"""승인 A 테스트 — 공통 날짜 교차검증 / 측정 불가(None) 재가중 / 거래일 기준 최신성.
네트워크 불필요. 실행:  cd 02_engine && python -m universal_quant_engine.tests.test_reliability_v1
"""
import os
import sys
from datetime import datetime, timedelta

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))

from universal_quant_engine import Market  # noqa: E402
from universal_quant_engine.collectors import _common  # noqa: E402
from universal_quant_engine.core.interfaces import MarketDataProvider  # noqa: E402
from universal_quant_engine.core.models import MarketBar, ReliabilityReport  # noqa: E402
from universal_quant_engine.reliability.engine import ReliabilityEngine  # noqa: E402
from universal_quant_engine.validation.cross_source import CrossSourceVerifier  # noqa: E402

results = []


def check(name, cond):
    results.append(bool(cond))
    print(f"{'PASS' if cond else 'FAIL'} - {name}")


def frame(closes, end="2026-09-25", vol=1e6, source="s"):
    """end(포함)까지 영업일 len(closes)개. 값은 closes 순서대로."""
    idx = pd.bdate_range(end=end, periods=len(closes))
    c = [float(x) for x in closes]
    return pd.DataFrame({"source": source, "timestamp": idx, "open": c, "high": [x + 1 for x in c],
                         "low": [x - 1 for x in c], "close": c, "volume": vol, "quality": "normal"})


def test_cross_source():
    print("-- 교차검증 (공통 날짜 기준) --")
    v = CrossSourceVerifier()
    base = [2600 + i for i in range(20)]

    r = v.compare_closes({"krx": frame(base), "yahoo": frame(base[:-1] , end="2026-09-24")})
    check("1일 늦은 소스라도 공통 날짜 값이 같으면 agreement 1.0", r["agreement"] == 1.0 and r["status"] == "ok")
    check("지연은 별도 상태로 표시 (yahoo 1영업일)", r["lagging_sources"] == {"yahoo": 1})
    check("비교 날짜 수·범위·소스별 마지막 날짜 포함",
          r["n_common_dates"] == 19 and r["common_date_range"][1] == "2026-09-24"
          and r["last_dates"] == {"krx": "2026-09-25", "yahoo": "2026-09-24"})

    bad = list(base); bad[-1] += 0.5
    r = v.compare_closes({"krx": frame(base), "naver": frame(bad)})
    check("실제 값 불일치는 agreement 하락", r["agreement"] < 1.0)
    check("2개 소스: 어느 쪽이 옳다고 판정하지 않음 (둘 다 같은 match)",
          len({c["match"] for c in r["comparisons"].values()}) == 1
          and not any(c["match"] for c in r["comparisons"].values()))
    check("소스별 편차·불일치 날짜 수 포함",
          all({"close_diff", "n_mismatch_dates", "max_close_diff", "n_dates"} <= set(c) for c in r["comparisons"].values())
          and r["comparisons"]["naver"]["n_mismatch_dates"] == 1)

    r = v.compare_closes({"krx": frame(base), "naver": frame([x + 0.004 for x in base])})
    check("허용오차(0.01) 이내 차이는 일치 (기본값 유지)", r["agreement"] == 1.0)
    r = v.compare_closes({"krx": frame(base), "naver": frame([x + 0.02 for x in base])})
    check("허용오차 초과 차이는 불일치", r["agreement"] == 0.0)

    r = v.compare_closes({"a": frame(base), "b": frame(base), "c": frame([x + 5 for x in base])})
    check("3개 소스: 기준은 중앙값 → 이탈 소스 하나만 불일치",
          r["comparisons"]["a"]["match"] and r["comparisons"]["b"]["match"]
          and not r["comparisons"]["c"]["match"] and abs(r["agreement"] - 2 / 3) < 1e-9)

    r = v.compare_closes({"only": frame(base)})
    check("단일 소스 → agreement None, single_source", r["agreement"] is None and r["status"] == "single_source")
    r = v.compare_closes({})
    check("빈 입력 → agreement None", r["agreement"] is None)
    r = v.compare_closes({"a": frame(base[:5], end="2026-08-14"), "b": frame(base[:5], end="2026-09-25")})
    check("공통 날짜 없음 → None + no_overlap", r["agreement"] is None and r["status"] == "no_overlap")
    check("허용오차를 인자로 바꿀 수 있음",
          CrossSourceVerifier(tolerance=0.05).compare_closes(
              {"krx": frame(base), "naver": frame([x + 0.02 for x in base])})["agreement"] == 1.0)


def test_reweighting():
    print("-- 종합 점수 재가중 --")
    rep = ReliabilityReport(source="x", freshness=1.0, completeness=1.0, consistency=0.75,
                            timestamp_quality=1.0, duplicate_rate=0.0, missing_rate=0.0,
                            outlier_rate=0.1, cross_source_agreement=None)
    bd = ReliabilityEngine.score_breakdown(rep)
    rest = [1.0, 1.0, 0.75, 1.0, 0.9]
    check("None 구성요소 제외 후 나머지 평균과 정확히 일치",
          bd["score"] == round(sum(rest) / 5 * 100, 1) and bd["n_used"] == 5
          and bd["excluded"] == ["cross_source_agreement"])
    rep.cross_source_agreement = 0.5
    bd2 = ReliabilityEngine.score_breakdown(rep)
    check("값이 있으면 6개 모두 평균", bd2["score"] == round((sum(rest) + 0.5) / 6 * 100, 1) and bd2["excluded"] == [])
    check("overall_score 는 breakdown 점수와 동일", ReliabilityEngine.overall_score(rep) == bd2["score"])
    check("to_dict 는 None 을 그대로 유지",
          ReliabilityReport(source="x").to_dict()["cross_source_agreement"] is None)


def test_freshness():
    print("-- 최신성 (거래일 기준, 주말만 휴장) --")
    e = ReliabilityEngine()
    fri = pd.Timestamp("2026-09-25")
    mon_am = datetime(2026, 9, 28, 9, 0)
    check("월요일 아침, 마지막 봉이 금요일 → 지연 0 (불필요한 감쇠 없음)", e.trading_day_lag(fri, mon_am) == 0)
    check("토요일, 마지막 봉이 금요일 → 지연 0", e.trading_day_lag(fri, datetime(2026, 9, 26, 12, 0)) == 0)
    check("월요일 16시 이후 금요일 봉 → 1거래일 지연", e.trading_day_lag(fri, datetime(2026, 9, 28, 17, 0)) == 1)
    check("수요일 봉, 금요일 기대 → 2거래일 지연", e.trading_day_lag(pd.Timestamp("2026-09-23"), mon_am) == 2)
    check("미래 날짜 봉은 지연 0", e.trading_day_lag(pd.Timestamp("2026-10-05"), mon_am) == 0)

    df = frame([2600 + i for i in range(30)], end="2026-09-25")
    rep0 = e.build_report("s", df, {"validators": {}}, now=mon_am)
    check("build_report: 월요일 아침 freshness 1.0", rep0.freshness == 1.0)
    df2 = frame([2600 + i for i in range(30)], end="2026-09-23")
    rep2 = e.build_report("s", df2, {"validators": {}}, now=mon_am)
    check("build_report: 실제 2거래일 지연은 감쇠 (0.25)", rep2.freshness == 0.25)
    check("cross_agreement 미지정 → None", rep0.cross_source_agreement is None)


class _P(MarketDataProvider):
    def __init__(self, name, close, lag=0):
        self.name, self.c, self.lag, self.last_status = name, close, lag, "ok"

    def get_bars(self, symbol, timeframe="1d", count=200):
        end = pd.Timestamp(datetime.now().date()) - pd.offsets.BDay(self.lag)
        days = pd.bdate_range(end=end, periods=count)
        return [MarketBar(symbol, d.to_pydatetime(), self.c, self.c + 1, self.c - 1, self.c, 1000.0, self.name)
                for d in days]

    def get_quote(self, symbol):
        return None

    def health(self):
        return True


def test_api():
    print("-- API 통합 --")
    m = Market(providers=["mock"], fetch_mode="fallback")
    m.providers = {"a": _P("a", 2600.0)}
    m.market("KOSPI", count=40)
    rep = m.reliability_report("KOSPI")
    v = m.verify("KOSPI")
    check("단일 소스: reliability_report.cross_source_agreement None", rep.cross_source_agreement is None)
    check("단일 소스: verify()가 예외 없이 agreement None 반환", v["cross_source"]["agreement"] is None)
    check("단일 소스: 종합 점수 0~100, 제외 항목 기록",
          0 <= rep.checks["overall_score"] <= 100
          and rep.checks["score_breakdown"]["excluded"] == ["cross_source_agreement"])

    m2 = Market(providers=["mock"], fetch_mode="all")
    m2.providers = {"a": _P("a", 2600.0), "b": _P("b", 2600.0, lag=1)}
    m2.market("KOSPI", count=40)
    rep2 = m2.reliability_report("KOSPI")
    check("2소스(한쪽 1일 지연·값 동일): agreement 1.0, 지연 소스 표시",
          rep2.cross_source_agreement == 1.0
          and rep2.checks["cross_source"]["lagging_sources"] == {"b": 1}
          and rep2.checks["score_breakdown"]["excluded"] == [])


def test_isolation_observation():
    print("-- 격리 확인 (관찰만; 구조 변경은 승인 B) --")
    state = _common.STATE_DIR
    before = sorted(p.name for p in state.glob("*")) if state.exists() else []
    _P("z", 1.0).get_bars("KOSPI", "1d", 5)
    Market(providers=["mock"]).market("KOSPI", count=10)
    CrossSourceVerifier().compare_closes({"a": frame([1, 2, 3]), "b": frame([1, 2, 3])})
    after = sorted(p.name for p in state.glob("*")) if state.exists() else []
    check("이 테스트 파일 실행 전후로 collector_state 파일 목록이 변하지 않음", before == after)


def run():
    test_cross_source(); test_reweighting(); test_freshness(); test_api(); test_isolation_observation()
    print("\n" + "=" * 50)
    print(f"{sum(results)}/{len(results)} 통과")
    return 0 if all(results) else 1


if __name__ == "__main__":
    raise SystemExit(run())
