"""CROSS-SOURCE VERIFICATION — 원천 간 값 비교. 하나를 임의로 선택하지 않고 차이를 보존한다.

비교 원칙 (승인 A):
  - 소스별 '마지막 봉'이 아니라 모든 소스에 존재하는 '공통 날짜'끼리 비교한다.
  - 날짜가 다른 것(지연)은 일치율에 섞지 않고 lagging_sources 로 따로 보고한다.
  - 기준값은 중앙값. 소스가 2개면 중앙값=평균이며, 어느 쪽이 옳은지 판정하지 않고
    두 소스 사이의 차이 자체를 허용오차와 비교한다.
  - 소스가 1개이거나 공통 날짜가 없으면 agreement=None (측정 불가). 1.0 으로 채우지 않는다.
허용오차(tolerance, volume_tolerance)의 기본값은 기존과 같다. 값의 적정성은 E1 실측 후 별도 결정.
"""
from typing import Dict, Optional
import numpy as np
import pandas as pd

_EPS = 1e-9  # 부동소수점 경계 오차 방지


def _by_date(df: pd.DataFrame) -> pd.DataFrame:
    """날짜(자정) 인덱스의 close/volume 표. 같은 날짜가 중복이면 마지막 행."""
    out = pd.DataFrame({
        "close": pd.to_numeric(df["close"], errors="coerce").to_numpy(),
        "volume": pd.to_numeric(df["volume"], errors="coerce").to_numpy(),
    }, index=pd.to_datetime(df["timestamp"]).dt.normalize())
    return out[~out.index.duplicated(keep="last")].dropna(subset=["close"])


class CrossSourceVerifier:
    def __init__(self, tolerance: float = 0.01, volume_tolerance: float = 0.05):
        self.tolerance = tolerance          # 가격 허용 오차 (절대)
        self.volume_tolerance = volume_tolerance  # 거래량 허용 오차 (비율)

    @staticmethod
    def _empty(status: str, last_dates: dict, lagging: dict, n_sources: int) -> dict:
        return {"agreement": None, "status": status, "reference": "median",
                "n_sources": n_sources, "n_common_dates": 0, "common_date_range": None,
                "last_dates": last_dates, "lagging_sources": lagging, "comparisons": {}}

    def compare_closes(self, frames: Dict[str, pd.DataFrame]) -> dict:
        """동일 symbol 의 원천별 DataFrame 을 공통 날짜 기준으로 비교한다.

        반환: agreement(0~1 또는 None), status(ok/single_source/no_overlap), n_common_dates,
              common_date_range, last_dates, lagging_sources(소스→뒤처진 영업일 수),
              comparisons(소스별 마지막 공통일의 값·편차와 전체 공통일 통계).
        """
        tables = {s: _by_date(df) for s, df in frames.items() if df is not None and len(df)}
        tables = {s: t for s, t in tables.items() if len(t)}
        last_dates = {s: t.index.max().date().isoformat() for s, t in tables.items()}
        newest = max((t.index.max() for t in tables.values()), default=None)
        lagging = {}
        if newest is not None:
            for s, t in tables.items():
                lag = int(np.busday_count(t.index.max().date(), newest.date()))
                if lag > 0:
                    lagging[s] = lag

        if len(tables) < 2:
            return self._empty("single_source", last_dates, lagging, len(tables))
        common = None
        for t in tables.values():
            common = t.index if common is None else common.intersection(t.index)
        common = common.sort_values()
        if len(common) == 0:
            return self._empty("no_overlap", last_dates, lagging, len(tables))

        srcs = list(tables)
        closes = pd.DataFrame({s: tables[s].loc[common, "close"] for s in srcs})
        vols = pd.DataFrame({s: tables[s].loc[common, "volume"] for s in srcs})
        ref_c = closes.median(axis=1)
        ref_v = vols.median(axis=1)

        if len(srcs) == 2:
            # 두 값 사이의 차이 자체를 비교한다 (어느 쪽이 옳은지 판정하지 않음)
            gap_c = (closes[srcs[0]] - closes[srcs[1]]).abs()
            dev_c = pd.DataFrame({s: gap_c for s in srcs})
            gap_v = (vols[srcs[0]] - vols[srcs[1]]).abs() / vols.max(axis=1).replace(0, 1.0)
            dev_v = pd.DataFrame({s: gap_v for s in srcs})
        else:
            dev_c = closes.sub(ref_c, axis=0).abs()
            dev_v = vols.sub(ref_v, axis=0).abs().div(ref_v.replace(0, 1.0), axis=0)
        dev_v = dev_v.fillna(0.0)  # 거래량 누락은 가격 일치 판정에 관여하지 않음
        ok = (dev_c <= self.tolerance + _EPS) & (dev_v <= self.volume_tolerance + _EPS)

        last = common[-1]
        comparisons = {}
        for s in srcs:
            comparisons[s] = {
                "close": float(closes.loc[last, s]),
                "close_diff": round(float(dev_c.loc[last, s]), 4),
                "volume": float(vols.loc[last, s]) if pd.notna(vols.loc[last, s]) else 0.0,
                "volume_diff_ratio": round(float(dev_v.loc[last, s]), 4),
                "match": bool(ok.loc[last, s]),
                "compared_date": last.date().isoformat(),
                "n_dates": int(len(common)),
                "n_mismatch_dates": int((~ok[s]).sum()),
                "max_close_diff": round(float(dev_c[s].max()), 4),
                "mean_close_diff": round(float(dev_c[s].mean()), 4),
            }
        agreement = float(ok.to_numpy().mean())
        return {"agreement": agreement, "status": "ok", "reference": "median",
                "n_sources": len(srcs), "n_common_dates": int(len(common)),
                "common_date_range": [common[0].date().isoformat(), last.date().isoformat()],
                "last_dates": last_dates, "lagging_sources": lagging,
                "comparisons": comparisons}

    def ohlc_table(self, frames: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """원천별 OHLCV 비교표."""
        rows = []
        for src, df in frames.items():
            if len(df):
                r = df.iloc[-1]
                rows.append({"source": src, "open": r["open"], "high": r["high"],
                             "low": r["low"], "close": r["close"], "volume": r["volume"]})
        return pd.DataFrame(rows)
