"""RELIABILITY ENGINE — 구성요소를 보존하는 신뢰도 리포트.

승인 A 변경점:
  - 최신성: 시계 시간이 아니라 '기대 최신 거래일 대비 뒤처진 거래일 수'로 감쇠한다.
    한계: 이번 단계에서는 주말만 휴장으로 보며 한국 공휴일 달력은 반영하지 않는다.
          공휴일 직후에는 최신성이 실제보다 낮게 계산될 수 있다. 서버 시각은 한국 시간이라고 가정한다.
  - 측정 불가(None) 구성요소는 종합 점수에서 빼고 남은 항목으로 다시 계산한다(재가중).
"""
from datetime import date, datetime, timedelta
from typing import Dict, Optional

import numpy as np
import pandas as pd

from ..core.models import ReliabilityReport


def expected_latest_trading_day(now: datetime, publish_hour: int = 16) -> date:
    """지금 시점에 제공되어야 하는 가장 최근 거래일 (주말만 휴장으로 간주).
    평일 publish_hour 이전에는 오늘 봉이 아직 확정 전이므로 직전 평일을 기대한다."""
    d = now.date()
    if not (d.weekday() < 5 and now.hour >= publish_hour):
        d -= timedelta(days=1)
    while d.weekday() >= 5:
        d -= timedelta(days=1)
    return d


class ReliabilityEngine:
    """데이터 품질 검증 결과 + 원천 간 일치율 → ReliabilityReport.
    합산 점수는 정책(policy)으로 분리: 기본 정책은 가중평균.
    """

    def __init__(self, freshness_halflife_trading_days: float = 1.0, publish_hour: int = 16):
        self.halflife = freshness_halflife_trading_days
        self.publish_hour = publish_hour

    def trading_day_lag(self, last_bar: pd.Timestamp, now: datetime) -> int:
        """기대 최신 거래일보다 몇 거래일 뒤처졌는지 (앞서 있으면 0)."""
        expected = expected_latest_trading_day(now, self.publish_hour)
        last = pd.Timestamp(last_bar).date()
        if last >= expected:
            return 0
        return int(np.busday_count(last, expected))

    def build_report(self, source: str, data: pd.DataFrame,
                     validation: dict = None, cross_agreement: Optional[float] = None,
                     now: Optional[datetime] = None) -> ReliabilityReport:
        n = len(data)
        now = now or datetime.now()

        # 최신성: 기대 최신 거래일 대비 뒤처진 거래일 수로 지수 감쇠
        if n and "timestamp" in data:
            last_ts = pd.to_datetime(data["timestamp"]).iloc[-1]
            lag = self.trading_day_lag(last_ts, now)
            freshness = 0.5 ** (lag / self.halflife)
        else:
            freshness = 0.0

        v = (validation or {}).get("validators", {})
        missing_rate = v.get("missing", {}).get("details", {}).get("missing_rate", 0.0)
        duplicate_rate = v.get("duplicate", {}).get("details", {}).get("duplicate_rate", 0.0)
        outlier_rate = v.get("outlier", {}).get("details", {}).get("outlier_rate", 0.0)
        ts_passed = v.get("timestamp", {}).get("passed", False)
        ohlc_passed = v.get("ohlc", {}).get("passed", False)
        continuity_passed = v.get("continuity", {}).get("passed", False)

        consistency = 1.0
        consistency -= 0.5 * (not ohlc_passed) + 0.25 * (not continuity_passed)
        consistency = max(consistency, 0.0)

        return ReliabilityReport(
            source=source,
            freshness=round(freshness, 4),
            completeness=round(max(1.0 - missing_rate, 0.0), 4),
            consistency=round(consistency, 4),
            timestamp_quality=1.0 if ts_passed else 0.5,
            duplicate_rate=round(duplicate_rate, 4),
            missing_rate=round(missing_rate, 4),
            outlier_rate=round(outlier_rate, 4),
            cross_source_agreement=None if cross_agreement is None else round(cross_agreement, 4),
            checks=v,
        )

    @staticmethod
    def score_components(report: ReliabilityReport) -> Dict[str, Optional[float]]:
        """종합 점수에 들어가는 구성요소. 측정 불가는 None."""
        return {
            "freshness": report.freshness,
            "completeness": report.completeness,
            "consistency": report.consistency,
            "timestamp_quality": report.timestamp_quality,
            "cross_source_agreement": report.cross_source_agreement,
            "anomaly_free": 1.0 - min(report.duplicate_rate + report.missing_rate + report.outlier_rate, 1.0),
        }

    @staticmethod
    def score_breakdown(report: ReliabilityReport) -> dict:
        """종합 점수와 계산 근거: 사용한 항목 / 제외한 항목(측정 불가) / 항목별 값."""
        comps = ReliabilityEngine.score_components(report)
        used = {k: x for k, x in comps.items() if x is not None}
        excluded = [k for k, x in comps.items() if x is None]
        score = round(sum(used.values()) / len(used) * 100, 1) if used else 0.0
        return {"score": score, "policy": "equal_weight_mean_of_measured",
                "used": used, "excluded": excluded, "n_used": len(used)}

    @staticmethod
    def overall_score(report: ReliabilityReport) -> float:
        """기본 정책: 측정된 항목의 균등 가중평균 (0~100). 측정 불가 항목은 제외 후 재가중."""
        return ReliabilityEngine.score_breakdown(report)["score"]
