"""vol_bridge 테스트 — UME MockProvider 와 합성 데이터만 사용 (네트워크·실제 계정 불필요).

UME(universal_quant_engine) 가 같은 02_engine 폴더에 없으면 UME 의존 테스트는 SKIP 으로 표시된다.
합성 옵션체인은 실제 시장 데이터가 아니다. 통합 테스트는 '계약 경계가 맞는지' 확인하는 용도다.

실행:  cd 02_engine && python -m vol_bridge.tests.test_bridge
"""
import os
import re
import sys
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, ENGINE)

from vol_bridge.price_adapter import UmePriceSeriesSource, frame_to_price_series  # noqa: E402
from volatility_model import implied_vol as iv  # noqa: E402
from volatility_model import synthetic as syn  # noqa: E402
from volatility_model.bl_density import bl_density  # noqa: E402
from volatility_model.contracts import PriceSeries, PriceSeriesSource  # noqa: E402

try:
    from universal_quant_engine import Market  # noqa: E402
    HAVE_UME = True
except Exception:  # pragma: no cover
    HAVE_UME = False

results = []


def check(name, cond):
    results.append(bool(cond))
    print(f"{'PASS' if cond else 'FAIL'} - {name}")


def skip(name):
    print(f"SKIP - {name} (UME 없음)")


def raises(fn, exc=ValueError):
    try:
        fn()
    except exc:
        return True
    except Exception:
        return False
    return False


def frame(n=10, **over):
    t0 = datetime(2026, 9, 1, 16, 0)
    df = pd.DataFrame({
        "source": ["mock"] * n,
        "timestamp": [t0 + timedelta(days=i) for i in range(n)],
        "open": 2500.0 + np.arange(n), "high": 2510.0 + np.arange(n), "low": 2490.0 + np.arange(n),
        "close": 2500.0 + np.arange(n), "volume": [1e6] * n, "quality": ["normal"] * n})
    for k, v in over.items():
        df[k] = v
    return df


class FakeMarket:
    """UME Market 과 같은 메서드만 가진 가짜 객체 (duck typing 확인용)."""
    def __init__(self, df, report=True, fail_report=False):
        self.df, self.calls, self._report, self._fail = df, [], report, fail_report
        self.last_report = {"used": ["mock"], "errors": {}, "skipped": {}}
        if not report:
            self.reliability_report = None

    def market(self, symbol, timeframe="1d", count=200):
        self.calls.append((symbol, timeframe, count))
        return self.df

    def reliability_report(self, symbol):
        if self._fail:
            raise RuntimeError("boom")
        class R:
            checks = {"overall_score": 88.0}
            def to_dict(self):
                return {"source": "mock", "freshness": 0.5, "completeness": 1.0}
        return R()


def test_frame_conversion():
    print("-- frame_to_price_series --")
    df = frame(10)
    before = df.copy(deep=True)
    ps, flags = frame_to_price_series(df, "KOSPI200")
    check("정상 변환: 길이·종가·시각·소스 보존, 플래그 없음",
          isinstance(ps, PriceSeries) and len(ps.close) == 10 and np.array_equal(ps.close, df["close"].to_numpy())
          and ps.timestamps[0] == datetime(2026, 9, 1, 16, 0) and ps.source == "mock" and flags == ())
    check("입력 DataFrame 은 수정되지 않음", df.equals(before))

    shuffled = df.sample(frac=1.0, random_state=1)
    ps2, _ = frame_to_price_series(shuffled, "X")
    check("순서가 섞인 입력도 시각 오름차순으로 정렬", np.array_equal(ps2.close, ps.close))

    q = frame(10, quality=["normal"] * 6 + ["missing", "delayed", "manual", "normal"])
    ps3, f3 = frame_to_price_series(q, "X")
    check("quality: missing 제외, delayed/manual 은 포함하고 플래그",
          len(ps3.close) == 9 and "quality_missing_excluded:1" in f3
          and "quality_delayed_included:1" in f3 and "quality_manual_included:1" in f3)

    bad = frame(10)
    bad.loc[2, "close"] = np.nan; bad.loc[3, "close"] = 0.0; bad.loc[4, "close"] = -5.0
    ps4, f4 = frame_to_price_series(bad, "X")
    check("종가 NaN/0/음수 행 제외 + 플래그", len(ps4.close) == 7 and "invalid_close_excluded:3" in f4)

    dup = pd.concat([frame(5), frame(5).iloc[[2]].assign(close=9999.0)], ignore_index=True)
    ps5, f5 = frame_to_price_series(dup, "X")
    check("중복 시각: 마지막 행만 남기고 플래그", len(ps5.close) == 5 and 9999.0 in ps5.close and "duplicate_timestamp_dropped:1" in f5)

    multi = frame(4); multi.loc[0, "source"] = "naver"
    _, f6 = frame_to_price_series(multi, "X")
    check("여러 소스가 섞이면 플래그", any(x.startswith("multiple_sources:") for x in f6))

    check("빈 데이터 / 필수 컬럼 없음 / 유효 행 없음 → ValueError",
          raises(lambda: frame_to_price_series(pd.DataFrame(), "X"))
          and raises(lambda: frame_to_price_series(df.drop(columns=["close"]), "X"))
          and raises(lambda: frame_to_price_series(frame(3, quality=["missing"] * 3), "X")))


def test_source_wrapper():
    print("-- UmePriceSeriesSource (가짜 market, duck typing) --")
    df = frame(30)
    fm = FakeMarket(df)
    src = UmePriceSeriesSource(fm, count=30)
    check("PriceSeriesSource 인터페이스 충족", isinstance(src, PriceSeriesSource))
    ps = src.get_price_series("KOSPI200", "2026-09-05", "2026-09-10")
    check("market(symbol, timeframe, count) 로 호출", fm.calls == [("KOSPI200", "1d", 30)])
    check("start/end(날짜, end 포함)로 자름", [t.day for t in ps.timestamps] == [5, 6, 7, 8, 9, 10])
    ps_all = src.get_price_series("KOSPI200", None, None)
    check("기간 미지정이면 전체", len(ps_all.close) == 30)
    src.get_price_series("KOSPI200", "2026-08-01", "2026-09-10")
    check("받은 데이터가 start 보다 늦게 시작하면 플래그(정보 포함)",
          any(f == "data_starts_after_requested_start:2026-09-01" for f in src.last_flags))
    check("신뢰도 값이 변형 없이 별도 전달",
          src.last_reliability == {"components": {"source": "mock", "freshness": 0.5, "completeness": 1.0},
                                   "overall_score": 88.0,
                                   "collection": {"used": ["mock"], "errors": {}, "skipped": {}}})
    check("신뢰도 계산 실패가 가격 변환을 막지 않음(플래그만)",
          (lambda s: (s.get_price_series("X", None, None), s.last_reliability is None
                      and any(f.startswith("reliability_unavailable") for f in s.last_flags))[1])(
              UmePriceSeriesSource(FakeMarket(df, fail_report=True))))
    check("reliability_report 없는 객체도 동작(플래그)",
          (lambda s: (s.get_price_series("X", None, None), "reliability_unavailable" in s.last_flags)[1])(
              UmePriceSeriesSource(FakeMarket(df, report=False))))
    check("기간에 데이터가 없으면 ValueError",
          raises(lambda: src.get_price_series("X", "2027-01-01", "2027-01-31")))
    check("count < 1 거부", raises(lambda: UmePriceSeriesSource(fm, count=0)))


def test_real_ume():
    print("-- 실제 UME (MockProvider) --")
    if not HAVE_UME:
        skip("UME 실제 연동"); return
    m = Market(providers=["mock"])
    src = UmePriceSeriesSource(m, count=60)
    ps = src.get_price_series("KOSPI200")
    frame_direct = m.market("KOSPI200", "1d", 60)
    check("UME Mock → PriceSeries: 길이 60, 종가가 UME 표준 프레임과 일치",
          len(ps.close) == 60 and np.array_equal(ps.close, frame_direct["close"].to_numpy()) and ps.source == "mock")
    rep = m.reliability_report("KOSPI200")
    check("UME 신뢰도가 값 그대로 전달 (components·overall_score)",
          src.last_reliability["components"] == rep.to_dict()
          and src.last_reliability["overall_score"] == rep.checks["overall_score"]
          and src.last_reliability["collection"]["used"] == ["mock"])
    check("PriceSeries 계약 충족(양수·오름차순)", np.all(ps.close > 0) and all(b > a for a, b in zip(ps.timestamps, ps.timestamps[1:])))

    # 결합 통합: UME 종가 → 스팟 → (합성) 옵션체인 → BL. 합성 옵션체인은 실제 시장 데이터가 아님.
    spot = float(ps.close[-1])
    chain = syn.make_option_chain(S=spot, strikes=np.linspace(0.5 * spot, 2.0 * spot, 161))
    cur = iv.otm_call_curve(chain)
    res = bl_density(cur.strikes, cur.call_prices, forward=chain.forward, T=chain.T, r=chain.rate)
    check("결합 흐름(UME 종가→합성 옵션체인→OTM 곡선→BL): 유한한 밀도, 음수 없음, 질량 합이 적분과 일치",
          np.all(np.isfinite(res.density)) and res.neg_density_ratio == 0.0
          and abs(res.downside_mass + res.upside_mass - res.integral_clipped) < 0.01
          and chain.source == "synthetic")


def test_reliability_none():
    print("-- 신뢰도 구성요소 None (승인 A: 측정 불가) --")
    class FM(FakeMarket):
        def reliability_report(self, symbol):
            class R:
                checks = {"overall_score": 91.0}
                def to_dict(self):
                    return {"source": "mock", "freshness": 1.0, "cross_source_agreement": None}
            return R()
    src = UmePriceSeriesSource(FM(frame(10)), count=10)
    src.get_price_series("X")
    check("가짜 market: cross_source_agreement=None 이 변형 없이 전달, 종합 점수 유지",
          src.last_reliability["components"]["cross_source_agreement"] is None
          and src.last_reliability["overall_score"] == 91.0 and "reliability_unavailable" not in src.last_flags)
    if not HAVE_UME:
        skip("실제 UME 단일 소스 None"); return
    m = Market(providers=["mock"])
    src = UmePriceSeriesSource(m, count=30)
    ps = src.get_price_series("KOSPI200")
    lr = src.last_reliability
    check("실제 UME 단일 소스: components 의 cross_source_agreement None, overall_score 0~100, 가격 변환 정상",
          lr is not None and lr["components"]["cross_source_agreement"] is None
          and 0 <= lr["overall_score"] <= 100 and len(ps.close) == 30
          and not any(f.startswith("reliability_unavailable") for f in src.last_flags))


def test_independence():
    print("-- 독립성 --")
    def imports(dirpath, needle):
        hits = []
        for root, _, files in os.walk(dirpath):
            for fn in files:
                if fn.endswith(".py") and os.path.join(root) != HERE:
                    for line in open(os.path.join(root, fn), encoding="utf-8"):
                        if re.match(r"\s*(import|from)\s+.*" + needle, line):
                            hits.append(os.path.join(root, fn))
        return hits
    bridge_dir = os.path.join(ENGINE, "vol_bridge")
    check("브리지는 UME 를 import 하지 않음(duck typing)", not imports(bridge_dir, "universal_quant_engine"))
    check("volatility_model 은 UME/브리지를 import 하지 않음",
          not imports(os.path.join(ENGINE, "volatility_model"), "universal_quant_engine|vol_bridge"))
    ume_dir = os.path.join(ENGINE, "universal_quant_engine")
    if os.path.isdir(ume_dir):
        check("UME 는 변동성 모델/브리지를 import 하지 않음(UME 미수정)",
              not imports(ume_dir, "volatility_model|vol_bridge"))
    else:
        skip("UME 독립성")


def run():
    test_frame_conversion(); test_source_wrapper(); test_real_ume(); test_reliability_none(); test_independence()
    print("\n" + "=" * 50)
    print(f"{sum(results)}/{len(results)} 통과")
    return 0 if all(results) else 1


if __name__ == "__main__":
    raise SystemExit(run())
