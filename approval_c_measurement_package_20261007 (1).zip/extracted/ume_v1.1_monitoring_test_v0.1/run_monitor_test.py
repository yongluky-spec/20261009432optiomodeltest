"""감시 모듈 테스트 실행기 — 실제 KRX 접속 없이 알고리즘을 검증한다."""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENGINE_ROOT = ROOT / "02_engine"
sys.path.insert(0, str(ENGINE_ROOT))

import pandas as pd
from universal_quant_engine.monitoring import MonitoringEngine


def make_data():
    ts = pd.date_range("2026-09-28 09:00", periods=5, freq="h")
    return pd.DataFrame({
        "symbol": ["KOSPI"] * 5,
        "timestamp": ts,
        "open": [100, 101, 102, 103, 104],
        "high": [101, 102, 103, 104, 105],
        "low": [99, 100, 101, 102, 103],
        "close": [100.5, 101.5, 102.5, 103.5, 104.5],
        "volume": [1000, 1100, 1200, 1300, 1400],
        "source": ["mock"] * 5,
        "quality": ["normal"] * 5,
    })


def main():
    previous = make_data()
    current = previous.copy()
    current.loc[4, "close"] = 106.5
    current.loc[4, "high"] = 107.0
    current.loc[4, "volume"] = 1800

    engine = MonitoringEngine()
    result = engine.run(current=current, previous=previous)

    print("=" * 70)
    print("UME Monitoring Module — TEST v0.1")
    print("=" * 70)
    print("상태:", result.status)
    print("변경 행:", result.changes["changed_count"])
    print("수정:", len(result.changes["modified"]))
    print("추가:", len(result.changes["added"]))
    print("삭제:", len(result.changes["removed"]))
    print("검증 PASS:", result.validation["passed"])
    print("신뢰도:", result.overall_score)
    print("\n[변경 내용]")
    for item in result.changes["modified"]:
        print("KEY:", item["key"])
        for field, change in item["changes"].items():
            print(f"  {field}: {change}")
    print("\n[검증]")
    for name, check in result.validation["validators"].items():
        print(f"  {name}: {'PASS' if check.get('passed') else 'FAIL'}")
    print("\n테스트 완료")


if __name__ == "__main__":
    main()
