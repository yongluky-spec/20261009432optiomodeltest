"""MONITORING ENGINE — 변경 감지 + 기존 검증/신뢰도 엔진 통합."""
from dataclasses import dataclass
from typing import Dict, Optional
import pandas as pd

from ..validation.data_quality import DataValidator
from ..validation.cross_source import CrossSourceVerifier
from ..reliability.engine import ReliabilityEngine
from .change_detector import ChangeDetector


@dataclass
class MonitoringResult:
    status: str
    changes: dict
    validation: dict
    cross_source: dict
    reliability: dict
    overall_score: float

    def to_dict(self) -> dict:
        return {
            "status": self.status,
            "changes": self.changes,
            "validation": self.validation,
            "cross_source": self.cross_source,
            "reliability": self.reliability,
            "overall_score": self.overall_score,
        }


class MonitoringEngine:
    """수집하지 않는다. 입력된 이전/현재 데이터만 감시한다."""

    def __init__(self, validator=None, cross_verifier=None, reliability=None, change_detector=None):
        self.validator = validator or DataValidator()
        self.cross_verifier = cross_verifier or CrossSourceVerifier()
        self.reliability = reliability or ReliabilityEngine()
        self.change_detector = change_detector or ChangeDetector()

    def run(self, current: pd.DataFrame, previous: Optional[pd.DataFrame] = None,
            source_frames: Optional[Dict[str, pd.DataFrame]] = None) -> MonitoringResult:
        changes = self.change_detector.compare(previous, current).to_dict() if previous is not None else {
            "added": [], "removed": [], "modified": [], "unchanged": 0, "changed_count": 0
        }

        validation = self.validator.validate(current)
        frames = source_frames or {}
        if not frames:
            frames = {str(current["source"].iloc[0]) if "source" in current.columns and len(current) else "current": current}
        cross = self.cross_verifier.compare_closes(frames) if len(frames) >= 2 else {"agreement": 1.0, "comparisons": {}}
        source = str(current["source"].iloc[0]) if "source" in current.columns and len(current) else "unknown"
        report = self.reliability.build_report(source, current, validation=validation,
                                               cross_agreement=cross.get("agreement", 1.0))
        score = self.reliability.overall_score(report)
        reliability = report.to_dict()
        reliability["overall_score"] = score

        status = self._status(changes, validation, score, cross.get("agreement", 1.0))
        return MonitoringResult(status, changes, validation, cross, reliability, score)

    @staticmethod
    def _status(changes, validation, score, agreement):
        if not validation.get("passed", False):
            return "ERROR"
        if score < 70.0 or agreement < 0.67:
            return "WARNING"
        if changes.get("changed_count", 0) > 0:
            return "CHANGED"
        return "NORMAL"
