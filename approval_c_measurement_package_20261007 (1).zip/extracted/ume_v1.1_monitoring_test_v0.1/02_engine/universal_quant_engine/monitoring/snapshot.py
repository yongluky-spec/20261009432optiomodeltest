"""SNAPSHOT STORE — 감시용 이전/현재 데이터를 간단한 CSV로 보관한다."""
from pathlib import Path
import pandas as pd


class SnapshotStore:
    def __init__(self, directory="monitor_data"):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def path(self, symbol):
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in str(symbol))
        return self.directory / f"{safe}_latest.csv"

    def load(self, symbol):
        path = self.path(symbol)
        if not path.exists():
            return None
        return pd.read_csv(path, parse_dates=["timestamp"])

    def save(self, symbol, data):
        data.to_csv(self.path(symbol), index=False)
