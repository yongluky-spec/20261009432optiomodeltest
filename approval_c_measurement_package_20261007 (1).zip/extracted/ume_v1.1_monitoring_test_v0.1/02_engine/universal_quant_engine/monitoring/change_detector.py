"""CHANGE DETECTOR — 이전 Snapshot과 현재 데이터를 비교한다."""
from dataclasses import dataclass, field
from typing import Dict, List, Any
import pandas as pd

KEY_COLUMNS = ["symbol", "timestamp"]
COMPARE_COLUMNS = ["open", "high", "low", "close", "volume", "source", "quality"]


@dataclass
class ChangeReport:
    added: List[Dict[str, Any]] = field(default_factory=list)
    removed: List[Dict[str, Any]] = field(default_factory=list)
    modified: List[Dict[str, Any]] = field(default_factory=list)
    unchanged: int = 0

    @property
    def changed_count(self) -> int:
        return len(self.added) + len(self.removed) + len(self.modified)

    def to_dict(self) -> dict:
        return {
            "added": self.added,
            "removed": self.removed,
            "modified": self.modified,
            "unchanged": self.unchanged,
            "changed_count": self.changed_count,
        }


class ChangeDetector:
    """동일 symbol+timestamp를 기준으로 이전/현재 Snapshot을 비교한다."""

    def __init__(self, key_columns=None, compare_columns=None):
        self.key_columns = key_columns or KEY_COLUMNS
        self.compare_columns = compare_columns or COMPARE_COLUMNS

    @staticmethod
    def _key(row, columns):
        return tuple(str(row[c]) for c in columns)

    def compare(self, previous: pd.DataFrame, current: pd.DataFrame) -> ChangeReport:
        previous = previous.copy()
        current = current.copy()
        for frame in (previous, current):
            if "timestamp" in frame:
                frame["timestamp"] = pd.to_datetime(frame["timestamp"])
            if "symbol" not in frame:
                frame["symbol"] = "UNKNOWN"

        prev_map = {self._key(row, self.key_columns): row for _, row in previous.iterrows()}
        curr_map = {self._key(row, self.key_columns): row for _, row in current.iterrows()}

        report = ChangeReport()

        for key in sorted(curr_map.keys() - prev_map.keys(), key=str):
            row = curr_map[key]
            report.added.append({"key": key, "current": row.to_dict()})

        for key in sorted(prev_map.keys() - curr_map.keys(), key=str):
            row = prev_map[key]
            report.removed.append({"key": key, "previous": row.to_dict()})

        for key in sorted(curr_map.keys() & prev_map.keys(), key=str):
            old = prev_map[key]
            new = curr_map[key]
            fields = {}
            for col in self.compare_columns:
                if col not in old.index or col not in new.index:
                    continue
                a, b = old[col], new[col]
                if pd.isna(a) and pd.isna(b):
                    continue
                if self._different(a, b):
                    change = {"previous": self._safe(a), "current": self._safe(b)}
                    if self._numeric(a) and self._numeric(b):
                        change["delta"] = float(b - a)
                        change["pct_change"] = None if float(a) == 0 else float((b - a) / a * 100.0)
                    fields[col] = change
            if fields:
                report.modified.append({"key": key, "changes": fields})
            else:
                report.unchanged += 1

        return report

    @staticmethod
    def _numeric(value):
        return isinstance(value, (int, float)) and not isinstance(value, bool) and pd.notna(value)

    @staticmethod
    def _different(a, b):
        if isinstance(a, pd.Timestamp) or isinstance(b, pd.Timestamp):
            return pd.Timestamp(a) != pd.Timestamp(b)
        try:
            if pd.isna(a) and pd.isna(b):
                return False
        except (TypeError, ValueError):
            pass
        return a != b

    @staticmethod
    def _safe(value):
        if isinstance(value, pd.Timestamp):
            return value.isoformat()
        if pd.isna(value):
            return None
        if hasattr(value, "item"):
            try:
                return value.item()
            except Exception:
                pass
        return value
