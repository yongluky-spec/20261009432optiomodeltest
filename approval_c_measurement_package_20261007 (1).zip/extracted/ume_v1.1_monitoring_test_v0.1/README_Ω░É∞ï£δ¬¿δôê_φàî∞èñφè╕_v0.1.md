# UME 감시 모듈 테스트 v0.1

이 버전은 기존 데이터 수집 모듈을 수정하지 않고, 감시 기능을 독립 모듈로 시험하기 위한 테스트 버전이다.

## 핵심 알고리즘

### A. ChangeDetector
- 이전 Snapshot과 현재 데이터를 `symbol + timestamp`로 매칭
- 신규(added), 삭제(removed), 수정(modified), 동일(unchanged) 구분
- OHLCV/source/quality 변경값과 숫자형 delta, pct_change 계산

### B. MonitoringEngine
- 기존 `DataValidator` 재사용
- 기존 `CrossSourceVerifier` 재사용
- 기존 `ReliabilityEngine` 재사용
- 변경 결과 + 검증 결과 + 신뢰도를 통합해 상태를 산출

상태:
- NORMAL: 변경 없음 + 검증 정상
- CHANGED: 변경 있음 + 검증/신뢰도 정상
- WARNING: 신뢰도 또는 원천 일치율 경고
- ERROR: 데이터 검증 실패

## 테스트 실행

프로젝트 루트에서:

```bash
python run_monitor_test.py
```

실제 KRX 접속이나 계정정보가 필요하지 않다. 가상 데이터로 이전/현재 변경을 만들고 알고리즘만 테스트한다.

## 중요한 제한

- 이것은 테스트 버전이다.
- 신뢰도 임계값(70, 67%)은 운영 확정값이 아니다.
- Snapshot 저장/운영 연결 정책은 아직 확정하지 않았다.
- 기존 대시보드는 이 테스트 버전에서 변경하지 않는다.
