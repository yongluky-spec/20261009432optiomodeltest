#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
KOSPI / KOSPI200 Market Decision Dashboard
- 현물 / 선물 / 인버스 분리
- 현·선물 괴리(Basis) 계산
- 이동평균, ATR, 변동성
- 지지/저항 밴드
- 0/25/50/75/100% 포지션 레벨
- Streamlit 웹 대시보드

실행:
    pip install -r requirements.txt
    streamlit run kospi_model.py

데이터:
    yfinance 무료 데이터 사용.
    선물 티커는 환경/시장 데이터 제공처에 따라 달라질 수 있으므로
    사이드바에서 직접 티커를 수정할 수 있게 구성했다.
"""

import os
import numpy as np
import pandas as pd
import streamlit as st
import yfinance as yf

st.set_page_config(
    page_title="KOSPI Market Engine",
    page_icon="📈",
    layout="wide",
)

DEFAULTS = {
    "KOSPI 현물": "^KS11",
    "KOSPI200 현물": "^KS200",
    "KOSPI200 선물": "KS200",
    "인버스 ETF": "114800.KS",  # KODEX 인버스 예시. 필요시 변경
}

@st.cache_data(ttl=300)
def load_data(ticker: str, period: str = "1y", interval: str = "1d"):
    if not ticker:
        return pd.DataFrame()

    try:
        df = yf.download(
            ticker,
            period=period,
            interval=interval,
            auto_adjust=False,
            progress=False,
        )
        if df.empty:
            return pd.DataFrame()

        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)

        required = ["Open", "High", "Low", "Close"]
        if not all(c in df.columns for c in required):
            return pd.DataFrame()

        df = df[required + ([c for c in ["Volume"] if c in df.columns])]
        return df.dropna()
    except Exception:
        return pd.DataFrame()


def pct_change(df, n=1):
    return df["Close"].pct_change(n) * 100


def atr(df, n=14):
    prev_close = df["Close"].shift(1)
    tr = pd.concat(
        [
            df["High"] - df["Low"],
            (df["High"] - prev_close).abs(),
            (df["Low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return tr.rolling(n).mean()


def zscore(series, n=60):
    mean = series.rolling(n).mean()
    std = series.rolling(n).std()
    return (series - mean) / std.replace(0, np.nan)


def make_levels(df):
    close = float(df["Close"].iloc[-1])
    ma20 = float(df["Close"].rolling(20).mean().iloc[-1])
    ma60 = float(df["Close"].rolling(60).mean().iloc[-1])
    a = float(atr(df).iloc[-1])

    # 변동성에 따른 동적 밴드
    resistance = max(ma20, close) + 1.0 * a
    support = min(ma20, close) - 1.0 * a

    # 최근 60일 고저점
    high60 = float(df["High"].rolling(60).max().iloc[-1])
    low60 = float(df["Low"].rolling(60).min().iloc[-1])

    return {
        "close": close,
        "ma20": ma20,
        "ma60": ma60,
        "atr": a,
        "resistance": resistance,
        "support": support,
        "high60": high60,
        "low60": low60,
    }


def directional_score(df):
    """-100 ~ +100. +는 상승, -는 하락."""
    if len(df) < 70:
        return 0.0, 0.0, "데이터 부족"

    close = df["Close"]
    ma20 = close.rolling(20).mean()
    ma60 = close.rolling(60).mean()
    r5 = close.pct_change(5).iloc[-1] * 100
    r20 = close.pct_change(20).iloc[-1] * 100

    score = 0.0

    # 추세
    score += 30 if close.iloc[-1] > ma20.iloc[-1] else -30
    score += 25 if ma20.iloc[-1] > ma60.iloc[-1] else -25

    # 단기 모멘텀
    score += np.clip(r5 * 8, -20, 20)
    score += np.clip(r20 * 3, -15, 15)

    # 최근 종가 위치
    hi = close.rolling(60).max().iloc[-1]
    lo = close.rolling(60).min().iloc[-1]
    pos = (close.iloc[-1] - lo) / (hi - lo) if hi != lo else 0.5
    score += (pos - 0.5) * 20

    score = float(np.clip(score, -100, 100))
    confidence = float(np.clip(abs(score), 0, 100))

    if score >= 25:
        direction = "상승 우세"
    elif score <= -25:
        direction = "하락 우세"
    else:
        direction = "중립 / 혼조"

    return score, confidence, direction


def position_level(score, confidence, basis_z=0.0):
    """
    0/25/50/75/100 레벨.
    하락 방향일수록 인버스/헤지 비중을 높이는 구조.
    Basis가 비정상적으로 벌어지면 한 단계 보수적으로 낮춘다.
    """
    effective = score

    # 현물 대비 선물의 괴리가 지나치게 크면 확신도 할인
    if abs(basis_z) >= 2:
        effective *= 0.65
    elif abs(basis_z) >= 1.5:
        effective *= 0.8

    if effective <= -65 and confidence >= 65:
        return 100
    if effective <= -45 and confidence >= 45:
        return 75
    if effective <= -25 and confidence >= 25:
        return 50
    if effective < 0:
        return 25
    return 0


def regime_text(score, confidence):
    if confidence < 25:
        return "신호 약함"
    if score <= -60:
        return "강한 하방 위험"
    if score <= -25:
        return "하방 우세"
    if score >= 60:
        return "강한 상승"
    if score >= 25:
        return "상승 우세"
    return "중립"


# ---------------- Sidebar ----------------
st.sidebar.title("⚙️ 데이터 설정")

kospi_ticker = st.sidebar.text_input("KOSPI 현물", DEFAULTS["KOSPI 현물"])
ks200_ticker = st.sidebar.text_input("KOSPI200 현물", DEFAULTS["KOSPI200 현물"])
futures_ticker = st.sidebar.text_input("KOSPI200 선물", DEFAULTS["KOSPI200 선물"])
inverse_ticker = st.sidebar.text_input("인버스 ETF", DEFAULTS["인버스 ETF"])

period = st.sidebar.selectbox(
    "분석 기간",
    ["6mo", "1y", "2y", "5y"],
    index=1,
)

st.sidebar.caption(
    "※ 무료 데이터 제공처의 티커/지연 여부는 변할 수 있습니다. "
    "실전 매매 전에는 KRX/증권사 데이터로 교차검증하세요."
)

# ---------------- Load ----------------
kospi = load_data(kospi_ticker, period)
ks200 = load_data(ks200_ticker, period)
futures = load_data(futures_ticker, period)
inverse = load_data(inverse_ticker, period)

st.title("📊 KOSPI Market Decision Engine")
st.caption("현물 + 선물 + 인버스 + 변동성 + 괴리율 기반 의사결정 보조 시스템")

if ks200.empty:
    st.error(
        "KOSPI200 현물 데이터를 불러오지 못했습니다. "
        "사이드바의 티커를 확인하세요."
    )
    st.stop()

# ---------------- Main model ----------------
spot_levels = make_levels(ks200)
spot_score, spot_conf, spot_direction = directional_score(ks200)

fut_score = fut_conf = 0.0
fut_direction = "데이터 없음"
if not futures.empty:
    fut_score, fut_conf, fut_direction = directional_score(futures)

spot = spot_levels["close"]
future = float(futures["Close"].iloc[-1]) if not futures.empty else np.nan

basis = np.nan
basis_z = 0.0
if not np.isnan(future) and spot != 0:
    basis = (future - spot) / spot * 100

    basis_series = (
        futures["Close"].reindex(ks200.index).ffill() - ks200["Close"]
    ) / ks200["Close"] * 100
    basis_z_series = zscore(basis_series, 60).dropna()
    if not basis_z_series.empty:
        basis_z = float(basis_z_series.iloc[-1])

# 현물/선물 합성 방향
if not futures.empty:
    composite_score = 0.65 * spot_score + 0.35 * fut_score
    composite_conf = min(
        100,
        0.65 * spot_conf + 0.35 * fut_conf
    )
else:
    composite_score = spot_score
    composite_conf = spot_conf

regime = regime_text(composite_score, composite_conf)
level = position_level(composite_score, composite_conf, basis_z)

# ---------------- Header cards ----------------
c1, c2, c3, c4, c5 = st.columns(5)

c1.metric(
    "KOSPI200",
    f"{spot:,.2f}",
    f"{pct_change(ks200).iloc[-1]:+.2f}%"
)
if not futures.empty:
    c2.metric(
        "선물",
        f"{future:,.2f}",
        f"{pct_change(futures).iloc[-1]:+.2f}%"
    )
else:
    c2.metric("선물", "N/A")

c3.metric("방향 점수", f"{composite_score:+.1f}")
c4.metric("신뢰도", f"{composite_conf:.0f}%")
c5.metric("헤지/인버스 레벨", f"{level}%")

st.divider()

# ---------------- Decision ----------------
left, right = st.columns([1, 1])

with left:
    st.subheader("🎯 현재 판단")
    st.markdown(f"### {regime}")
    st.write(f"**방향:** {spot_direction}")
    st.write(f"**종합 점수:** `{composite_score:+.1f} / 100`")
    st.write(f"**신뢰도:** `{composite_conf:.0f}%`")
    st.write(f"**권장 헤지/인버스 단계:** `{level}%`")

    if composite_score <= -45:
        st.warning(
            "하방 위험이 높은 구간입니다. "
            "단일 진입보다 분할 대응을 우선하세요."
        )
    elif composite_score >= 45:
        st.success(
            "상승 추세 우세입니다. "
            "과도한 헤지는 줄이고 추세 추종 여부를 검토하세요."
        )
    else:
        st.info("신호가 혼조입니다. 신규 포지션은 보수적으로 접근하세요.")

with right:
    st.subheader("📐 현·선물 괴리")
    if not np.isnan(basis):
        st.metric("Basis", f"{basis:+.3f}%")
        st.write(f"Basis Z-score: `{basis_z:+.2f}`")

        if abs(basis_z) >= 2:
            st.error("괴리 극단: 방향 신호의 신뢰도를 할인하는 구간")
        elif abs(basis_z) >= 1.5:
            st.warning("괴리 확대: 추격 진입 주의")
        else:
            st.success("괴리 정상 범위")
    else:
        st.info("선물 데이터가 없어 Basis를 계산하지 못했습니다.")

# ---------------- Bands ----------------
st.divider()
st.subheader("📏 KOSPI200 동적 밴드")

b1, b2, b3, b4, b5 = st.columns(5)
b1.metric("60일 저점", f"{spot_levels['low60']:,.2f}")
b2.metric("지지선", f"{spot_levels['support']:,.2f}")
b3.metric("현재", f"{spot_levels['close']:,.2f}")
b4.metric("저항선", f"{spot_levels['resistance']:,.2f}")
b5.metric("60일 고점", f"{spot_levels['high60']:,.2f}")

st.write(
    f"MA20 `{spot_levels['ma20']:,.2f}` · "
    f"MA60 `{spot_levels['ma60']:,.2f}` · "
    f"ATR14 `{spot_levels['atr']:,.2f}`"
)

# ---------------- Chart ----------------
chart_df = ks200[["Close"]].copy()
chart_df["MA20"] = chart_df["Close"].rolling(20).mean()
chart_df["MA60"] = chart_df["Close"].rolling(60).mean()
chart_df = chart_df.tail(180)

st.line_chart(chart_df)

# ---------------- Detailed data ----------------
with st.expander("🔎 상세 분석"):
    rows = {
        "현물 방향 점수": spot_score,
        "현물 신뢰도": spot_conf,
        "선물 방향 점수": fut_score,
        "선물 신뢰도": fut_conf,
        "Basis %": basis,
        "Basis Z": basis_z,
        "권장 헤지/인버스": level,
    }
    st.dataframe(
        pd.DataFrame(rows, index=["값"]).T,
        use_container_width=True,
    )

# ---------------- Inverse ----------------
if not inverse.empty:
    st.divider()
    st.subheader("🔄 인버스 ETF 상태")
    inv_price = float(inverse["Close"].iloc[-1])
    inv_ret = float(pct_change(inverse).iloc[-1])

    i1, i2 = st.columns(2)
    i1.metric("인버스 가격", f"{inv_price:,.2f}")
    i2.metric("일간 수익률", f"{inv_ret:+.2f}%")

    st.caption(
        "인버스 상품은 기초자산의 일일 수익률을 반대로 추종하도록 "
        "설계된 상품이므로 장기 누적 성과는 단순 -1배와 다를 수 있습니다."
    )

st.divider()
st.caption(
    "⚠️ 본 프로그램은 투자 판단 보조용입니다. "
    "수익을 보장하지 않으며 실시간 주문/매매 기능은 포함하지 않습니다."
)
