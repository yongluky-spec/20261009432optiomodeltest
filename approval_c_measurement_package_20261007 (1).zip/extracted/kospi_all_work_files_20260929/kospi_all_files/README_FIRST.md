KOSPI / UME 작업 파일 묶음

01_kospi_model/
- kospi_model.py : 원래 만들던 KOSPI Market Decision Engine
- requirements.txt : 해당 모델 실행용 기본 의존성

02_ume_collectors/
- ume_v1.1_collectors_260928.zip : 현재 데이터 수집 모듈 원본

03_breeden_litzenberger/
- src/breeden_litzenberger_v1.py : BL 엔진 작업본
- tests/bl_synthetic_validation_v1.py : BL 합성 검증 작업본

04_previous_monitoring_test/
- ume_v1.1_monitoring_test_v0.1.zip : 이전에 앞서 만들어진 감시 테스트. 현재 작업 순서에서는 보류/참조용.

현재 작업 순서
1. 원래 KOSPI 모델을 기준으로 작업을 이어간다.
2. UME 데이터 수집 모듈은 별도 모듈로 유지한다.
3. 데이터 수집 실행을 쉽게 만드는 작업을 먼저 한다.
4. 이후 기존 감시 대시보드와 연결한다.
5. 그 다음 감시 기능(전 데이터↔현 데이터 변경 비교 + 검증 + 신뢰도)을 붙인다.

주의
- KRX ID/PW 등 실제 자격증명은 넣지 않았습니다.
- 기존 작업본을 보존하는 것을 우선했습니다.
