breeden_litzenberger_v1.py
BL(Breeden-Litzenberger) 엔진 v1
- 콜가격 곡선 평활 -> 스플라인 2차 미분 -> 위험중립 밀도 q(K) = e^{rT} * d2C/dK2
- 단조성/볼록성 검사도 동일한 스플라인 경로에서 수행 (계산 경로 일관성)
- 상·하방 질량 기준은 선도(forward) F 기준으로 통일
- 기준점 F가 격자 위에 없을 경우 밀도 보간으로 경계 처리
- 만기 임박: 경고(WARN) / 사용 중단(STOP) 2단계. 임계는 ④ 결과 후 확정(그 전 None)

승인된 설계 반영:
  1) 정렬된 K·C를 모든 검증에 동일 전달
  2) 단조성·볼록성은 스플라인 1·2차 도함수로 검사
  3) 기준점 F 질량은 밀도 보간으로 정확히 분할
  4) 중복 K, NaN, 유한값, 최소 개수, 음수 가격, T<=0 입력 검증
  5) 평활 강도 smoothing_s 파라미터 (None=보간, float=평활 스플라인). 고정 s 사용 안 함
"""

from dataclasses import dataclass, field
import numpy as np
from scipy.interpolate import CubicSpline, UnivariateSpline


@dataclass
class BLResult:
    strikes: np.ndarray
    density: np.ndarray
    integral: float
    neg_density_ratio: float
    monotonic_violations: int
    convexity_violations: int
    downside_mass: float
    upside_mass: float
    clipped_negative: bool
    status: str
    warnings: list = field(default_factory=list)

    @property
    def valid(self) -> bool:
        return self.status == "OK" and not self.warnings


def _validate_inputs(strikes, call_prices, T, forward):
    k = np.asarray(strikes, dtype=float)
    c = np.asarray(call_prices, dtype=float)
    if k.ndim != 1 or c.ndim != 1 or k.shape != c.shape:
        raise ValueError("strikes/call_prices는 같은 길이의 1차원 배열이어야 합니다.")
    if len(k) < 5:
        raise ValueError("행사가 격자는 5점 이상이어야 합니다.")
    if not (np.all(np.isfinite(k)) and np.all(np.isfinite(c))):
        raise ValueError("NaN 또는 비유한 값이 있습니다.")
    if not np.isfinite(forward) or forward <= 0:
        raise ValueError("forward는 양의 유한 값이어야 합니다.")
    if T <= 0:
        raise ValueError("T는 양수여야 합니다.")


def bl_density(strikes, call_prices, forward, T, r=0.0,
              smoothing_s=None, warn_T=None, stop_T=None) -> BLResult:
    """q(K) = e^{rT} * d2C/dK2. forward=상·하방 질량 기준(선도 F)."""
    _validate_inputs(strikes, call_prices, T, forward)

    order = np.argsort(strikes)
    k = np.asarray(strikes, dtype=float)[order]
    c = np.asarray(call_prices, dtype=float)[order]  # 정렬된 K·C를 모든 검증에 동일 사용
    if np.any(np.diff(k) <= 0):
        raise ValueError("행사가 중복이 존재합니다.")
    if np.any(c < -1e-12):
        raise ValueError("콜 가격에 음수가 있습니다.")

    warnings, status = [], "OK"
    if stop_T is not None and T < stop_T:
        status = "STOP"
        warnings.append(f"만기 임박 사용 중단: T={T:.5f} < stop_T={stop_T}")
    elif warn_T is not None and T < warn_T:
        status = "WARN"
        warnings.append(f"만기 임박 경고: T={T:.5f} < warn_T={warn_T}")

    # 단일 계산 경로: 스플라인 -> 1·2차 미분 -> 단조성/볼록성/밀도
    if smoothing_s is None:
        spline = CubicSpline(k, c)
        d1 = spline(k, 1)
        d2 = spline(k, 2)
    else:
        spline = UnivariateSpline(k, c, s=smoothing_s, k=3)
        d1 = spline.derivative(1)(k)
        d2 = spline.derivative(2)(k)
    q = np.exp(r * T) * d2

    tol = 1e-12
    monotonic_violations = int(np.sum(d1 > tol))
    neg_ratio = float(np.mean(q < 0))
    convexity_violations = int(np.sum(d2 < -tol))
    integral = float(np.trapezoid(q, k))
    if neg_ratio > 0:
        warnings.append(f"음수 밀도 비율 {neg_ratio:.4f}")

    # 상·하방 질량: F 기준, 경계 보간
    q_pos = np.clip(q, 0.0, None)
    clipped_negative = bool(np.any(q < 0))
    if k[0] <= forward <= k[-1]:
        q_spline = CubicSpline(k, q_pos)
        grid_lo = np.concatenate([k[k <= forward], [forward]])
        grid_hi = np.concatenate([[forward], k[k > forward]])
        downside_mass = float(np.trapezoid(q_spline(grid_lo), grid_lo))
        upside_mass = float(np.trapezoid(q_spline(grid_hi), grid_hi))
    else:
        warnings.append(f"forward={forward}가 격자 [{k[0]:.2f},{k[-1]:.2f}] 밖. 질량 신뢰도 저하")
        below = k <= forward
        downside_mass = float(np.trapezoid(q_pos[below], k[below])) if below.any() else 0.0
        upside_mass = float(np.trapezoid(q_pos[~below], k[~below])) if (~below).any() else 0.0

    return BLResult(k, q, integral, neg_ratio,
                    monotonic_violations, convexity_violations,
                    downside_mass, upside_mass, clipped_negative,
                    status, warnings)
