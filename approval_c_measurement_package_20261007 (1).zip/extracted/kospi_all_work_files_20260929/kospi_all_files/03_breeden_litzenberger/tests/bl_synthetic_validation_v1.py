bl_synthetic_validation_v1.py
B단계 BL 합성 검증 — breeden_litzenberger_v1.py와 짝.

승인된 설계:
  ① 무잡음: 정규화TV<=0.02, 질량오차<=0.01, 음수밀도 확인
  ② 노이즈: 노이즈 수준 x 평활 강도 s 스윕, OTM-only vs 전체 비교, 호가 반올림 포함
  ③ 범위·격자: 고정 0.98 PASS/FAIL 폐지, 참 질량>=0.98 최소 범위 탐색, 꼬리 손실·정규화TV 기록
  ④ 만기: T별 동일 지표 측정, 최초 붕괴 T 탐색 -> T_warning/T_disable 후보. 고정 임계 미적용
  정규화 TV: 공통 절단 구간에서 각자의 구간 질량으로 정규화 후 0.5*∫|q̂-q|dK

한계: 참값은 로그정규 1개. 구현·노이즈 내성까지만 입증.
시장 분포 예측력은 C단계. 출력: 콘솔만.
"""

import sys
from pathlib import Path

import numpy as np
from scipy.stats import norm

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.breeden_litzenberger_v1 import bl_density


def bs_call(S, K, r, T, sigma):
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    return S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)


def bs_put(S, K, r, T, sigma):
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    return K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)


def lognormal_pdf(S, K, r, T, sigma):
    sT = sigma * np.sqrt(T)
    x = (np.log(K / S) - (r - 0.5 * sigma**2) * T) / sT
    return np.exp(-0.5 * x**2) / (K * sT * np.sqrt(2 * np.pi))


def normalized_tv(k, q_hat, q_true):
    """공통 절단 구간 질량으로 각자 정규화한 뒤 0.5*∫|q̂-q|."""
    m_t = float(np.trapezoid(q_true, k))
    m_h = float(np.trapezoid(q_hat, k))
    if m_t <= 0 or m_h <= 0:
        return float("inf")
    qh = np.clip(q_hat, 0, None) / m_h
    qt = np.clip(q_true, 0, None) / m_t
    return 0.5 * float(np.trapezoid(np.abs(qh - qt), k))


def true_masses(k, q_true, F):
    """같은 절단 구간의 참 하방/상방 질량 (F 경계 보간 포함)."""
    below = k <= F
    if k[0] < F < k[-1]:
        g_lo = np.concatenate([k[below], [F]])
        g_hi = np.concatenate([[F], k[~below]])
        lo = float(np.trapezoid(np.interp(g_lo, k, q_true), g_lo))
        hi = float(np.trapezoid(np.interp(g_hi, k, q_true), g_hi))
    else:
        lo = float(np.trapezoid(q_true[below], k[below])) if below.any() else 0.0
        hi = float(np.trapezoid(q_true[~below], k[~below])) if (~below).any() else 0.0
    return lo, hi


def print_row(tag, m, crit):
    ok = all(m[key] <= lim for key, lim in crit.items())
    parts = " ".join(f"{k}={v:.4f}" if isinstance(v, float) else f"{k}={v}"
                     for k, v in m.items())
    print(f"  [{tag}] {parts} -> {'PASS' if ok else 'FAIL'}")


# ① 무잡음 복원
def test1(S=250.0, r=0.03, sigma=0.25):
    print("① 무잡음 복원 (잠정: 정규화TV<=0.02, 질량오차<=0.01, 위반=0)")
    for T in (0.25, 0.5):
        k = np.linspace(S * 0.5, S * 2.0, 161)
        c = bs_call(S, k, r, T, sigma)
        F = S * np.exp(r * T)
        q_true = lognormal_pdf(S, k, r, T, sigma)
        res = bl_density(k, c, forward=F, T=T, r=r)
        lo_t, hi_t = true_masses(k, q_true, F)
        m = {"정규화TV": normalized_tv(k, res.density, q_true),
             "구간질량오차": abs(res.integral - float(np.trapezoid(q_true, k))),
             "음수밀도": res.neg_density_ratio,
             "하방오차": abs(res.downside_mass - lo_t),
             "상방오차": abs(res.upside_mass - hi_t),
             "단조위반": res.monotonic_violations,
             "볼록위반": res.convexity_violations}
        print_row(f"T={T}", m, {"정규화TV": 0.02, "구간질량오차": 0.01,
                                "하방오차": 0.01, "상방오차": 0.01,
                                "음수밀도": 0.0, "단조위반": 0, "볼록위반": 0})


# ② 노이즈 강건성 (노이즈 x s 격자 스윕)
def test2(S=250.0, r=0.03, sigma=0.25, T=0.25, seed=7):
    print("② 노이즈 강건성 (잠정: 정규화TV<=0.05, 음수밀도=0)")
    rng = np.random.default_rng(seed)
    k = np.linspace(S * 0.7, S * 1.3, 61)
    F = S * np.exp(r * T)
    q_true = lognormal_pdf(S, k, r, T, sigma)
    c0 = bs_call(S, k, r, T, sigma)
    p0 = bs_put(S, k, r, T, sigma)
    n = len(k)
    s_cand = [0.0, n * 0.01**2, n * 0.05**2, n * 0.1**2]  # 고정 s 아님: 자유도 기반 스윕

    for eps in (0.001, 0.005, 0.01):
        otm = np.where(k < F, p0, c0)
        noisy = np.round(otm * (1 + rng.uniform(-eps, eps, size=k.shape)), 2)
        calls_otm = np.where(k < F, noisy + (F - k) * np.exp(-r * T), noisy)
        calls_all = np.round(c0 * (1 + rng.uniform(-eps, eps, size=k.shape)), 2)
        for tag, prices in (("OTM환산", calls_otm), ("전체콜", calls_all)):
            for s in s_cand:
                res = bl_density(k, prices, forward=F, T=T, r=r,
                                 smoothing_s=(None if s == 0.0 else s))
                m = {"정규화TV": normalized_tv(k, res.density, q_true),
                     "음수밀도": res.neg_density_ratio,
                     "볼록위반": res.convexity_violations}
                print_row(f"noise={eps:.3f}/{tag}/s={s:.2f}", m,
                          {"정규화TV": 0.05, "음수밀도": 0.0})


# ③ 범위·격자 민감도 (최소 커버리지 탐색)
def test3(S=250.0, r=0.03, sigma=0.25, T=0.25):
    print("③ 범위·격자 민감도 — 참 질량>=0.98 최소 범위 탐색")
    F = S * np.exp(r * T)
    print(f"  {'범위':>10} {'n':>4} {'참절단질량':>10} {'복원적분':>9} {'꼬리손실':>8} {'정규화TV':>9}")
    min_cover = None
    for width, n in [(1.15, 41), (1.3, 61), (1.5, 61), (2.0, 81), (3.0, 101), (4.0, 121)]:
        k = np.linspace(S / width, S * width, n)
        c = bs_call(S, k, r, T, sigma)
        q_true = lognormal_pdf(S, k, r, T, sigma)
        res = bl_density(k, c, forward=F, T=T, r=r)
        true_m = float(np.trapezoid(q_true, k))
        tail = max(0.0, true_m - res.integral)
        flag = ""
        if min_cover is None and true_m >= 0.98:
            min_cover = width
            flag = "  <- 98% 달성 최소 범위"
        print(f"  ±{width:>5}x {n:>4} {true_m:>10.4f} {res.integral:>9.4f} {tail:>8.4f} "
              f"{normalized_tv(k, res.density, q_true):>9.4f}{flag}")
    print("  -> 최소 범위 이상에서 ① 기준 정규화TV 만족 여부 확인" if min_cover
          else "  -> 98% 미달: 더 넓은 행사가 필요 (경고)")


# ④ 만기 임박 (붕괴 T 탐색)
def test4(S=250.0, r=0.03, sigma=0.25, seed=11):
    print("④ 만기 임박 — T별 지표, 최초 붕괴 T -> T_warning/T_disable 후보")
    rng = np.random.default_rng(seed)
    ts = [0.5, 0.25, 0.1, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001]
    breakdown = None
    for T in ts:
        F = S * np.exp(r * T)
        k = np.linspace(S * 0.85, S * 1.15, 61)
        c = np.round(bs_call(S, k, r, T, sigma) * (1 + rng.uniform(-0.005, 0.005, size=k.shape)), 2)
        q_true = lognormal_pdf(S, k, r, T, sigma)
        try:
            res = bl_density(k, c, forward=F, T=T, r=r)
        except ValueError as e:
            print(f"  T={T:<7} 오류: {e}")
            breakdown = breakdown or T
            continue
        true_m = float(np.trapezoid(q_true, k))
        integ_err = abs(res.integral - true_m)
        ok = res.neg_density_ratio == 0.0 and integ_err <= 0.02
        print(f"  T={T:<7} 정규화TV={normalized_tv(k, res.density, q_true):.4f} "
              f"음수밀도={res.neg_density_ratio:.3f} 적분오차={integ_err:.4f} "
              f"볼록위반={res.convexity_violations} {'OK' if ok else 'FAIL'}")
        if not ok and breakdown is None:
            breakdown = T
    if breakdown is not None:
        print(f"  -> 후보: T_disable={breakdown:.4f}(년), T_warning=2x={breakdown*2:.4f}(년). ①~③ 재확인 후 확정")
    else:
        print("  -> 붕괴 없음: T_warning/T_disable 미제안(None 유지)")


if __name__ == "__main__":
    print("=" * 64)
    print("B단계 BL 합성 검증 v1 (콘솔 출력 전용)")
    print("=" * 64)
    test1()
    test2()
    test3()
