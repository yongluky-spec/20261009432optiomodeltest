"""수집기 공통 도구 — 여러 프로그램이 동시에 수집해도 충돌하지 않게 하는 부분.

충돌 방지 3가지:
  1) 캐시/상태 파일은 임시파일(프로세스별 고유 이름)에 쓴 뒤 os.replace로 교체 (원자적 쓰기)
  2) 호스트별 요청 간격을 '프로세스 간 공유'로 지킨다 (락 파일 + 마지막 요청 시각 파일)
  3) 경로는 cwd 기준이 아니라 절대경로(프로젝트 루트/04_data) 또는 환경변수로 고정
"""
import json
import os
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

# 프로젝트 루트 = 02_engine 의 상위 폴더 (패키지가 다른 곳에 있으면 환경변수로 지정)
_DEFAULT_ROOT = Path(__file__).resolve().parents[3]
DATA_ROOT = Path(os.environ.get("UME_DATA_DIR", _DEFAULT_ROOT / "04_data"))
STATE_DIR = Path(os.environ.get("UME_STATE_DIR", DATA_ROOT / "collector_state"))

USER_AGENT = "Mozilla/5.0 (UME collector)"


class ProviderError(Exception):
    """수집 실패. kind: config / unsupported / http / network / parse / empty"""

    def __init__(self, message: str, kind: str = "network"):
        super().__init__(message)
        self.kind = kind


# ── 원자적 파일 쓰기 ──────────────────────────────────────
def atomic_write_text(path: Path, text: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.{os.getpid()}.{uuid.uuid4().hex[:8]}.tmp")
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


# ── 프로세스 간 파일 락 ───────────────────────────────────
class FileLock:
    """O_EXCL 락 파일 (Windows/Linux 공통). 오래된 락(stale)은 자동 제거."""

    def __init__(self, path: Path, timeout: float = 30.0, stale: float = 60.0):
        self.path = Path(path)
        self.timeout = timeout
        self.stale = stale
        self._fd: Optional[int] = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        deadline = time.time() + self.timeout
        while True:
            try:
                self._fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(self._fd, str(os.getpid()).encode())
                return self
            except FileExistsError:
                try:
                    if time.time() - self.path.stat().st_mtime > self.stale:
                        self.path.unlink()
                        continue
                except OSError:
                    continue
                if time.time() > deadline:
                    raise TimeoutError(f"락 획득 시간 초과: {self.path}")
                time.sleep(0.05)

    def __exit__(self, *exc):
        if self._fd is not None:
            os.close(self._fd)
            self._fd = None
        try:
            self.path.unlink()
        except OSError:
            pass


def throttle(key: str, min_interval: float) -> None:
    """같은 key(호스트)로 나가는 요청 사이에 min_interval초를 보장한다 (프로세스 간 공유)."""
    if min_interval <= 0:
        return
    lock = STATE_DIR / f".{key}.lock"
    stamp = STATE_DIR / f".{key}.ts"
    try:
        with FileLock(lock, timeout=60.0):
            try:
                last = float(stamp.read_text().strip())
            except (OSError, ValueError):
                last = 0.0
            wait = last + min_interval - time.time()
            if wait > 0:
                time.sleep(wait)
            atomic_write_text(stamp, repr(time.time()))
    except TimeoutError:
        # 락을 못 잡아도 수집이 멈추면 안 된다 → 이 프로세스 안에서만 간격 유지
        time.sleep(min_interval)


# ── HTTP ─────────────────────────────────────────────────
def http_get_json(url: str, *, headers: Optional[Dict[str, str]] = None,
                  params: Optional[Dict[str, Any]] = None, timeout: float = 15.0,
                  retries: int = 2, backoff: float = 1.0,
                  throttle_key: Optional[str] = None,
                  min_interval: float = 0.0) -> Any:
    """GET → JSON. 일시 오류(네트워크/5xx/429)만 재시도, 4xx(인증 등)는 즉시 실패."""
    full = f"{url}?{urlencode(params)}" if params else url
    hdrs = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    hdrs.update(headers or {})
    last_exc: Optional[ProviderError] = None
    for attempt in range(retries + 1):
        if throttle_key:
            throttle(throttle_key, min_interval)
        try:
            with urlopen(Request(full, headers=hdrs), timeout=timeout) as resp:
                raw = resp.read()
            try:
                return json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeDecodeError) as exc:
                raise ProviderError(f"JSON 파싱 실패: {exc}", "parse")
        except HTTPError as exc:
            body = ""
            try:
                body = exc.read().decode("utf-8", "replace")[:160]
            except Exception:
                pass
            err = ProviderError(f"HTTP {exc.code}: {body}", "http")
            if exc.code not in (429, 500, 502, 503, 504):
                raise err  # 401/403/404 등은 재시도해도 소용없다
            last_exc = err
        except (URLError, TimeoutError, OSError) as exc:
            last_exc = ProviderError(f"네트워크 오류: {exc}", "network")
        if attempt < retries:
            time.sleep(backoff * (2 ** attempt))
    raise last_exc  # type: ignore[misc]


def to_num(v: Any) -> Optional[float]:
    if v in (None, "", "-"):
        return None
    try:
        return float(str(v).replace(",", "").strip())
    except (TypeError, ValueError):
        return None
