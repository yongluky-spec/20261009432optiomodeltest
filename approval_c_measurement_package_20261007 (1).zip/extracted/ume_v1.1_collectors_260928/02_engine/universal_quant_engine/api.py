"""Market / MarketEngine — 외부 프로그램용 최상위 API.

사용법:
    from universal_quant_engine import Market
    market = Market(providers=["mock"])
    data = market.market("KOSPI")
    indicators = market.analyze(data)
    report = market.verify("KOSPI")
    reliability = market.reliability_report("KOSPI")
"""
import pandas as pd
from typing import Dict, List, Optional

from .core.interfaces import MarketDataProvider, Strategy
from .core.registry import ProviderRegistry
from .collectors.mock_provider import MockProvider
from .collectors.krx_provider import KrxOpenApiProvider
from .collectors.naver_provider import NaverProvider
from .collectors.yahoo_provider import YahooProvider
from .normalization.normalizer import Normalizer
from .validation.data_quality import DataValidator
from .validation.cross_source import CrossSourceVerifier
from .reliability.engine import ReliabilityEngine
from .indicators.indicators import IndicatorEngine
from .backtest.engine import BacktestEngine, BrokerConfig
from .core.models import ReliabilityReport


LIVE_PROVIDERS = ["krx", "naver", "yahoo"]  # 실수집 폴백 순서


class MarketEngine:
    """fetch_mode:
         "all"      — 모든 Provider를 조회해 원천 간 교차검증에 사용 (기본, Mock/테스트용)
         "fallback" — 앞 순서 Provider가 성공하면 거기서 멈춤 (실수집 권장: 요청 수 최소화)
    """

    def __init__(self, providers: Optional[List[str]] = None,
                 provider_kwargs: Optional[dict] = None,
                 fetch_mode: str = "all"):
        if fetch_mode not in ("all", "fallback"):
            raise ValueError("fetch_mode 는 'all' 또는 'fallback'")
        self.fetch_mode = fetch_mode
        self.last_report: dict = {}
        self.registry = ProviderRegistry()
        self.registry.register(MockProvider)  # 기본 Mock (테스트/구조 검증용)
        self.registry.register(KrxOpenApiProvider)
        self.registry.register(NaverProvider)
        self.registry.register(YahooProvider)
        # → LS Xing, 키움, 한투 등은 추후 register로 추가
        self.provider_kwargs = provider_kwargs or {}
        self.providers: Dict[str, MarketDataProvider] = {
            name: self.registry.create(name, **self.provider_kwargs.get(name, {}))
            for name in (providers or ["mock"])
        }
        self.normalizer = Normalizer()
        self.validator = DataValidator()
        self.cross_verifier = CrossSourceVerifier()
        self.reliability = ReliabilityEngine()
        self.indicator_engine = IndicatorEngine()
        self._cache: Dict[str, pd.DataFrame] = {}
        self._frames_cache: Dict[str, pd.DataFrame] = {}

    # ── DATA ─────────────────────────────────────────────
    def market(self, symbol: str, timeframe: str = "1d", count: int = 200) -> pd.DataFrame:
        """Provider → Raw → Normalize → 표준 DataFrame.
        빈 결과도 실패로 취급한다. 성공/실패 내역은 self.last_report 에 남긴다.
        fetch_mode="fallback"이면 첫 성공 소스에서 멈춘다. 전부 실패하면 예외."""
        errors, frames, skipped = {}, {}, {}
        for name, provider in self.providers.items():
            try:
                bars = provider.get_bars(symbol, timeframe, count)
                frame = self.normalizer.normalize_bars(bars)
                if frame.empty:
                    raise RuntimeError("빈 데이터")
                frames[name] = frame
            except Exception as e:
                kind = getattr(e, "kind", "")
                (skipped if kind == "unsupported" else errors)[name] = f"{type(e).__name__}: {e}"
                continue
            if self.fetch_mode == "fallback":
                break
        self.last_report = {
            "symbol": symbol, "mode": self.fetch_mode, "used": list(frames),
            "errors": errors, "skipped": skipped,
            "status": {n: getattr(p, "last_status", None) for n, p in self.providers.items()},
        }
        if not frames:
            raise RuntimeError(f"모든 Provider 실패. 데이터 없음. errors={errors} skipped={skipped}")
        primary = next(iter(frames.values()))
        self._cache[symbol] = primary
        self._frames_cache = frames
        return primary

    def get_all_sources(self) -> Dict[str, pd.DataFrame]:
        return self._frames_cache

    # ── ANALYSIS ──────────────────────────────────────────
    def analyze(self, data: pd.DataFrame, indicators: Optional[List[str]] = None) -> pd.DataFrame:
        return self.indicator_engine.compute_all(data, names=indicators)

    # ── VERIFY / RELIABILITY ──────────────────────────────
    def verify(self, symbol: str, data: Optional[pd.DataFrame] = None) -> dict:
        data = data if data is not None else self._cache.get(symbol)
        if data is None:
            raise ValueError(f"'{symbol}' 데이터 없음. market()을 먼저 호출하세요.")
        validation = self.validator.validate(data)
        frames = self._frames_cache
        cross = (self.cross_verifier.compare_closes(frames)
                 if len(frames) >= 2 else {"agreement": 1.0})
        return {"validation": validation, "cross_source": cross,
                "ohlc_table": self.cross_verifier.ohlc_table(frames)}

    def reliability_report(self, symbol: str,
                           data: Optional[pd.DataFrame] = None) -> ReliabilityReport:
        data = data if data is not None else self._cache.get(symbol)
        if data is None:
            raise ValueError(f"'{symbol}' 데이터 없음.")
        frames = self._frames_cache
        cross = (self.cross_verifier.compare_closes(frames)
                 if len(frames) >= 2 else {"agreement": 1.0})
        source = data["source"].iloc[0] if "source" in data else "unknown"
        report = self.reliability.build_report(
            source, data, validation=self.validator.validate(data),
            cross_agreement=cross.get("agreement", 1.0))
        report.checks["overall_score"] = ReliabilityEngine.overall_score(report)
        return report

    # ── BACKTEST ──────────────────────────────────────────
    def backtest(self, data: pd.DataFrame, strategy: Strategy,
                 config: Optional[BrokerConfig] = None) -> dict:
        return BacktestEngine(config).run(data, strategy)


# 짧은 별칭
Market = MarketEngine
