"""수집기 테스트 — 실제 인터넷 없이 가짜 HTTP 응답으로 동작을 검증한다.

실행:  cd 02_engine && python -m universal_quant_engine.tests.test_collectors_v1
※ 실제 사이트 연결 확인은 examples/smoke_test_live.py 로 (인터넷·KRX 키 필요)
"""
import json
import multiprocessing as mp
import os
import sys
import tempfile
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.error import HTTPError, URLError

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))

_TMP = tempfile.mkdtemp(prefix="ume_test_")
os.environ["UME_STATE_DIR"] = os.path.join(_TMP, "state")
os.environ["UME_DATA_DIR"] = os.path.join(_TMP, "data")

from universal_quant_engine import Market  # noqa: E402
from universal_quant_engine.collectors import _common  # noqa: E402
from universal_quant_engine.collectors import krx_provider, naver_provider, yahoo_provider  # noqa: E402
from universal_quant_engine.collectors._common import ProviderError  # noqa: E402


class FakeResp:
    def __init__(self, obj):
        self._raw = json.dumps(obj).encode("utf-8")

    def read(self):
        return self._raw

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def install_fake(handler):
    """handler(url, headers) -> obj 또는 예외. 호출 URL 목록을 반환."""
    calls = []

    def fake_urlopen(req, timeout=None):
        calls.append(req.full_url)
        out = handler(req.full_url, dict(req.header_items()))
        if isinstance(out, Exception):
            raise out
        return FakeResp(out)

    _common.urlopen = fake_urlopen
    return calls


def krx_handler(url, headers):
    d = url.split("basDd=")[1][:8]
    day = datetime.strptime(d, "%Y%m%d").date()
    if headers.get("Auth_key") != "KEY123":
        return HTTPError(url, 401, "unauthorized", {}, None)
    if day.weekday() >= 5:
        return {"OutBlock_1": []}
    base = 2500 + day.toordinal() % 50
    return {"OutBlock_1": [
        {"IDX_NM": "코스피 200", "OPNPRC_IDX": "300", "HGPRC_IDX": "310", "LWPRC_IDX": "290",
         "CLSPRC_IDX": "305", "ACC_TRDVOL": "1,000"},
        {"IDX_NM": "코스피", "OPNPRC_IDX": f"{base}.10", "HGPRC_IDX": f"{base + 10}.50",
         "LWPRC_IDX": f"{base - 10}.00", "CLSPRC_IDX": f"{base + 5}.20", "ACC_TRDVOL": "400,123"}]}


def run():
    results = []

    def check(name, cond):
        results.append(bool(cond))
        print(f"{'PASS' if cond else 'FAIL'} - {name}")

    # 테스트에서는 대기 시간을 없앤다
    kw_fast = {"krx": {"auth_key": "KEY123", "request_interval": 0,
                       "cache_dir": os.path.join(_TMP, "krx_cache")}}

    # ① KRX: 파싱 + 필요한 만큼만 요청
    calls = install_fake(krx_handler)
    m = Market(providers=["krx"], provider_kwargs=kw_fast)
    df = m.market("KOSPI", count=10)
    check("KRX 10봉 수집·표준 컬럼", len(df) == 10 and list(df.columns[:2]) == ["source", "timestamp"])
    check("KRX 코스피200 행과 섞이지 않음(코스피 값 사용)", df["close"].iloc[-1] > 2000)
    check("KRX 요청 수가 필요한 만큼만(<=20)", len(calls) <= 20)
    check("KRX 표준 검증 통과", m.validator.validate(df)["passed"])

    # ② KRX: 캐시 재사용 (두 번째는 네트워크 거의 0)
    before = len(calls)
    Market(providers=["krx"], provider_kwargs=kw_fast).market("KOSPI", count=10)
    check("KRX 캐시 재사용 (신규 요청 <=2, 오늘/어제 미캐시분만)", len(calls) - before <= 2)

    # ③ KRX: 인증키 오류는 즉시 중단 (하루씩 260번 반복 안 함)
    calls = install_fake(krx_handler)
    bad = Market(providers=["krx"], provider_kwargs={"krx": {
        "auth_key": "WRONG", "request_interval": 0, "cache_dir": os.path.join(_TMP, "c2")}})
    try:
        bad.market("KOSPI", count=50)
        ok = False
    except RuntimeError:
        ok = True
    check("KRX 인증 실패 시 1~2회 요청 후 즉시 중단", ok and len(calls) <= 2)

    # ④ KRX: 키 없음
    os.environ.pop("KRX_AUTH_KEY", None)
    m2 = Market(providers=["krx"], provider_kwargs={"krx": {"cache_dir": os.path.join(_TMP, "c3")}})
    try:
        m2.market("KOSPI", count=5)
        ok = False
    except RuntimeError as e:
        ok = "config" in str(e) or "AUTH_KEY" in str(e)
    check("KRX 키 없음 → 원인 메시지 포함 실패", ok)

    # ⑤ 네이버 파싱
    naver_rows = [{"localDate": (date(2026, 9, 1) + timedelta(days=i)).strftime("%Y%m%d"),
                   "openPrice": 2500 + i, "highPrice": 2520 + i, "lowPrice": 2490 + i,
                   "closePrice": 2510 + i, "accumulatedTradingVolume": 1000 + i} for i in range(30)]
    install_fake(lambda u, h: {"priceInfos": naver_rows})
    nv = Market(providers=["naver"], provider_kwargs={"naver": {"request_interval": 0}}).market("KOSPI", count=20)
    check("네이버 20봉 파싱·정렬", len(nv) == 20 and nv["timestamp"].is_monotonic_increasing)

    # ⑥ 야후 파싱 (null 봉 건너뛰기)
    t0 = int(datetime(2026, 9, 1, 0, 0).timestamp())
    ts = [t0 + 86400 * i for i in range(10)]
    yq = {"open": [2500.0 + i for i in range(10)], "high": [2520.0 + i for i in range(10)],
          "low": [2490.0 + i for i in range(10)], "close": [2510.0 + i for i in range(10)],
          "volume": [1000] * 10}
    for k in yq:
        yq[k][3] = None
    install_fake(lambda u, h: {"chart": {"result": [{"meta": {"gmtoffset": 32400},
                                                     "timestamp": ts, "indicators": {"quote": [yq]}}],
                                         "error": None}})
    yh = Market(providers=["yahoo"], provider_kwargs={"yahoo": {"request_interval": 0}}).market("KOSPI", count=10)
    check("야후 null 봉 제외 후 9봉", len(yh) == 9)

    # ⑦ 폴백: KRX 실패 → 네이버 성공 (야후는 호출 안 함)
    def h7(url, headers):
        if "data-dbg.krx.co.kr" in url:
            return URLError("connection refused")
        if "api.stock.naver.com" in url:
            return {"priceInfos": naver_rows}
        raise AssertionError("야후까지 호출되면 안 됨")
    install_fake(h7)
    fb = Market(providers=["krx", "naver", "yahoo"], fetch_mode="fallback", provider_kwargs={
        "krx": {"auth_key": "KEY123", "request_interval": 0, "cache_dir": os.path.join(_TMP, "c4")},
        "naver": {"request_interval": 0}, "yahoo": {"request_interval": 0}})
    _sleep = time.sleep
    time.sleep = lambda s: None  # 재시도 대기 생략
    try:
        fdf = fb.market("KOSPI", count=20)
    finally:
        time.sleep = _sleep
    rep = fb.last_report
    check("폴백: 네이버 데이터 사용", fdf["source"].iloc[0] == "naver")
    check("폴백: 리포트에 KRX 실패 원인 기록", "krx" in rep["errors"] and rep["used"] == ["naver"])

    # ⑧ 미지원 심볼은 '오류'가 아니라 '건너뜀'으로 분리
    install_fake(lambda u, h: {"chart": {"result": [{"meta": {}, "timestamp": ts[:5],
                "indicators": {"quote": [{k: v[:5] for k, v in yq.items()}]}}], "error": None}})
    m8 = Market(providers=["naver", "yahoo"], fetch_mode="fallback",
                provider_kwargs={"naver": {"request_interval": 0}, "yahoo": {"request_interval": 0}})
    m8.market("^GSPC", count=3)
    check("미지원 심볼: 네이버는 skipped, 야후로 통과", "naver" in m8.last_report["skipped"]
          and m8.last_report["used"] == ["yahoo"])

    # ⑨ 전부 실패 시 예외 + 이유
    install_fake(lambda u, h: {"priceInfos": []})
    m9 = Market(providers=["naver"], provider_kwargs={"naver": {"request_interval": 0}})
    try:
        m9.market("KOSPI", count=5)
        ok = False
    except RuntimeError as e:
        ok = "naver" in str(e)
    check("빈 응답은 실패로 처리(빈 표를 성공으로 넘기지 않음)", ok)

    # ⑩ 원자적 쓰기: 동시 다발 쓰기 후에도 JSON이 온전
    target = Path(_TMP) / "shared.json"
    procs = [mp.Process(target=_writer, args=(str(target), i)) for i in range(6)]
    [p.start() for p in procs]
    [p.join() for p in procs]
    try:
        json.loads(target.read_text(encoding="utf-8"))
        ok = True
    except Exception:
        ok = False
    check("6개 프로세스 동시 쓰기 후 파일 온전", ok and not list(Path(_TMP).glob("shared.json.*.tmp")))

    # ⑪ 프로세스 간 요청 간격 공유
    q = mp.Queue()
    procs = [mp.Process(target=_stamper, args=(q,)) for _ in range(3)]
    [p.start() for p in procs]
    [p.join() for p in procs]
    stamps = sorted(q.get() for _ in range(3))
    gaps = [b - a for a, b in zip(stamps, stamps[1:])]
    check("3개 프로세스 요청 간격 >= 0.4초 (설정 0.5초)", all(g >= 0.4 for g in gaps))

    print("\n" + "=" * 50)
    print(f"{sum(results)}/{len(results)} 통과")
    return 0 if all(results) else 1


def _writer(path, i):
    for n in range(30):
        _common.atomic_write_text(Path(path), json.dumps({"writer": i, "n": n, "pad": "x" * 2000}))


def _stamper(q):
    _common.throttle("testhost", 0.5)
    q.put(time.time())


if __name__ == "__main__":
    raise SystemExit(run())
