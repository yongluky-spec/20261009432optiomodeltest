# UME 수집 모듈 v1.1 (2026-09-28)

UME v1 패키지에 **실제 수집기(KRX Open API → 네이버 → 야후)** 를 추가한 버전입니다.
다른 프로그램은 이 패키지를 불러와 `market()` 한 줄로만 데이터를 받습니다.

## 설치
zip을 풀어 `02_engine/` 폴더를 프로젝트 루트에 둡니다 (의존성: pandas, numpy 만. requests/yfinance 불필요).

## 사용 (다른 프로그램에서)
```python
import sys; sys.path.insert(0, "02_engine")
from universal_quant_engine import Market

m = Market(providers=["krx", "naver", "yahoo"], fetch_mode="fallback")
df = m.market("KOSPI", count=200)      # 표준 일봉표: source,timestamp,open,high,low,close,volume,quality
print(m.last_report)                   # 어느 소스를 썼는지, 실패한 소스의 원인
```
- 지원 심볼: `KOSPI`, `KOSPI200` (일봉 `1d`). 야후는 `^GSPC`, `AAPL` 같은 심볼도 그대로 통과
- KRX 키: 환경변수 `KRX_AUTH_KEY` (또는 `Market(..., provider_kwargs={"krx": {"auth_key": "..."}})`)

## 충돌 방지 장치
| 문제 | 처리 |
|---|---|
| 두 프로그램이 같은 캐시 파일을 동시에 씀 | 프로세스별 고유 임시파일에 쓰고 교체(원자적 쓰기) |
| 두 프로그램이 동시에 KRX를 두드려 제한에 걸림 | 요청 간 1초 간격을 **프로세스 간 공유**(락 파일)로 유지 |
| 실행 폴더에 따라 캐시 위치가 달라짐 | 절대경로 `프로젝트루트/04_data/` 고정 (환경변수 `UME_DATA_DIR`로 변경 가능) |
| 실패 원인이 조용히 사라짐 | `last_report`에 소스별 실패 원인·상태 기록 |
| 인증키 오류를 260일 반복 요청 | 401/403은 즉시 중단 |

## 검증
- `python -m universal_quant_engine.tests.test_v1` → 14/14 (기존)
- `python -m universal_quant_engine.tests.test_collectors_v1` → 15/15 (가짜 응답 기반)
- **실제 사이트 연결은 아직 검증 전** → `python universal_quant_engine/examples/smoke_test_live.py`

## 알려진 한계
- 실제 KRX/네이버/야후 응답은 이 환경(인터넷 차단)에서 확인하지 못했습니다. 필드명은 기존 `krx_openapi_client_v1.py`·`kospi_model_v3.py`에서 쓰던 것을 그대로 사용했습니다.
- KRX 코스피200의 응답 지수명(`IDX_NM`)은 "코스피 200"으로 가정했습니다 (공백 제거 후 비교). 다르면 `krx_provider.py`의 `INDEX_NAMES`만 고치면 됩니다.
- pykrx(KRX 아이디/비번 방식)는 이 체인에 넣지 않았습니다.
- 연휴가 5일을 넘으면 기존 `ContinuityValidator`가 '간격 큼'으로 실패 처리할 수 있습니다 (v1 검증기 그대로).
