"""REGIME — 시장 국면 판정: TREND / BREAKOUT_TRANSITION / MEAN_REVERSION / TRANSITION.

원본: kospi-model-arena-observatory-v4-수정본.py 871~923줄.
알고리즘 코드는 변경 없이 옮겼고, import 경로만 모듈 단위로 바꿨다.
"""
from __future__ import annotations

import math
from typing import Dict, Tuple

import numpy as np
import pandas as pd

class RegimeEngine:
    """
    [F9 v2] 변동성 척도 변경: 절대 clip 대신 자기 이력 분위수.

    v1의 clip(0, .01)은 demo와 실제 일봉 KOSPI 모두에서 포화되어
    BREAKOUT_TRANSITION 판정이 사실상 trend 하나로 결정되는 문제가 있었다.
    이제 일간 환산 변동성을 '과거 자기 이력 대비 상위 분위수'로 바꿔서
    봉 주기와 변동성 수준 모두에 robust하게 만든다.
    - volatility = 최근 일간환산 변동성이 자기 이력에서 차지하는 분위수(0~1).
      최소 120봉 이력이 쌓이기 전에는 확정 판정을 하지 않는다(TRANSITION).

    bar_minutes: 한 봉의 길이(분). 일봉이면 390.
    """

    MIN_HISTORY = 120

    def __init__(self, bar_minutes: float = 1.0):
        self.bar_minutes = float(bar_minutes)

    def infer(self, df: pd.DataFrame) -> Tuple[str, Dict[str, float]]:
        ret = df["close"].pct_change()
        mom = ret.rolling(10).mean().iloc[-1]
        vol = ret.rolling(20).std().iloc[-1]
        ma = df["close"].rolling(20).mean().iloc[-1]
        px = df["close"].iloc[-1]
        dist = (px/ma-1) if pd.notna(ma) and ma else 0
        trend = float(np.clip(abs(dist)*40, 0, 1))
        momentum = float(np.clip(abs(float(mom) if pd.notna(mom) else 0)*200, 0, 1))

        # 봉당 변동성 → 일간 환산 (sqrt of bars per day)
        bars_per_day = max(1.0, 390.0 / max(self.bar_minutes, 1e-9))
        vol_series = (ret.rolling(20).std() * math.sqrt(bars_per_day)).dropna()
        vol_daily = float(vol_series.iloc[-1]) if len(vol_series) else 0.0
        if len(vol_series) >= self.MIN_HISTORY:
            hist = vol_series.iloc[:-1]
            # 자기 이력 대비 현재 변동성의 분위수(0~1)
            volatility = float(np.mean(hist.values <= vol_daily)) if len(hist) else 0.5
        else:
            # 이력 부족: 이력이 쌓일 때까지 이력 기반 판정 불가 → 중립치 사용
            volatility = 0.5

        if trend > .75 and momentum > .6:
            regime = "TREND"
        elif volatility > .75 and trend > .5:
            regime = "BREAKOUT_TRANSITION"
        elif trend < .25 and momentum < .35:
            regime = "MEAN_REVERSION"
        else:
            regime = "TRANSITION"
        return regime, {"trend": trend, "momentum": momentum, "volatility": volatility,
                        "distance_ma": float(dist), "bar_minutes": self.bar_minutes}
