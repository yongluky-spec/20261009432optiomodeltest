"""SENSORS — 상태 센서: StateSpace(위치·속도·가속), Friction(호가 마찰).

원본: kospi-model-arena-observatory-v4-수정본.py 824~865줄.
알고리즘 코드는 변경 없이 옮겼고, import 경로만 모듈 단위로 바꿨다.
"""
from __future__ import annotations

from typing import Any, Mapping

import numpy as np
import pandas as pd

class StateSpaceSensor:
    name, task = "StateSpace", "sensor"

    def predict(self, df):
        ma = df["close"].rolling(20).mean()
        atr = (df["high"]-df["low"]).rolling(14).mean().replace(0, np.nan)
        pos = (df["close"]-ma)/atr
        vel = pos.diff()
        acc = vel.diff()
        x = float(pos.iloc[-1]) if pd.notna(pos.iloc[-1]) else 0
        v = float(vel.iloc[-1]) if pd.notna(vel.iloc[-1]) else 0
        a = float(acc.iloc[-1]) if pd.notna(acc.iloc[-1]) else 0
        if x > 1 and v > 0: state = "UP_ACCELERATION"
        elif x < -1 and v < 0: state = "DOWN_ACCELERATION"
        elif abs(x) < .5: state = "CENTERED"
        else: state = "TRANSITION"
        return {"model": self.name, "task": self.task, "signal": state,
                "strength": min(1, abs(x)/3), "x": x, "v": v, "a": a}


class FrictionSensor:
    name, task = "Friction", "sensor"

    def predict(self, orderbook: Mapping[str, Any]):
        if not orderbook:
            return {"model": self.name, "task": self.task, "signal": "ORDERBOOK_UNAVAILABLE",
                    "strength": 0, "status": "DEGRADED"}
        try:
            bid = np.array(orderbook["bid_volumes"], dtype=float)
            ask = np.array(orderbook["ask_volumes"], dtype=float)
            spread = float(orderbook["spread"])
            depth = float(bid.sum()+ask.sum())
            oib = float((bid.sum()-ask.sum())/(bid.sum()+ask.sum()+1e-9))
            ratio = spread * (1 + .4*abs(oib)) / max(depth, 1e-9)
            return {"model": self.name, "task": self.task,
                    "signal": "STRESS" if ratio > .001 else "NORMAL",
                    "strength": min(1, ratio*1000), "status": "GOOD",
                    "friction_ratio": ratio, "oib": oib}
        except Exception as exc:
            return {"model": self.name, "task": self.task, "signal": "DEGRADED",
                    "strength": 0, "status": "ERROR", "error": str(exc)}
