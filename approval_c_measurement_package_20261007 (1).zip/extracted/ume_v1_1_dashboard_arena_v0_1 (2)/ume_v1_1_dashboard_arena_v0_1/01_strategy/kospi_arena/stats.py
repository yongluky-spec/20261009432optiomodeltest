"""STATS — 공용 수식: sigmoid, Wilson 95% 하한, JSON 직렬화 보조.

원본: kospi-model-arena-observatory-v4-수정본.py 587~613줄.
알고리즘 코드는 변경 없이 옮겼고, import 경로만 모듈 단위로 바꿨다.
"""
from __future__ import annotations

import math
from typing import Any, Optional

import numpy as np
import pandas as pd

def sigmoid(x: float) -> float:
    x = float(np.clip(x, -30, 30))
    return 1.0 / (1.0 + math.exp(-x))


def wilson_lower_bound(k: int, n: int, z: float = 1.96) -> Optional[float]:
    """[F3] 방향적중률의 Wilson 95% 신뢰구간 하한."""
    if n <= 0:
        return None
    p = k / n
    denom = 1 + z * z / n
    centre = p + z * z / (2 * n)
    margin = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (centre - margin) / denom


def _json_default(obj: Any) -> Any:
    """[F4-1] numpy bool_/int64/float64 등을 JSON 직렬화 가능 값으로 변환."""
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (pd.Timestamp,)):
        return str(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")
