"""OOS — OOS 평가: 방향적중률, Wilson 하한, 판정(VERIFIED/NO_EDGE/INSUFFICIENT_SAMPLE/DUPLICATED_SAMPLE).

원본: kospi-model-arena-observatory-v4-수정본.py 1110~1251줄.
알고리즘 코드는 변경 없이 옮겼고, import 경로만 모듈 단위로 바꿨다.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Optional

import numpy as np
import pandas as pd

from .ledger import PredictionLedger
from .stats import wilson_lower_bound

@dataclass
class Performance:
    model: str
    task: str
    n: int
    directional_accuracy: Optional[float]
    da_ci_low: Optional[float] = None
    brier: Optional[float] = None
    mae: Optional[float] = None
    profit_factor: Optional[float] = None
    sharpe: Optional[float] = None
    mdd: Optional[float] = None
    status: str = "UNVERIFIED"


class OOSAnalyzer:
    """
    [F1][F3] 수정된 스코어카드.

    - direction_correct는 bool/None이 섞인 object 열이므로
      pd.to_numeric(errors='coerce') 후 dropna().mean() 한다.
    - VERIFIED 조건: n >= 30 (비중첩) AND Wilson 95% CI 하한 > 50%.
      CI 하한이 50% 이하면 DA가 우연일 가능성을 배제하지 못하므로
      'NO_EDGE'로 표기한다.
    """

    MIN_VERIFIED_N = 30

    @staticmethod
    def _has_duplicate_samples(g: pd.DataFrame) -> bool:
        """
        [F4-8] 중복 표본 방어선 — 심볼·소스와 무관한 '내용 지문' 기반.

        원장 키(timestamp, model, horizon, symbol, source)와 달리,
        통계 검사는 symbol/source를 신뢰하지 않는다:
        - 구형 원장의 symbol="UNKNOWN"은 어떤 심볼과도 같은 것으로
          취급한다(wildcard). --legacy-symbol 승격을 빠뜨려도
          UNKNOWN+KOSPI 중복이 VERIFIED로 통과하지 않는다.
        - 검사 키: (timestamp, model, horizon, price_at_prediction, p_up).
          이 값들이 같으면 같은 시장 시점에 대한 같은 예측으로 본다.
        - source가 달라도(예: demo_replay vs live) 같은 시각·모델·가격의
          예측은 같은 시장 시점을 두 번 세는 것이므로 중복이다.

        정책 요약(두 계층의 역할 분담):
        - 원장(add/load)은 source까지 포함해 기록 보존을 위해 중복을
          허용하지 않는다(기록 계층).
        - OOS 통계(summarize)는 시장 시점 기준으로 유일성을 강제하고,
          위반이 있으면 VERIFIED를 주지 않는다(통계 계층).

        [F4-11] 성능: 지문 키로 그룹화한 뒤 그룹 안에서만 심볼을
        비교한다(O(n) 근사). 전체 이중 루프는 피한다.
        """
        key_cols = ["timestamp", "model", "horizon",
                    "price_at_prediction", "p_up"]
        for c in key_cols:
            if c not in g.columns:
                return False
        gg = g.dropna(subset=["timestamp"])
        if gg.empty:
            return False

        # [F4-11] (timestamp, model, horizon, price, p_up) 그룹화 → O(n).
        # 가격·확률이 다르면(KOSPI 지수 vs K200 선물 등) 다른 그룹이
        # 되므로 오탐하지 않는다. 같은 지문이 2건 이상인 그룹만 중복.
        grouped = gg.groupby(
            ["timestamp", "model", "horizon", "price_at_prediction", "p_up"],
            dropna=False)
        for _, grp in grouped:
            if len(grp) < 2:
                continue
            symbols = {str(r.get("symbol", "UNKNOWN"))
                       for r in grp.to_dict("records")}
            if "UNKNOWN" in symbols or len(symbols) == 1:
                # UNKNOWN wildcard 포함, 또는 심볼까지 같음 → 같은 시장
                # 시점을 두 번 센 것(source만 다른 경우 포함)
                return True
            # 심볼이 서로 다르면 다른 종목의 우연한 동일 지문(가격·p_up까지
            # 같음)이다. 희박한 경우로, 중복이 아니므로 통과시킨다.
        return False

    def summarize(self, ledger: PredictionLedger) -> pd.DataFrame:
        df = ledger.dataframe()
        if df.empty:
            return pd.DataFrame()
        out = []
        for (model, task), g in df.groupby(["model", "task"]):
            g = g[g["status"] == "EVALUATED"].copy()
            n = len(g)
            if n == 0:
                out.append(asdict(Performance(model, task, 0, None, status="UNVERIFIED")))
                continue

            # [F1] bool/None 혼합 object 열의 안전한 수치화
            dc = pd.to_numeric(g["direction_correct"], errors="coerce")
            acc = None
            ci_low = None
            if dc.notna().any():
                k = int(dc.dropna().sum())
                n_eff = int(dc.notna().sum())
                acc = float(k / n_eff)
                ci_low = wilson_lower_bound(k, n_eff)

            brier = None
            if "p_up" in g.columns and g["p_up"].notna().any() and g["actual_direction"].notna().any():
                gg = g[g["p_up"].notna() & g["actual_direction"].notna()].copy()
                y = (gg["actual_direction"] == "UP").astype(float)
                brier = float(np.mean((gg["p_up"].astype(float)-y)**2))

            mae = float(g["absolute_error"].dropna().mean()) if g["absolute_error"].notna().any() else None

            pnl = []
            for _, r in g.iterrows():
                if r["predicted_return"] is None or pd.isna(r["predicted_return"]):
                    continue
                pnl.append(float(np.sign(r["predicted_return"]) * r["actual_return"]))
            pf = None
            sharpe = None
            mdd = None
            if pnl:
                arr = np.asarray(pnl, dtype=float)
                gains = arr[arr > 0].sum()
                losses = -arr[arr < 0].sum()
                pf = float(gains/losses) if losses > 0 else float("inf")
                sharpe = float(arr.mean()/(arr.std(ddof=1)+1e-12)*np.sqrt(len(arr))) if len(arr) > 1 else None
                curve = np.cumsum(arr)
                peak = np.maximum.accumulate(curve)
                mdd = float(np.min(curve-peak))

            # [F3] VERIFIED 판정 강화 + [F4-6] 중복 표본 방어선
            if self._has_duplicate_samples(g):
                status = "DUPLICATED_SAMPLE"
            elif acc is None or n < self.MIN_VERIFIED_N:
                status = "INSUFFICIENT_SAMPLE"
            elif ci_low is not None and ci_low > 0.5:
                status = "VERIFIED"
            else:
                status = "NO_EDGE"
            out.append(asdict(Performance(model, task, n, acc, ci_low, brier,
                                          mae, pf, sharpe, mdd, status)))
        return pd.DataFrame(out)
