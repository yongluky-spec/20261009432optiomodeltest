"""TIR — TIR 센서 v1(원본 frozen 함수 우선, 없으면 내장 폴백)과 v2(4분류).

원본: kospi-model-arena-observatory-v4-수정본.py 190~211줄, 687~774줄, 777~822줄.
알고리즘 코드는 변경 없이 옮겼고, import 경로만 모듈 단위로 바꿨다.
"""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd

# [F7-3] TIR v1 frozen baseline: 원본 파일이 있으면 import해서 쓴다.
# 실패 시 조용히 넘어가지 않고 경고를 남긴다(폴백이 쓰이는지 항상 알 수 있게).
# [검증 반영] 원본 tir_reflection_backtest_v1.py에는 TIRReflectionV1 '클래스'가
# 없고 run_backtest_v1/compute_tir_proxies '함수'가 있다(2026-09-26 실물 확인).
# 따라서 클래스 import가 아니라 모듈 import + 함수 인터페이스 검증으로 바꾼다
# (kospi_cockpit_sensor_hub_v1.1.py의 TIRSensor와 동일한 패턴).
TIR_V1_IMPORT_ERROR: Optional[str] = None
try:  # pragma: no cover - 환경 의존
    import tir_reflection_backtest_v1 as _tir_v1_module  # type: ignore
    if not callable(getattr(_tir_v1_module, "run_backtest_v1", None)):
        raise AttributeError("run_backtest_v1 함수 없음")
    TIR_V1_MODULE_AVAILABLE = True
except Exception as _exc:  # noqa: BLE001 - 원본 부재/시그니처 불일치 모두 폴백
    _tir_v1_module = None  # type: ignore
    TIR_V1_MODULE_AVAILABLE = False
    TIR_V1_IMPORT_ERROR = f"{type(_exc).__name__}: {_exc}"


def tir_v1_baseline_status() -> str:
    if TIR_V1_MODULE_AVAILABLE:
        return "frozen(import tir_reflection_backtest_v1.run_backtest_v1)"
    return f"internal fallback (import failed: {TIR_V1_IMPORT_ERROR})"


class TIRV1External:
    """
    [F7-3] 원본 tir_reflection_backtest_v1.py의 함수 기반 frozen baseline 래퍼.

    원본 run_backtest_v1(df)는 다음 컬럼을 요구한다:
      spot_close, futures_close, high, low, close, trade_amount
    없으면 close로 보조한다(futures_close가 없으면 basis=0, theta_proxy=0).
    반환 df에 tir_score/tir_signal/kappa_proxy/theta_proxy가 생기며,
    이 래퍼는 그 '마지막 행'을 센서 신호로 변환한다.

    주의: 원본은 일봉(rolling 60일) 기준이다. 분봉에 적용하면 창의 의미가
    달라진다(60봉). bar 단위는 호출자가 문서화한다.
    """

    name, task = "TIR_v1", "sensor"
    frozen = True  # 원본 import 시

    def compute(self, df):
        x = df.copy()
        if "spot_close" not in x.columns:
            x["spot_close"] = x["close"]
        if "futures_close" not in x.columns:
            x["futures_close"] = x["close"]
        # 원본은 내부에서 print(시그널 통계)를 출력한다 - 그대로 둔다.
        return _tir_v1_module.run_backtest_v1(x)

    def predict(self, df):
        x = self.compute(df)
        s = x["tir_score"].iloc[-1]
        active = bool(x["tir_signal"].iloc[-1]) if pd.notna(x["tir_signal"].iloc[-1]) else False
        return {"model": self.name, "task": self.task,
                "signal": "TIR_ACTIVE" if active else "NORMAL",
                "strength": float(s/4) if pd.notna(s) else 0,
                "frozen_baseline": self.frozen}


class TIRV1Fallback:
    """
    [F7] TIR v1 폴백 구현.

    주의: 이 클래스는 frozen baseline의 '복제'이다. 원본
    tir_reflection_backtest_v1.py가 import 가능하면 그것이 우선한다.
    또한 원본이 일봉(rolling 60일) 기준이라면, 분봉에 적용하면
    창의 의미가 달라진다(60분). bar_minutes로 의미를 문서화한다.
    """

    name, task = "TIR_v1", "sensor"
    frozen = False  # 폴백이면 False, 원본 import면 True

    def compute(self, df):
        x = df.copy()
        spot = x.get("spot_close", x["close"])
        if "spot_close" not in x.columns:
            x["spot_close"] = spot
        fut = x.get("futures_close", x["close"])
        if "futures_close" not in x.columns:
            x["futures_close"] = fut
        x["basis"] = x["futures_close"] - x["spot_close"]
        x["theta_proxy"] = x["basis"].diff()
        range_pct = (x["high"] - x["low"]) / x["close"]
        m = x["trade_amount"].rolling(20).mean()
        s = x["trade_amount"].rolling(20).std()
        z = np.clip((x["trade_amount"]-m)/(s+1e-9), 0, None)
        x["kappa_proxy"] = z/(range_pct+1e-3)
        high60 = x["close"].rolling(60).max()
        box = (x["close"] >= high60*.95).astype(int)*2
        kt = x["kappa_proxy"].expanding(60).quantile(.65).shift(1)
        tt = x["theta_proxy"].expanding(60).quantile(.35).shift(1)
        # [F7-3] 원본 run_backtest_v1과 동일한 컬럼명(tir_score/tir_signal) 사용
        x["tir_score"] = box + (x["kappa_proxy"] >= kt).astype(int) + (x["theta_proxy"] <= tt).astype(int)
        x["tir_signal"] = x["tir_score"] >= 3
        return x

    def predict(self, df):
        x = self.compute(df)
        s = x["tir_score"].iloc[-1]
        active = bool(s >= 3) if pd.notna(s) else False
        return {"model": self.name, "task": self.task,
                "signal": "TIR_ACTIVE" if active else "NORMAL",
                "strength": float(s/4) if pd.notna(s) else 0,
                "frozen_baseline": self.frozen}


def get_tir_v1():
    """[F7-3] 원본 frozen baseline 우선, 없으면 폴백."""
    if TIR_V1_MODULE_AVAILABLE and _tir_v1_module is not None:
        return TIRV1External()
    return TIRV1Fallback()


class TIRV2:
    """
    [F7-4] 원본 4분류 정의에 일치시킴 (2026-09-26 원본 실물 확보 후 검증).

    원본 tir_reflection_backtest_v1.py의 classify_v2_states 규칙:
      - v_proxy = EMA(ROC_5), v_thresh = |v_proxy|의 expanding
        quantile(0.70) + shift(1) → look-ahead 없음
      - is_fast = |v_proxy| >= v_thresh
      - TIR 충족 + Slow   → TRAPPED
      - TIR 충족 + Fast   → LEAK_WARNING
      - TIR 미충족 + Slow → 일반(이 파일 표기: NORMAL)
      - TIR 미충족 + Fast → BREAKOUT_후보(확정 아님, 후보)
    즉 BREAKOUT_후보는 'TIR 미충족' 상태에서만 등장한다
    (이전 구현인 'TIR 활성 + 빠름 = BREAKOUT_CANDIDATE'와는 다른, 원본 정의).
    """

    name, task = "TIR_v2", "sensor"

    def predict(self, df):
        tir1 = get_tir_v1()
        x = tir1.compute(df)
        roc = x["close"].pct_change(5)
        v = roc.ewm(alpha=.2, adjust=False).mean()
        # 원본과 동일: |v_proxy| 기준 expanding quantile + shift(1)
        th = v.abs().expanding(60).quantile(.70).shift(1)
        active = bool(x["tir_score"].iloc[-1] >= 3) if pd.notna(x["tir_score"].iloc[-1]) else False
        vv = v.iloc[-1]
        tt = th.iloc[-1]
        if pd.isna(tt) or pd.isna(vv):
            state = "TIR_ACTIVE" if active else "NORMAL"
            strength = .5
        else:
            is_fast = bool(abs(vv) >= tt)
            if active and not is_fast:
                state = "TRAPPED"
            elif active and is_fast:
                state = "LEAK_WARNING"
            elif not active and not is_fast:
                state = "NORMAL"  # 원본 표기 '일반'
            else:
                state = "BREAKOUT_후보"  # 원본 표기 그대로 사용
            strength = float(min(1, abs(vv)/(tt+1e-9)))
        return {"model": self.name, "task": self.task, "signal": state,
                "strength": strength,
                "tir_v1_frozen_baseline": getattr(tir1, "frozen", False)}
