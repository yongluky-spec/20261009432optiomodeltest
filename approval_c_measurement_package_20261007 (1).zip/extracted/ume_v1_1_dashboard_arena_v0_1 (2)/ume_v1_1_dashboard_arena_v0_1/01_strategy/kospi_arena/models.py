"""MODELS — 방향/돌파 예측 모델 4개: Momentum, Hook_OU(평균회귀), Threshold, Breakout.

원본: kospi-model-arena-observatory-v4-수정본.py 616~684줄.
알고리즘 코드는 변경 없이 옮겼고, import 경로만 모듈 단위로 바꿨다.
"""
from __future__ import annotations

from typing import Any, Dict

import numpy as np
import pandas as pd

from .stats import sigmoid

class BaseModel:
    name = "Base"
    task = "direction"

    def predict(self, df: pd.DataFrame) -> Dict[str, Any]:
        raise NotImplementedError


class MomentumModel(BaseModel):
    name, task = "Momentum", "direction"

    def predict(self, df):
        r = float(df["close"].pct_change(5).iloc[-1])
        p = sigmoid(r * 120) if np.isfinite(r) else 0.5
        return {"model": self.name, "task": self.task, "direction": "UP" if p >= .5 else "DOWN",
                "p_up": p, "predicted_return": r, "strength": abs(p-.5)*2, "actionable": True}


class MeanReversionModel(BaseModel):
    name, task = "Hook_OU", "direction"

    def predict(self, df):
        ma = float(df["close"].rolling(20).mean().iloc[-1])
        px = float(df["close"].iloc[-1])
        z = (px/ma - 1) if ma else 0
        p = sigmoid(-z * 80)
        return {"model": self.name, "task": self.task, "direction": "UP" if p >= .5 else "DOWN",
                "p_up": p, "predicted_return": -z, "strength": abs(p-.5)*2, "actionable": True}


class ThresholdModel(BaseModel):
    name, task = "Threshold", "direction"

    def predict(self, df):
        r = df["close"].pct_change().rolling(10).mean().iloc[-1]
        v = df["close"].pct_change().rolling(20).std().iloc[-1]
        score = float(r/v) if pd.notna(r) and pd.notna(v) and v > 0 else 0
        p = sigmoid(score)
        return {"model": self.name, "task": self.task, "direction": "UP" if p >= .5 else "DOWN",
                "p_up": p, "predicted_return": float(r) if pd.notna(r) else 0,
                "strength": min(1, abs(score)/3), "actionable": True}


class BreakoutModel(BaseModel):
    name, task = "Breakout", "breakout"

    def predict(self, df):
        hh = df["high"].rolling(20).max().iloc[-2]
        ll = df["low"].rolling(20).min().iloc[-2]
        px = df["close"].iloc[-1]
        if pd.isna(hh) or pd.isna(ll):
            return {"model": self.name, "task": self.task, "signal": "UNKNOWN",
                    "predicted_return": 0, "strength": 0, "actionable": False}
        if px > hh:
            ret = float(px/hh - 1)
            return {"model": self.name, "task": self.task, "signal": "UP_BREAKOUT",
                    "direction": "UP", "p_up": .5 + min(.49, ret*100),
                    "predicted_return": ret, "strength": min(1, ret*100),
                    "actionable": True}
        if px < ll:
            ret = float(ll/px - 1)
            return {"model": self.name, "task": self.task, "signal": "DOWN_BREAKOUT",
                    "direction": "DOWN", "p_up": .5 - min(.49, ret*100),
                    "predicted_return": -ret, "strength": min(1, ret*100),
                    "actionable": True}
        # [F2] NO_BREAKOUT은 중립 신호: 원장에서 제외(actionable=False).
        return {"model": self.name, "task": self.task, "signal": "NO_BREAKOUT",
                "direction": "UP" if px >= df["close"].rolling(20).mean().iloc[-1] else "DOWN",
                "p_up": .5, "predicted_return": 0, "strength": 0, "actionable": False}
