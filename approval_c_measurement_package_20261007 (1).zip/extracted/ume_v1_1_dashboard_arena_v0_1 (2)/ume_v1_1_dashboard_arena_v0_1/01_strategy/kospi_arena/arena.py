"""ARENA — Arena: 정규화 → Regime → 모델 → 원장 → OOS → Priority 를 묶는 실행기.

원본: kospi-model-arena-observatory-v4-수정본.py 1313~1453줄.
알고리즘 코드는 변경 없이 옮겼고, import 경로만 모듈 단위로 바꿨다.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

import numpy as np
import pandas as pd

from .contract import normalize_bars
from .ledger import PredictionLedger, PredictionRecord
from .models import BreakoutModel, MeanReversionModel, MomentumModel, ThresholdModel
from .oos import OOSAnalyzer
from .regime import RegimeEngine
from .scoring import REGIME_FIT, _obs_score
from .sensors import FrictionSensor, StateSpaceSensor
from .tir import TIRV2, get_tir_v1

@dataclass
class ArenaResult:
    timestamp: pd.Timestamp
    regime: str
    market_state: Dict[str, float]
    predictions: List[Dict[str, Any]]
    sensors: List[Dict[str, Any]]
    oos: pd.DataFrame
    current_priority: Optional[str]
    current_reason: str
    oos_leader: Optional[str]
    provider: str
    quality: str


class Arena:
    def __init__(self, ledger_path: Optional[str] = None, bar_minutes: float = 1.0,
                 legacy_symbol: Optional[str] = None):
        self.models = [
            MomentumModel(), MeanReversionModel(), ThresholdModel(), BreakoutModel()
        ]
        self.tir2 = TIRV2()
        self.state = StateSpaceSensor()
        self.friction = FrictionSensor()
        self.regime = RegimeEngine(bar_minutes=bar_minutes)
        self.ledger = PredictionLedger()
        self.oos = OOSAnalyzer()
        self.ledger_path = ledger_path
        if ledger_path and Path(ledger_path).exists():
            # [F4-6] 구형 원장의 UNKNOWN 심볼을 승격해 키 중복 방지
            self.ledger.load(ledger_path, legacy_symbol=legacy_symbol)

    # -------------------------------------------------- ledger persistence
    def _flush_ledger(self):
        if self.ledger_path:
            self.ledger.save(self.ledger_path)

    def _record(self, hist: pd.DataFrame, reg: str, p: Dict[str, Any], horizon: int):
        """[F2] actionable 신호만 원장에 고정 기록한다."""
        if not p.get("actionable", False):
            return
        if "direction" not in p and "p_up" not in p:
            return
        self.ledger.add(PredictionRecord(
            timestamp=str(hist["timestamp"].iloc[-1]),
            model=p["model"], task=p.get("task", "direction"),
            horizon=horizon, regime=reg,
            prediction=p.get("direction", p.get("signal", "UNKNOWN")),
            p_up=float(p["p_up"]) if "p_up" in p else None,
            predicted_return=float(p.get("predicted_return", 0)),
            price_at_prediction=float(hist["close"].iloc[-1]),
            source=str(hist["source"].iloc[-1]),
            symbol=str(hist["symbol"].iloc[-1]),  # [F4-4]
        ))

    def run_backtest_replay(self, bars: pd.DataFrame, horizon: int = 5) -> ArenaResult:
        """
        [F3] stride=horizon 비중첩 워크포워드.
        매 horizon 봉마다 한 번만 예측하므로 평가 표본이 서로 겹치지 않는다.
        여전히 예측 시점에는 미래 데이터가 들어가지 않는다(hist = x.iloc[:i+1]).
        """
        x = normalize_bars(bars, "replay")
        start = 70
        for i in range(start, len(x)-horizon, horizon):
            hist = x.iloc[:i+1].copy()
            reg, _ = self.regime.infer(hist)
            for model in self.models:
                p = model.predict(hist)
                self._record(hist, reg, p, horizon)
        self.ledger.evaluate(x)
        self._flush_ledger()
        return self.evaluate_current(x, "replay", "GOOD", record=False)

    def evaluate_current(self, bars: pd.DataFrame, provider: str, quality: str,
                         orderbook: Optional[Mapping[str, Any]] = None,
                         horizon: int = 5, record: Optional[bool] = None) -> ArenaResult:
        """
        현재 스냅샷 관찰 + [F4] 현재 예측을 PENDING으로 원장에 고정 기록.
        이후 실제 봉이 들어오면 ledger.evaluate()가 실제값을 부착한다.
        [F5] orderbook이 제공되면 Friction 센서가 활성화된다.
        """
        if record is None:
            record = True
        x = normalize_bars(bars, provider)
        reg, state = self.regime.infer(x)

        predictions = [m.predict(x) for m in self.models]

        if record:
            for p in predictions:
                self._record(x, reg, p, horizon)
            self._flush_ledger()

        sensors = [get_tir_v1().predict(x), self.tir2.predict(x), self.state.predict(x)]
        sensors.append(self.friction.predict(orderbook or {}))  # [F5]

        oos = self.oos.summarize(self.ledger)
        current_priority, reason = self._priority(predictions, reg, oos)
        oos_leader = self._oos_leader(oos)
        return ArenaResult(pd.Timestamp(x["timestamp"].iloc[-1]), reg, state,
                           predictions, sensors, oos, current_priority, reason,
                           oos_leader, provider, quality)

    def _priority(self, predictions, regime, oos):
        candidates = []
        for p in predictions:
            strength = float(np.clip(p.get("strength", 0), 0, 1))
            # [F2] 중립(NO_BREAKOUT) 신호는 Priority 후보에서 제외
            if not p.get("actionable", True):
                continue
            score, evidence, validated = _obs_score(p["model"], strength, regime, oos)
            candidates.append((score, p["model"], strength,
                               REGIME_FIT.get(p["model"], {}).get(regime, .5),
                               validated, evidence))

        if not candidates:
            return None, "지금은 actionable 예측이 없습니다(모두 중립 신호)."

        candidates.sort(reverse=True)
        _, name, strength, fit, validated, evidence = candidates[0]
        if validated:
            reason = (f"{name}: 현재 신호강도 {strength:.2f} × Regime 적합도 {fit:.2f} "
                      f"+ 검증된 OOS 증거({evidence}). "
                      f"단, Regime 적합도는 heuristic prior다.")
        else:
            reason = (f"{name}: 현재 신호강도 {strength:.2f} × Regime 적합도 {fit:.2f}. "
                      f"{evidence}; 따라서 잠정 Priority.")
        return name, reason

    @staticmethod
    def _oos_leader(oos):
        if oos.empty:
            return None
        v = oos[(oos["task"] == "direction") & (oos["status"] == "VERIFIED")].copy()
        if v.empty:
            return None
        # [F3] DA가 같으면 CI 하한이 높은 쪽, 그다음 표본이 많은 쪽
        v = v.sort_values(["directional_accuracy", "da_ci_low", "n"], ascending=False)
        return str(v.iloc[0]["model"])
