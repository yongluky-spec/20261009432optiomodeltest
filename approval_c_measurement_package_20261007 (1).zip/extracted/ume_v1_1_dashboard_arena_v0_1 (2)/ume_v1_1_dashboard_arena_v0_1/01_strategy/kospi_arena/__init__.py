"""kospi_arena — KOSPI Model Arena 알고리즘 모듈 묶음.

원본(kospi-model-arena-observatory-v4-수정본.py)의 알고리즘을 역할별 파일로 분리했다.
계산 코드는 원본과 동일하며, 분리 후에도 결과가 같은지는 tests/test_equivalence.py 가 대조한다.

  contract  봉 데이터 계약·정규화       stats    sigmoid·Wilson 하한
  models    방향/돌파 모델 4개          tir      TIR v1/v2 센서
  sensors   StateSpace·Friction         regime   시장 국면
  ledger    예측 원장                   oos      OOS 평가
  scoring   Regime 적합도·관찰 점수      arena    실행기
  data_port 수집 모듈 연결부(어댑터)
"""
from .arena import Arena, ArenaResult
from .contract import LOCAL_TZ, REQUIRED_BAR_COLUMNS, normalize_bars
from .data_port import BarSource, contract_report, to_arena_bars
from .ledger import PredictionLedger, PredictionRecord
from .models import BreakoutModel, MeanReversionModel, MomentumModel, ThresholdModel
from .oos import OOSAnalyzer, Performance
from .regime import RegimeEngine
from .scoring import REGIME_FIT, _obs_score
from .sensors import FrictionSensor, StateSpaceSensor
from .stats import sigmoid, wilson_lower_bound
from .tir import TIRV2, get_tir_v1, tir_v1_baseline_status

__version__ = "1.0.0"
__all__ = [
    "Arena", "ArenaResult", "normalize_bars", "REQUIRED_BAR_COLUMNS", "LOCAL_TZ",
    "PredictionLedger", "PredictionRecord", "OOSAnalyzer", "Performance", "RegimeEngine",
    "MomentumModel", "MeanReversionModel", "ThresholdModel", "BreakoutModel",
    "StateSpaceSensor", "FrictionSensor", "TIRV2", "get_tir_v1", "tir_v1_baseline_status",
    "BarSource", "to_arena_bars", "contract_report",
    "REGIME_FIT", "_obs_score", "sigmoid", "wilson_lower_bound",
]
