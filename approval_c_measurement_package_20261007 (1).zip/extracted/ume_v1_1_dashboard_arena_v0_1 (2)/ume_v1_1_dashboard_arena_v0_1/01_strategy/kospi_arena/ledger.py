"""LEDGER — 예측 원장(append-only). 예측을 먼저 고정 기록하고 나중에 실제값을 붙인다.

원본: kospi-model-arena-observatory-v4-수정본.py 928~1108줄.
알고리즘 코드는 변경 없이 옮겼고, import 경로만 모듈 단위로 바꿨다.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .contract import normalize_bars
from .stats import _json_default

@dataclass
class PredictionRecord:
    timestamp: str
    model: str
    task: str
    horizon: int
    regime: str
    prediction: str
    p_up: Optional[float]
    predicted_return: Optional[float]
    price_at_prediction: float
    target_timestamp: Optional[str] = None
    actual_return: Optional[float] = None
    actual_direction: Optional[str] = None
    direction_correct: Optional[bool] = None
    absolute_error: Optional[float] = None
    status: str = "PENDING"
    source: str = "UNKNOWN"
    # [F4-4] 중복 키에 symbol 포함(지수/선물 등 종목 병행 대비).
    # 기존 원장 파일(필드 없음)도 기본값으로 무리 없이 적재된다.
    symbol: str = "UNKNOWN"


class PredictionLedger:
    """
    [F4] 예측 고정 기록(append-only ledger).

    - [F4-4] (timestamp, model, horizon, symbol, source) 키로 중복 기록을
      차단한다. 같은 시각에 다른 종목/공급원의 예측은 별도 레코드로
      공존한다(예: KOSPI 지수와 KOSPI200 선물).
    - [F4-2] 재적재 후 리플레이를 다시 돌려도 같은 예측이 두 배로
      쌓이지 않고, 실시간에서 evaluate_current()를 반복 호출해도
      한 시점·모델·종목당 1건만 남는다.
    - [F4-6] 구형 원장(symbol 필드 없음 → UNKNOWN) 호환: load()에
      legacy_symbol을 지정하면 UNKNOWN 심볼을 해당 심볼로 승격해서
      새 리플레이(symbol="KOSPI")와 키가 달라 중복 방지가 작동하지
      않는 일을 막는다. [F4-8] 승격을 빠뜨려도 통계는 지켜진다:
      OOSAnalyzer가 symbol/source와 무관한 내용 지문(timestamp,
      model, horizon, price_at_prediction, p_up)으로 중복을 검사하고
      UNKNOWN은 wildcard 취급한다. 중복이 있으면 VERIFIED 대신
      DUPLICATED_SAMPLE — 원장 형식과 무관한 통계 방어선.
    - [F4-5] save()는 신규 예측 레코드와 '평가 갱신 이벤트'(_t=update)
      줄을 append한다. PENDING으로 저장된 예측이 나중에 EVALUATED로
      바뀌면 갱신 줄이 추가되고, load()는 같은 키의 마지막 상태를
      우선 적용한다 — append-only와 양립하면서 실시간
      "기록 → 실제값 부착" 순환이 재적재 후에도 유지된다.
      [F4-7] 신규 레코드를 쓸 때 현재 상태를 _saved_status에 함께
      기록해, 이미 EVALUATED인 레코드에 불필요한 갱신 줄이 붙지 않는다.
    - evaluate()는 PENDING 레코드에만 실제값을 부착한다(재평가 안 함).
    """

    def __init__(self):
        self.records: List[PredictionRecord] = []
        self._seen: Dict[Tuple[str, str, int, str, str], PredictionRecord] = {}
        self._saved_count = 0  # 이미 디스크에 append된 신규 레코드 수
        self._saved_status: Dict[Tuple[str, str, int, str, str], str] = {}

    def _key(self, rec: PredictionRecord) -> Tuple[str, str, int, str, str]:
        # [F4-4] symbol과 source를 포함한 복합 키
        return (rec.timestamp, rec.model, int(rec.horizon),
                str(rec.symbol), str(rec.source))

    def add(self, rec: PredictionRecord) -> bool:
        """중복이면 기록하지 않고 False를 반환한다."""
        k = self._key(rec)
        if k in self._seen:
            return False
        self._seen[k] = rec
        self.records.append(rec)
        return True

    def save(self, path: str):
        """
        [F4-3] 전체 덮어쓰기가 아니라 append.
        [F4-5] 신규 레코드 줄(_t=record) 다음에, 마지막 저장 이후
        상태가 변한 레코드의 평가 갱신 줄(_t=update)을 추가한다.
        [F4-7] 신규 레코드를 쓸 때 _saved_status를 함께 기록해서,
        이미 EVALUATED로 저장된 레코드에 불필요한 갱신 줄이
        하나씩 더 붙지 않는다(리플레이에서 2배 파일 방지).
        """
        p = Path(path)
        with p.open("a", encoding="utf-8") as f:
            for rec in self.records[self._saved_count:]:
                row = asdict(rec)
                row["_t"] = "record"
                f.write(json.dumps(row, ensure_ascii=False,
                                   default=_json_default) + "\n")
                # [F4-7] 저장 시점의 상태를 기록
                self._saved_status[self._key(rec)] = rec.status
            self._saved_count = len(self.records)
            for rec in self.records:
                k = self._key(rec)
                last = self._saved_status.get(k, "PENDING")
                if rec.status != last:
                    f.write(json.dumps({
                        "_t": "update",
                        "key": list(k),
                        "status": rec.status,
                        "target_timestamp": rec.target_timestamp,
                        "actual_return": rec.actual_return,
                        "actual_direction": rec.actual_direction,
                        "direction_correct": rec.direction_correct,
                        "absolute_error": rec.absolute_error,
                    }, ensure_ascii=False, default=_json_default) + "\n")
                    self._saved_status[k] = rec.status

    def load(self, path: str, legacy_symbol: Optional[str] = None):
        """
        [F4-6] legacy_symbol: 구형 원장(symbol 필드 없음 → "UNKNOWN")의
        심볼을 이 값으로 승격한다(예: --legacy-symbol KOSPI).
        승격하지 않으면 새 리플레이(symbol="KOSPI")와 키가 달라
        중복 방지가 작동하지 않아 표본이 두 배가 될 수 있다.
        """
        p = Path(path)
        if not p.exists():
            return
        with p.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                d = json.loads(line)
                kind = d.get("_t", "record")  # 구형 파일(필드 없음)은 레코드 줄
                if kind == "update":
                    # [F4-5] 같은 키의 마지막 상태를 적용(파일 순서대로 처리)
                    k = tuple(d["key"])
                    rec = self._seen.get(k)  # type: ignore[arg-type]
                    if rec is None:
                        continue
                    rec.status = d.get("status", rec.status)
                    rec.target_timestamp = d.get("target_timestamp")
                    rec.actual_return = d.get("actual_return")
                    rec.actual_direction = d.get("actual_direction")
                    rec.direction_correct = d.get("direction_correct")
                    rec.absolute_error = d.get("absolute_error")
                else:
                    d.pop("_t", None)
                    rec = PredictionRecord(**d)
                    # [F4-6] 구형 UNKNOWN 심볼 승격(중복 방지 키 통일)
                    if legacy_symbol and rec.symbol == "UNKNOWN":
                        rec.symbol = legacy_symbol
                    self.add(rec)
        self._saved_count = len(self.records)
        self._saved_status = {self._key(r): r.status for r in self.records}

    def evaluate(self, bars: pd.DataFrame):
        x = normalize_bars(bars, "ledger")
        ts = x["timestamp"].to_numpy()
        px = x["close"].to_numpy()

        for rec in self.records:
            if rec.status != "PENDING":
                continue
            t0 = pd.Timestamp(rec.timestamp)  # [F8] naive로 통일된 입력 전제
            future = np.where(ts > np.datetime64(t0))[0]
            if len(future) < rec.horizon:
                continue
            idx = future[rec.horizon-1]
            actual = float(px[idx]/rec.price_at_prediction - 1)
            rec.target_timestamp = str(pd.Timestamp(ts[idx]))
            rec.actual_return = actual
            rec.actual_direction = "UP" if actual > 0 else "DOWN" if actual < 0 else "FLAT"
            if rec.task == "direction" and rec.p_up is not None:
                pred_dir = "UP" if rec.p_up >= .5 else "DOWN"
                # [F4-1] numpy.bool_ 대신 순수 bool로 저장(JSON 직렬화 가능)
                rec.direction_correct = bool(pred_dir == rec.actual_direction)
            elif rec.predicted_return is not None:
                if actual != 0 and rec.predicted_return != 0:
                    # [F4-1] numpy.bool_ 대신 순수 bool로 저장(JSON 직렬화 가능)
                    rec.direction_correct = bool(np.sign(rec.predicted_return) == np.sign(actual))
                else:
                    rec.direction_correct = None
            if rec.predicted_return is not None:
                rec.absolute_error = abs(actual-rec.predicted_return)
            rec.status = "EVALUATED"

    def dataframe(self) -> pd.DataFrame:
        if not self.records:
            return pd.DataFrame()
        return pd.DataFrame([asdict(x) for x in self.records])
