"""CONTRACT — 공통 봉 데이터 계약과 정규화. 수집 모듈이 넘겨줄 데이터의 유일한 입구 규격이다.

원본: kospi-model-arena-observatory-v4-수정본.py 218~296줄.
알고리즘 코드는 변경 없이 옮겼고, import 경로만 모듈 단위로 바꿨다.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import pandas as pd

REQUIRED_BAR_COLUMNS = {
    "timestamp", "symbol", "open", "high", "low", "close", "volume", "trade_amount"
}

# [F8] 모든 내부 타임스탬프는 이 타임존의 naive datetime으로 통일한다.
LOCAL_TZ = "Asia/Seoul"


@dataclass
class DataQuality:
    status: str
    source: str
    message: str = ""
    latency_ms: Optional[float] = None
    stale: bool = False
    missing_fields: Tuple[str, ...] = ()


@dataclass
class MarketSnapshot:
    timestamp: pd.Timestamp
    symbol: str
    open: float
    high: float
    low: float
    close: float
    volume: float
    trade_amount: float
    source: str
    quality: str
    source_timestamp: Optional[pd.Timestamp] = None
    spot_close: Optional[float] = None
    futures_close: Optional[float] = None
    basis: Optional[float] = None
    bid_prices: Tuple[float, ...] = ()
    ask_prices: Tuple[float, ...] = ()
    bid_volumes: Tuple[float, ...] = ()
    ask_volumes: Tuple[float, ...] = ()


def normalize_bars(df: pd.DataFrame, source: str) -> pd.DataFrame:
    x = df.copy()
    rename = {
        "date": "timestamp", "datetime": "timestamp", "time": "timestamp",
        "price": "close", "amount": "trade_amount", "turnover": "trade_amount",
    }
    for a, b in rename.items():
        if a in x.columns and b not in x.columns:
            x = x.rename(columns={a: b})

    missing = REQUIRED_BAR_COLUMNS - set(x.columns)
    if missing:
        raise ValueError(f"{source}: required columns missing: {sorted(missing)}")

    # [F8] tz-aware → LOCAL_TZ naive 로 통일. naive는 그대로 둔다.
    ts = pd.to_datetime(x["timestamp"])
    if getattr(ts.dt, "tz", None) is not None:
        ts = ts.dt.tz_convert(LOCAL_TZ).dt.tz_localize(None)
    x["timestamp"] = ts

    x["symbol"] = x["symbol"].astype(str)
    for c in ["open", "high", "low", "close", "volume", "trade_amount"]:
        x[c] = pd.to_numeric(x[c], errors="coerce")

    # [FIX] 컬럼 부재 시 스칼라 fillna로 크래시하던 v2 버그 수정.
    if "source" in x.columns:
        x["source"] = x["source"].fillna(source)
    else:
        x["source"] = source
    if "quality" in x.columns:
        x["quality"] = x["quality"].fillna("GOOD")
    else:
        x["quality"] = "GOOD"
    return x.sort_values("timestamp").reset_index(drop=True)
