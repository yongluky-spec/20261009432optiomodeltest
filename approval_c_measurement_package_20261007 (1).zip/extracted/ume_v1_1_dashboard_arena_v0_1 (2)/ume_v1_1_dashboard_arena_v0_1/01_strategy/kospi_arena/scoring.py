"""SCORING — 관찰 점수: 신호강도 × Regime 적합도(prior) × OOS 승수.

원본: kospi-model-arena-observatory-v4-수정본.py 1256~1311줄.
알고리즘 코드는 변경 없이 옮겼고, import 경로만 모듈 단위로 바꿨다.
"""
from __future__ import annotations

from typing import Tuple

import numpy as np
import pandas as pd

REGIME_FIT = {
    # [F11] 사람이 정한 heuristic prior. Priority는 신호강도 × 이 사전값 ×(검증 시) OOS 승수다.
    "Hook_OU": {"MEAN_REVERSION": 1.0, "TRANSITION": .7, "TREND": .35, "BREAKOUT_TRANSITION": .3},
    "Momentum": {"TREND": 1.0, "BREAKOUT_TRANSITION": .9, "TRANSITION": .65, "MEAN_REVERSION": .3},
    "Breakout": {"BREAKOUT_TRANSITION": 1.0, "TREND": .8, "TRANSITION": .6, "MEAN_REVERSION": .3},
    "Threshold": {"TRANSITION": .8, "MEAN_REVERSION": .75, "TREND": .5, "BREAKOUT_TRANSITION": .4},
    "TIR_v2": {"BREAKOUT_TRANSITION": 1.0, "TREND": .8, "TRANSITION": .6, "MEAN_REVERSION": .3},
}


def _oos_row(oos: pd.DataFrame, name: str) -> pd.DataFrame:
    if oos.empty or "model" not in oos.columns:
        return pd.DataFrame()
    return oos[oos["model"] == name]


def _obs_score(name: str, strength: float, regime: str, oos: pd.DataFrame) -> Tuple[float, str, bool]:
    """
    [F6] Priority/터미널/대시보드가 공유하는 단일 관찰 점수.
    [F12-2] 승수 기준선 정렬: VERIFIED는 항상 ×1.0 이상, 나머지는
      ×1.0 이하가 되도록 설계한다:
      - VERIFIED            : ×(1.0 + edge × stability_factor).
        edge = 2·DA − 1 (DA>50% 보장됨 → 항상 양수)이고
        stability_factor = 0.5 + 0.5·안정성이므로 승수는 항상 ≥1.0.
        예: DA 60%, 안정성 0.9 → edge=0.2, factor=0.95 → ×1.19. DA 70% → ×1.38.
      - NO_EDGE             : ×0.85 (우위 미확정 페널티)
      - 미검증·표본부족      : ×1.0 (중립)
      v3-1의 (0.5+0.5·DA)(≈0.76) 승수 역전 버그(검증된 모델이
      NO_EDGE·미검증보다 낮아지던 문제)를 수정했다.

    returns: (score, evidence, validated)
    """
    fit = REGIME_FIT.get(name, {}).get(regime, .5)
    base = float(np.clip(strength, 0, 1)) * fit
    row = _oos_row(oos, name)
    if row.empty:
        return base, "OOS 미검증(표본 없음)", False
    status = str(row["status"].iloc[0])
    if status == "VERIFIED":
        acc = float(row["directional_accuracy"].iloc[0])
        mdd = row["mdd"].iloc[0]
        stability = 1 - min(1, abs(float(mdd))) if pd.notna(mdd) else .5
        edge = 2.0 * acc - 1.0  # VERIFIED는 CI_low>50%이므로 항상 >0
        multiplier = 1.0 + edge * (0.5 + 0.5 * stability)
        evidence = f"OOS VERIFIED: DA={acc:.1%}, CI_low={float(row['da_ci_low'].iloc[0]):.1%}, n={int(row['n'].iloc[0])} (승수 ×{multiplier:.2f})"
        return base * multiplier, evidence, True
    if status in {"NO_EDGE", "DUPLICATED_SAMPLE"}:
        # [F4-6] 중복 표본도 통계 신뢰 불가 → NO_EDGE와 동일 페널티
        acc = float(row["directional_accuracy"].iloc[0]) if pd.notna(row["directional_accuracy"].iloc[0]) else 0.0
        ci = float(row["da_ci_low"].iloc[0]) if pd.notna(row["da_ci_low"].iloc[0]) else 0.0
        label = "OOS NO_EDGE" if status == "NO_EDGE" else "OOS DUPLICATED_SAMPLE(중복 표본)"
        evidence = (f"{label}: DA={acc:.1%}, CI_low={ci:.1%}, n={int(row['n'].iloc[0])} "
                    f"— 통계적 우위 미확정(스코어 ×0.85)")
        return base * 0.85, evidence, False
    return base, f"OOS 미검증({status}, n={int(row['n'].iloc[0])})", False
