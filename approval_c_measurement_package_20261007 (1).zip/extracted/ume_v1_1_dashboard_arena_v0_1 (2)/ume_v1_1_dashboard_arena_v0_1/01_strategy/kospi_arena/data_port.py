"""DATA PORT — 데이터 수집 모듈과 Arena 를 잇는 연결부. (수집 모듈 통합 지점)

Arena 는 이 파일이 만드는 '봉 계약'(contract.REQUIRED_BAR_COLUMNS)만 입력으로 받는다.
수집 모듈(UME collectors, 가상 수집기, 이후 실데이터 어댑터)은 BarSource 를 구현하거나
to_arena_bars() 로 표를 변환해 넘기면 된다. Arena 쪽 코드는 바꾸지 않는다.

이 파일의 함수는 데이터를 '변환·점검'만 하며 값을 만들어 채우지 않는다
(단, trade_amount 가 없을 때 volume × close 로 계산하는 것은 명시된 옵션이다).
"""
from __future__ import annotations

from typing import List, Optional, Protocol

import pandas as pd

from .contract import REQUIRED_BAR_COLUMNS, normalize_bars

# 품질 표기 대응표: Arena("GOOD") ↔ UME("normal/delayed/manual/missing")
QUALITY_TO_UME = {"GOOD": "normal", "STALE": "delayed", "DEGRADED": "delayed", "MANUAL": "manual", "MISSING": "missing"}
QUALITY_FROM_UME = {"normal": "GOOD", "delayed": "STALE", "manual": "MANUAL", "missing": "MISSING"}

# KOSPI 정규장(현지 시각). 점검용이며 데이터를 자르지 않는다.
SESSION_OPEN = "09:00"
SESSION_CLOSE = "15:30"


class BarSource(Protocol):
    """수집 모듈이 구현할 최소 규격. 반환 표는 to_arena_bars() 를 통과할 수 있어야 한다."""

    name: str

    def fetch_bars(self, symbol: str, start: Optional[str] = None, end: Optional[str] = None) -> pd.DataFrame: ...


def to_arena_bars(df: pd.DataFrame, source: str, symbol: Optional[str] = None,
                  derive_trade_amount: bool = False) -> pd.DataFrame:
    """수집 결과 표 → Arena 봉 계약. 부족한 컬럼은 명시적으로만 채운다.

    - symbol 이 표에 없으면 인자 symbol 을 넣는다(둘 다 없으면 오류).
    - trade_amount 가 없을 때: derive_trade_amount=True 면 volume × close, 아니면 오류.
    - quality 표기가 UME 어휘(normal 등)면 Arena 어휘(GOOD 등)로 바꾼다.
    """
    x = df.copy()
    if "symbol" not in x.columns:
        if symbol is None:
            raise ValueError("symbol 이 표에도 인자에도 없습니다")
        x["symbol"] = symbol
    if "trade_amount" not in x.columns and "amount" not in x.columns and "turnover" not in x.columns:
        if not derive_trade_amount:
            raise ValueError("trade_amount 없음 (derive_trade_amount=True 로 volume×close 계산 허용 가능)")
        x["trade_amount"] = pd.to_numeric(x["volume"], errors="coerce") * pd.to_numeric(x["close"], errors="coerce")
    if "quality" in x.columns:
        x["quality"] = x["quality"].map(lambda q: QUALITY_FROM_UME.get(q, q))
    return normalize_bars(x, source)


def contract_report(df: pd.DataFrame) -> dict:
    """계약 점검 결과(수정 없음): 부족 컬럼, 시간 순서, 정규장 밖 봉 개수, 결측 셀."""
    missing = sorted(REQUIRED_BAR_COLUMNS - set(df.columns))
    problems: List[str] = []
    if missing:
        problems.append(f"필수 컬럼 없음: {missing}")
    out = {"ok": not missing, "missing_columns": missing, "rows": len(df), "problems": problems,
           "outside_session_rows": None, "null_cells": None}
    if missing:
        return out
    ts = pd.to_datetime(df["timestamp"])
    if getattr(ts.dt, "tz", None) is not None:
        ts = ts.dt.tz_localize(None)
    t = ts.dt.strftime("%H:%M")
    outside = int(((t < SESSION_OPEN) | (t > SESSION_CLOSE)).sum())
    out["outside_session_rows"] = outside
    if outside:
        problems.append(f"정규장({SESSION_OPEN}~{SESSION_CLOSE}) 밖 봉 {outside}개")
    nulls = int(df[sorted(REQUIRED_BAR_COLUMNS - {"timestamp", "symbol"})].isna().sum().sum())
    out["null_cells"] = nulls
    if nulls:
        problems.append(f"결측 셀 {nulls}개")
    if not ts.is_monotonic_increasing:
        problems.append("timestamp 가 오름차순이 아님(정규화 시 정렬됨)")
    return out
