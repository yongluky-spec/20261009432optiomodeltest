"""kospi_arena 모듈 테스트.
1) 기준값 대조: 원본 Arena 를 돌려 저장한 golden_arena_v4.json 과 같은 결과인가 (원본 파일 없이도 실행됨)
2) 원본 직접 대조: 환경변수 UME_ARENA_PATH 가 있으면 원본 파일과 같은 데이터로 바로 비교
3) 모듈 단독 동작 / 데이터 연결부(data_port)
실행: python tests/test_arena_modules.py   (01_strategy 폴더에서)
"""
import glob
import importlib.util
import json
import math
import os
import sys
import warnings

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
warnings.simplefilter("ignore")

import pandas as pd  # noqa: E402

import kospi_arena as K  # noqa: E402

CSV = os.path.join(HERE, "..", "..", "04_data", "demo_kospi_synthetic_bars.csv")
results = []


def check(name, cond):
    results.append((name, bool(cond)))
    print(f"{'PASS' if cond else 'FAIL'} - {name}")


def close(a, b, tol=1e-12):
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(close(a[k], b[k], tol) for k in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(close(x, y, tol) for x, y in zip(a, b))
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool):
        return abs(a - b) <= tol * max(1.0, abs(b))
    return a == b


def clean(o):
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, list):
        return [clean(v) for v in o]
    if isinstance(o, float):
        return None if not math.isfinite(o) else o
    if hasattr(o, "item"):
        return clean(o.item())
    return o


def main():
    bars = pd.read_csv(CSV, parse_dates=["timestamp"])
    gold = json.load(open(os.path.join(HERE, "golden_arena_v4.json"), encoding="utf-8"))

    # 1) 기준값 대조
    for key, n in (("rows_390", 390), ("rows_720", 720)):
        r = K.Arena().run_backtest_replay(bars.iloc[:n])
        g = gold[key]
        check(f"[{n}봉] Regime 일치", r.regime == g["regime"])
        check(f"[{n}봉] Regime 구성요소 일치", close(clean(r.market_state), g["state"]))
        check(f"[{n}봉] 모델 예측 일치", close(clean(r.predictions), g["predictions"]))
        check(f"[{n}봉] 센서 출력 일치", close(clean(r.sensors), g["sensors"]))
        check(f"[{n}봉] OOS 표 일치", close(clean(json.loads(r.oos.to_json(orient="records"))), g["oos"]))
        check(f"[{n}봉] Priority·사유 일치", (r.current_priority, r.current_reason) == (g["priority"], g["reason"]))
        check(f"[{n}봉] OOS 우수 모델 일치", r.oos_leader == g["oos_leader"])

    # 2) 원본 직접 대조 (선택)
    p = os.environ.get("UME_ARENA_PATH")
    if p:
        path = p if os.path.isfile(p) else (glob.glob(os.path.join(p, "kospi-model-arena-observatory*.py")) or [None])[0]
        if path:
            spec = importlib.util.spec_from_file_location("orig_arena", path)
            O = importlib.util.module_from_spec(spec)
            sys.modules["orig_arena"] = O
            spec.loader.exec_module(O)
            a, b = O.Arena().run_backtest_replay(bars.iloc[:390]), K.Arena().run_backtest_replay(bars.iloc[:390])
            check("원본 직접 대조: 예측·센서·OOS 동일",
                  a.predictions == b.predictions and a.sensors == b.sensors and a.oos.equals(b.oos))
    else:
        print("SKIP - 원본 직접 대조 (UME_ARENA_PATH 미지정)")

    # 3) 모듈 단독 동작
    x = K.normalize_bars(bars.iloc[:100], "t")
    check("모델 4개 단독 실행", all(m.predict(x)["model"] for m in
          (K.MomentumModel(), K.MeanReversionModel(), K.ThresholdModel(), K.BreakoutModel())))
    check("Regime 단독 실행", K.RegimeEngine().infer(x)[0] in
          {"TREND", "BREAKOUT_TRANSITION", "MEAN_REVERSION", "TRANSITION"})
    check("Wilson 하한 (60/100 → 0.5013)", abs(K.wilson_lower_bound(60, 100) - 0.5013) < 1e-3)
    check("sigmoid(0)=0.5", K.sigmoid(0) == 0.5)
    check("StateSpace 단독 실행", K.StateSpaceSensor().predict(x)["signal"] in
          {"UP_ACCELERATION", "DOWN_ACCELERATION", "CENTERED", "TRANSITION"})
    check("Friction 호가 없으면 DEGRADED", K.FrictionSensor().predict({})["signal"] == "ORDERBOOK_UNAVAILABLE")

    # 4) 데이터 연결부
    rep = K.contract_report(bars)
    check("contract_report: 필수 컬럼 충족", rep["ok"])
    check("contract_report: 정규장 밖 봉 탐지", rep["outside_session_rows"] == 329)
    raw = bars.drop(columns=["trade_amount", "symbol"]).iloc[:50]
    try:
        K.to_arena_bars(raw, "t", symbol="KOSPI")
        check("trade_amount 없으면 기본은 오류", False)
    except ValueError:
        check("trade_amount 없으면 기본은 오류", True)
    y = K.to_arena_bars(raw, "t", symbol="KOSPI", derive_trade_amount=True)
    check("옵션 지정 시 trade_amount = volume × close",
          abs(y["trade_amount"].iloc[0] - raw["volume"].iloc[0] * raw["close"].iloc[0]) < 1e-9)
    z = bars.iloc[:50].copy()
    z["quality"] = "normal"
    check("UME 품질 어휘 normal → GOOD 변환", (K.to_arena_bars(z, "t")["quality"] == "GOOD").all())

    failed = [n for n, ok in results if not ok]
    print(f"\n결과: {len(results) - len(failed)}/{len(results)} 통과")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
