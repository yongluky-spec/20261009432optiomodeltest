# UME 대시보드 + Arena 알고리즘 모듈 v0.1

## 무엇이 들어 있나
| 위치 | 내용 |
|---|---|
| `01_strategy/kospi_arena/` | Arena 알고리즘을 역할별 10개 파일로 분리 (원본 코드 그대로, import 경로만 변경) |
| `01_strategy/kospi_arena/data_port.py` | **데이터 수집 모듈 연결부** (BarSource 규격, 표 변환, 계약 점검, 품질 어휘 변환) |
| `01_strategy/tests/` | 모듈 테스트 25개 + 원본 실행 결과 기준값(`golden_arena_v4.json`) |
| `02_engine/universal_quant_engine/dashboard/` | 데이터 추적 대시보드 (전후 비교·공식·검증·신뢰도·이전 실행 대비) |
| `run_dashboard.py` | 실행기 (`--demo`, `--csv`, `--serve`) |
| `dashboard_out/monitor_dashboard_sample.html` | 데모 실행 결과 화면 |
| `04_data/demo_kospi_synthetic_bars.csv` | 데모용 가상 수집기 출력 (720행) |

기존 UME·수집·감시 파일 51개는 한 글자도 수정하지 않았습니다(추가만).

## 실행
```
python run_dashboard.py --demo                                   # 데모 (dashboard_out/monitor_dashboard.html)
python run_dashboard.py --csv 새데이터.csv --out dashboard.html   # 내 데이터
python run_dashboard.py --csv 새데이터.csv --serve               # http://127.0.0.1:8770 , /refresh 로 재실행
python run_dashboard.py --demo --arena-path 원본Arena폴더         # 분리 모듈 대신 원본 Arena 파일로 실행
```
- 실행할 때마다 현재 데이터가 다음 실행의 "이전 Snapshot"이 되고, 이번 요약이 "이전 실행"으로 저장됩니다(`monitor_data/`).
- 서버는 127.0.0.1 에만 열립니다.

## 테스트
```
python 02_engine/universal_quant_engine/tests/test_dashboard.py       # 40개
(cd 01_strategy && python tests/test_arena_modules.py)                # 25개
python 02_engine/universal_quant_engine/tests/test_v1.py              # 기존 14개
python 02_engine/universal_quant_engine/tests/test_collectors_v1.py   # 기존 15개
python run_monitor_test.py                                            # 기존 감시 테스트
```

## Arena 모듈 구조
`contract`(봉 규격·정규화) · `stats`(sigmoid·Wilson) · `models`(모델 4개) · `tir`(TIR v1/v2) · `sensors`(StateSpace·Friction) ·
`regime` · `ledger`(예측 원장) · `oos`(OOS 판정) · `scoring`(Regime 적합도·점수) · `arena`(실행기) · `data_port`(수집 연결부)

분리 후에도 결과가 같은지는 원본 Arena 를 실행해 저장한 기준값과 대조합니다(390봉·720봉에서 Regime·예측·센서·OOS·Priority 전부 일치).
이후 알고리즘을 고칠 때도 이 기준값 대비 어떤 값이 바뀌는지 먼저 확인하세요.

## 수집 모듈 통합 (추후)
1. 수집기 결과 표를 `to_arena_bars(df, source, symbol)` 에 넘기면 Arena 봉 규격이 됩니다. `trade_amount` 가 없으면 기본은 오류이고 `derive_trade_amount=True` 로 volume×close 계산을 허용할 수 있습니다.
2. 수집 모듈은 `BarSource.fetch_bars(symbol, start, end)` 를 구현하면 됩니다.
3. 품질 표기는 Arena(`GOOD`) ↔ UME(`normal`) 대응표(`QUALITY_FROM_UME`)로 변환됩니다.
4. `contract_report(df)` 로 넘기기 전에 점검하세요. 현재 가상 수집기 CSV 는 720행 중 329행이 정규장(09:00~15:30) 밖입니다.
5. 통합 시 정할 것: 수집기 파일(`synthetic_data_collector.py`)을 `collectors/` 의 Provider 로 옮길지, 장 시간 보정 규칙, Ledger·Friction 기준본.

## 개선 후보 (엔진에 반영하지 않음, 화면 ④ 하단에 근거 수치 표시)
① 최신성이 가상·재생 데이터도 감점 ② 결측률 이중 감점(완결성+오염도) ③ 원천 일치가 최대값 기준·고정 절대 허용오차
④ 연속성 검증이 분봉에서 항상 통과 ⑤ 변경 감지에 수치 허용 오차 없음(대시보드는 자체 로더로 회피, ChangeDetector 는 그대로)
