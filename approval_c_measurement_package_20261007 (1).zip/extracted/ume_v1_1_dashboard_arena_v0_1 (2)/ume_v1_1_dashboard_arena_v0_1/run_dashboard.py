"""UME 데이터 추적 대시보드 실행기.

사용 예
  python run_dashboard.py --demo --out dashboard_out/monitor_dashboard.html
  python run_dashboard.py --csv 새데이터.csv --arena-path Arena폴더 --out dashboard.html
  python run_dashboard.py --csv 새데이터.csv --serve            # http://127.0.0.1:8770  (/refresh 로 재실행)

- 실행할 때마다 현재 데이터가 다음 실행의 '이전 Snapshot'이 되고, 이번 요약이 '이전 실행'으로 저장된다.
- Arena: --arena-path(원본 파일/폴더) 또는 UME_ARENA_PATH. 둘 다 없으면 01_strategy/kospi_arena 모듈 묶음을 쓴다.
- 이 스크립트는 표시와 저장만 하며 엔진·Arena 의 계산을 바꾸지 않는다.
"""
import argparse
import os
import sys
import tempfile
import warnings
import webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "02_engine"))
sys.path.insert(0, os.path.join(ROOT, "01_strategy"))
warnings.simplefilter("ignore")

import pandas as pd  # noqa: E402

from universal_quant_engine.dashboard import DashboardRunner  # noqa: E402
from universal_quant_engine.dashboard.demo import build_demo_pair  # noqa: E402
from universal_quant_engine.dashboard.render import render_html  # noqa: E402
from universal_quant_engine.dashboard.server import HOST, make_server  # noqa: E402

DEMO_CSV = os.path.join(ROOT, "04_data", "demo_kospi_synthetic_bars.csv")


def parse_args():
    p = argparse.ArgumentParser(description="UME 데이터 추적 대시보드")
    p.add_argument("--csv", help="현재 데이터 CSV (Arena 봉 규격)")
    p.add_argument("--demo", action="store_true", help="04_data 의 가상 데이터로 이전/현재 시나리오를 만들어 실행")
    p.add_argument("--symbol", default=None)
    p.add_argument("--arena-path", default=None, help="원본 Arena 파일 또는 폴더 (미지정 시 kospi_arena 모듈)")
    p.add_argument("--data-dir", default=None, help="Snapshot/실행 이력 저장 폴더 (기본 monitor_data, --demo 는 임시 폴더)")
    p.add_argument("--out", default="dashboard_out/monitor_dashboard.html")
    p.add_argument("--serve", action="store_true")
    p.add_argument("--port", type=int, default=8770)
    p.add_argument("--no-open", action="store_true")
    return p.parse_args()


def main():
    a = parse_args()
    if not a.demo and not a.csv:
        sys.exit("--csv 또는 --demo 중 하나가 필요합니다")

    if a.demo:
        data_dir = a.data_dir or tempfile.mkdtemp(prefix="ume_dash_demo_")
        runner = DashboardRunner(data_dir, arena_path=a.arena_path)
        prev, cur, frames = build_demo_pair(DEMO_CSV)
        runner.run(prev, symbol=a.symbol or "KOSPI")  # 기준 실행: 이번 결과가 다음의 '이전'이 된다
        note = ("데모 데이터입니다: 가상 수집기 CSV 의 1일(390봉)을 이전으로, 그 위에 '마지막 3봉 수정 + 5봉 추가 + 거래량 결측 2건'을 "
                "얹은 것을 현재로 사용했습니다. 시나리오 값은 실제 시장 데이터가 아닙니다.")
        provider = lambda: {**runner.run(cur, symbol=a.symbol or "KOSPI", source_frames=frames), }  # noqa: E731
        first = provider()
        first["meta"]["note"] = note
        report = first
    else:
        data_dir = a.data_dir or "monitor_data"
        runner = DashboardRunner(data_dir, arena_path=a.arena_path)

        def provider():
            df = pd.read_csv(a.csv, parse_dates=["timestamp"])
            return runner.run(df, symbol=a.symbol)
        report = provider()

    page = render_html(report)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        f.write(page)
    s = report["summary"]
    print(f"상태 {s['status']} · 신뢰도 {s['score']} · 검증 {s['validation']['passed_count']}/{s['validation']['total']} · "
          f"변경 {s['changes']['changed_count']}행 · Arena {'연결' if s['arena'].get('available') else '미연결'}")
    print(f"저장: {os.path.abspath(a.out)}")

    if a.serve:
        srv, _ = make_server(provider, a.port)
        url = f"http://{HOST}:{a.port}/"
        print(f"서버: {url}  (종료 Ctrl+C, 재실행 {url}refresh)")
        if not a.no_open:
            webbrowser.open(url)
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
