"""STEPS — 모델·센서·Regime 의 공식을 단계별로 펼치고, 이전 실행/현재 실행의 값을 나란히 놓는다.

입력은 저장된 실행 요약(summary["arena"])뿐이다. 값은 Arena 가 낸 수치와 그 입력값이며,
'대입' 문자열만 여기서 만든다. 공식 자체는 Arena 코드(v4)를 그대로 옮긴 표기다.
"""
import math
from typing import Any, Dict, List, Optional

from .util import g, isnum


def wilson_parts(k: int, n: int, z: float = 1.96) -> Optional[Dict[str, float]]:
    """Arena 의 wilson_lower_bound 를 단계별로 분해한 값 (Arena 와 같은 식)."""
    if n <= 0:
        return None
    p = k / n
    denom = 1 + z * z / n
    centre = p + z * z / (2 * n)
    margin = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return {"p": p, "denom": denom, "centre": centre, "margin": margin, "lower": (centre - margin) / denom}


def _s(label, formula, subst, prev, curr, nd=4, kind="num"):
    return {"label": label, "formula": formula, "subst": subst, "prev": prev, "curr": curr, "nd": nd, "kind": kind}


def _get(d: Optional[dict], *path):
    for p in path:
        if d is None:
            return None
        d = d.get(p) if isinstance(d, dict) else None
    return d


def model_steps(name: str, ca: dict, pa: Optional[dict]) -> List[Dict[str, Any]]:
    """name: Momentum / Hook_OU / Threshold / Breakout / Regime / StateSpace. ca/pa: summary['arena'] (현재/이전)."""
    ci = ca["inputs"]
    pi = pa["inputs"] if (pa and pa.get("available")) else None
    cm = ca["models"].get(name, {})
    pm = (pa or {}).get("models", {}).get(name, {}) if pi else {}

    def I(*p):  # 현재 입력
        return _get(ci, *p)

    def P(*p):  # 이전 입력
        return _get(pi, *p) if pi else None

    st: List[Dict[str, Any]] = []
    if name == "Momentum":
        k = I("Momentum", "k")
        st = [
            _s("close_t (현재 종가)", "입력", "", P("Momentum", "close_t"), I("Momentum", "close_t")),
            _s("close_t-5 (5봉 전 종가)", "입력", "", P("Momentum", "close_t5"), I("Momentum", "close_t5")),
            _s("ret5", "close_t ÷ close_t-5 - 1",
               f"{g(I('Momentum', 'close_t'))} ÷ {g(I('Momentum', 'close_t5'))} - 1",
               P("Momentum", "ret5"), I("Momentum", "ret5"), 6),
            _s("p_up", f"sigmoid(ret5 × {k})", f"sigmoid({g(I('Momentum', 'ret5'))} × {k})",
               pm.get("p_up"), cm.get("p_up")),
            _s("strength", "|p_up - 0.5| × 2", f"|{g(cm.get('p_up'))} - 0.5| × 2", pm.get("strength"), cm.get("strength")),
            _s("방향", "p_up ≥ 0.5 → UP, 아니면 DOWN", f"p_up = {g(cm.get('p_up'))}",
               pm.get("direction"), cm.get("direction"), kind="text"),
        ]
    elif name == "Hook_OU":
        k = I("Hook_OU", "k")
        st = [
            _s("close_t (현재 종가)", "입력", "", P("Hook_OU", "px"), I("Hook_OU", "px")),
            _s("MA20", "최근 20봉 종가 평균", "", P("Hook_OU", "ma20"), I("Hook_OU", "ma20")),
            _s("z", "close_t ÷ MA20 - 1", f"{g(I('Hook_OU', 'px'))} ÷ {g(I('Hook_OU', 'ma20'))} - 1",
               P("Hook_OU", "z"), I("Hook_OU", "z"), 6),
            _s("p_up", f"sigmoid(-z × {k})", f"sigmoid(-({g(I('Hook_OU', 'z'))}) × {k})", pm.get("p_up"), cm.get("p_up")),
            _s("예상 수익률", "-z", f"-({g(I('Hook_OU', 'z'))})", pm.get("predicted_return"), cm.get("predicted_return"), 6),
            _s("방향", "p_up ≥ 0.5 → UP, 아니면 DOWN", f"p_up = {g(cm.get('p_up'))}",
               pm.get("direction"), cm.get("direction"), kind="text"),
        ]
    elif name == "Threshold":
        st = [
            _s("r10", "최근 10봉 수익률 평균", "", P("Threshold", "r10"), I("Threshold", "r10"), 6),
            _s("v20", "최근 20봉 수익률 표준편차", "", P("Threshold", "v20"), I("Threshold", "v20"), 6),
            _s("score", "r10 ÷ v20", f"{g(I('Threshold', 'r10'))} ÷ {g(I('Threshold', 'v20'))}",
               P("Threshold", "score"), I("Threshold", "score")),
            _s("p_up", "sigmoid(score)", f"sigmoid({g(I('Threshold', 'score'))})", pm.get("p_up"), cm.get("p_up")),
            _s("strength", "min(1, |score| ÷ 3)", f"min(1, |{g(I('Threshold', 'score'))}| ÷ 3)",
               pm.get("strength"), cm.get("strength")),
            _s("방향", "p_up ≥ 0.5 → UP, 아니면 DOWN", f"p_up = {g(cm.get('p_up'))}",
               pm.get("direction"), cm.get("direction"), kind="text"),
        ]
    elif name == "Breakout":
        px, hh, ll = I("Breakout", "px"), I("Breakout", "hh"), I("Breakout", "ll")
        st = [
            _s("close_t (현재 종가)", "입력", "", P("Breakout", "px"), px),
            _s("직전 20봉 최고가", "현재 봉을 뺀 20봉 high 의 최대", "", P("Breakout", "hh"), hh),
            _s("직전 20봉 최저가", "현재 봉을 뺀 20봉 low 의 최소", "", P("Breakout", "ll"), ll),
            _s("신호", "종가 > 최고가 → UP_BREAKOUT / 종가 < 최저가 → DOWN_BREAKOUT / 그 외 NO_BREAKOUT",
               f"{g(px)} vs [{g(ll)}, {g(hh)}]", pm.get("signal"), cm.get("signal"), kind="text"),
            _s("actionable", "NO_BREAKOUT 은 원장·Priority 에서 제외", "", pm.get("actionable"), cm.get("actionable"),
               kind="text"),
        ]
    elif name == "Regime":
        r = ca["regime_parts"]
        p_r = pa["regime_parts"] if pi else {}
        st = [
            _s("distance_ma", "close ÷ MA20 - 1", f"{g(I('Regime', 'px'))} ÷ {g(I('Regime', 'ma20'))} - 1",
               p_r.get("distance_ma"), r.get("distance_ma"), 6),
            _s("trend", "clip(|distance_ma| × 40, 0, 1)", f"clip(|{g(r.get('distance_ma'))}| × 40, 0, 1)",
               p_r.get("trend"), r.get("trend")),
            _s("mom10", "최근 10봉 수익률 평균", "", P("Regime", "mom10"), I("Regime", "mom10"), 6),
            _s("momentum", "clip(|mom10| × 200, 0, 1)", f"clip(|{g(I('Regime', 'mom10'))}| × 200, 0, 1)",
               p_r.get("momentum"), r.get("momentum")),
            _s("volatility", "일간 환산 변동성이 자기 이력에서 차지하는 분위수 (이력 부족 시 0.5)",
               "Arena 가 낸 값을 그대로 표시", p_r.get("volatility"), r.get("volatility")),
            _s("Regime", "TREND / BREAKOUT_TRANSITION / MEAN_REVERSION / TRANSITION (아래 규칙 대조)", "",
               pa.get("regime") if pi else None, ca["regime"], kind="text"),
        ]
    elif name == "StateSpace":
        cs = ca["sensors"].get("StateSpace", {})
        ps = (pa or {}).get("sensors", {}).get("StateSpace", {}) if pi else {}
        st = [
            _s("MA20", "최근 20봉 종가 평균", "", P("StateSpace", "ma20"), I("StateSpace", "ma20")),
            _s("ATR14", "최근 14봉 (high - low) 평균", "", P("StateSpace", "atr14"), I("StateSpace", "atr14")),
            _s("x (위치)", "(close - MA20) ÷ ATR14",
               f"({g(I('StateSpace', 'px'))} - {g(I('StateSpace', 'ma20'))}) ÷ {g(I('StateSpace', 'atr14'))}",
               ps.get("x"), cs.get("x")),
            _s("v (속도)", "x_t - x_t-1", f"{g(I('StateSpace', 'x_t'))} - ({g(I('StateSpace', 'x_t1'))})",
               ps.get("v"), cs.get("v")),
            _s("a (가속)", "v_t - v_t-1 = x_t - 2·x_t-1 + x_t-2",
               f"{g(I('StateSpace', 'x_t'))} - 2×({g(I('StateSpace', 'x_t1'))}) + ({g(I('StateSpace', 'x_t2'))})",
               ps.get("a"), cs.get("a")),
            _s("상태", "x>1 & v>0 UP_ACCELERATION / x<-1 & v<0 DOWN_ACCELERATION / |x|<0.5 CENTERED / 그 외 TRANSITION",
               f"x = {g(cs.get('x'))}, v = {g(cs.get('v'))}", ps.get("signal"), cs.get("signal"), kind="text"),
            _s("strength", "min(1, |x| ÷ 3)", f"min(1, |{g(cs.get('x'))}| ÷ 3)", ps.get("strength"), cs.get("strength")),
        ]
    return st


def regime_rules(ca: dict) -> List[Dict[str, Any]]:
    """Regime 판정 규칙을 실제 값으로 대조 (Arena RegimeEngine.infer 의 if/elif 순서)."""
    r = ca["regime_parts"]
    t, m, v = r.get("trend") or 0.0, r.get("momentum") or 0.0, r.get("volatility") or 0.0
    rules = [
        ("TREND", f"trend > 0.75 그리고 momentum > 0.6", f"{g(t)} > 0.75 이고 {g(m)} > 0.6", t > .75 and m > .6),
        ("BREAKOUT_TRANSITION", "volatility > 0.75 그리고 trend > 0.5", f"{g(v)} > 0.75 이고 {g(t)} > 0.5", v > .75 and t > .5),
        ("MEAN_REVERSION", "trend < 0.25 그리고 momentum < 0.35", f"{g(t)} < 0.25 이고 {g(m)} < 0.35", t < .25 and m < .35),
        ("TRANSITION", "위 조건 모두 아님", "—", True),
    ]
    out, decided = [], False
    for name, cond, subst, fires in rules:
        if decided:
            out.append({"name": name, "cond": cond, "subst": subst, "fired": False, "evaluated": False})
            continue
        out.append({"name": name, "cond": cond, "subst": subst, "fired": bool(fires), "evaluated": True})
        decided = decided or bool(fires)
    return out
