"""SERVER — 대시보드를 127.0.0.1 에서만 여는 작은 서버 (표준 라이브러리만 사용).

- 바인딩: 127.0.0.1 고정 (SEC-001/002). 외부 접속을 열지 않는다.
- GET /          마지막으로 만든 화면
- GET /refresh   provider() 를 다시 실행해 새 화면을 만들고 / 로 이동
- GET /state.json 마지막 실행 요약(JSON)
"""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable, Dict, Tuple

from .render import render_html

HOST = "127.0.0.1"


def make_server(provider: Callable[[], Dict], port: int = 8770) -> Tuple[ThreadingHTTPServer, Callable[[], None]]:
    """provider: 실행할 때마다 새 report(dict)를 돌려주는 함수. 반환: (서버, 화면 갱신 함수)"""
    state = {"html": "", "summary": {}}
    lock = threading.Lock()

    def refresh() -> None:
        report = provider()
        page = render_html(report)
        with lock:
            state["html"] = page
            state["summary"] = report["summary"]

    class Handler(BaseHTTPRequestHandler):
        def _send(self, code, body: bytes, ctype: str):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):  # noqa: N802
            path = self.path.split("?")[0]
            if path == "/refresh":
                try:
                    refresh()
                except Exception as exc:  # noqa: BLE001
                    self._send(500, f"새로고침 실패: {type(exc).__name__}: {exc}".encode("utf-8"), "text/plain; charset=utf-8")
                    return
                self.send_response(303)
                self.send_header("Location", "/")
                self.end_headers()
            elif path == "/state.json":
                with lock:
                    body = json.dumps(state["summary"], ensure_ascii=False).encode("utf-8")
                self._send(200, body, "application/json; charset=utf-8")
            elif path == "/":
                with lock:
                    body = state["html"].encode("utf-8")
                self._send(200, body, "text/html; charset=utf-8")
            else:
                self._send(404, b"not found", "text/plain; charset=utf-8")

        def log_message(self, *a):  # 콘솔 소음 제거
            pass

    refresh()
    return ThreadingHTTPServer((HOST, port), Handler), refresh
