"""RENDER — report(dict) → 자체 완결형 HTML 한 장. 외부 스크립트/폰트/이미지를 불러오지 않는다.

배치(정보 우선순위): ① 현재 상태 → ② 데이터 전후 비교 → ③ 검증 → ④ 신뢰도 계산 → ⑤ 이전 실행 대비 변화
→ (접기) Arena 세부 모델/센서/OOS.  표시만 하며 어떤 계산도 바꾸지 않는다.
"""
import html
from typing import Any, Dict, List, Optional

from .steps import model_steps, regime_rules, wilson_parts
from .util import f4, g, isnum, show

STATUS_TEXT = {
    "NORMAL": "변경 없음 · 검증과 신뢰도 정상",
    "CHANGED": "데이터 변경 있음 · 검증과 신뢰도 정상",
    "WARNING": "신뢰도 또는 원천 일치율이 기준 미달",
    "ERROR": "데이터 검증 실패",
}

CSS = """
:root{--paper:#f2f4f7;--panel:#fff;--ink:#17212b;--muted:#5a6675;--line:#d3d9e0;--prev:#69768a;--curr:#0b57c4;
--ok:#137247;--okbg:#e4f3ea;--warn:#9a5a00;--warnbg:#fff1d6;--fail:#b3261e;--failbg:#fde7e5;--info:#0b57c4;--infobg:#e3eefc;
--chg:#fff6cf;--mono:ui-monospace,"D2Coding","JetBrains Mono",Consolas,"Malgun Gothic",monospace;
--sans:"Pretendard","Noto Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:64px}
body{margin:0;background:var(--paper);color:var(--ink);font:15px/1.6 var(--sans)}
a{color:var(--curr)}code,.mono{font-family:var(--mono)}
header.top{position:sticky;top:0;z-index:5;background:#17212b;color:#fff;padding:10px 20px;display:flex;flex-wrap:wrap;gap:8px 18px;align-items:center}
header.top h1{font-size:16px;margin:0;font-weight:700}header.top .meta{color:#b8c3d1;font-size:13px}
header.top nav{display:flex;flex-wrap:wrap;gap:4px 14px;margin-left:auto}header.top nav a{color:#dbe6f5;text-decoration:none;font-size:14px}
header.top nav a:hover,header.top nav a:focus-visible{text-decoration:underline;color:#fff}
main{max-width:1240px;margin:0 auto;padding:18px 16px 60px}
section,details.sec{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:18px 20px;margin:0 0 18px}
h2{font-size:19px;margin:0 0 4px}h3{font-size:15.5px;margin:20px 0 6px}h2+.lead{margin-top:0}
.lead{color:var(--muted);margin:0 0 12px;font-size:14px}
table{border-collapse:collapse;width:100%;font-size:13.5px;font-variant-numeric:tabular-nums}
th,td{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left;vertical-align:top}
th{background:#eef1f5;font-weight:600;white-space:nowrap}td.num,th.num{text-align:right}
.scroll{overflow-x:auto}tr.same td{color:var(--muted)}tr.chg td{background:var(--chg)}tr.noise td{background:#f1e9ff}
.pv{color:var(--prev)}.cv{color:var(--curr);font-weight:600}.ar{color:var(--muted);margin:0 6px}
.up{color:#0b6b3a}.dn{color:#a4301f}.d0{color:var(--muted)}
.badge{display:inline-block;padding:1px 8px;border-radius:10px;font-size:12.5px;font-weight:600;border:1px solid transparent}
.b-ok{background:var(--okbg);color:var(--ok)}.b-warn{background:var(--warnbg);color:var(--warn)}.b-fail{background:var(--failbg);color:var(--fail)}
.b-info{background:var(--infobg);color:var(--info)}.b-na{background:#e9edf1;color:var(--muted)}
.formula{font-family:var(--mono);font-size:13px;background:#f5f7fa;border:1px solid var(--line);border-left:3px solid var(--curr);padding:6px 10px;margin:4px 0;white-space:pre-wrap;word-break:break-word}
.hero{display:grid;grid-template-columns:minmax(220px,300px) 1fr;gap:16px;border:1px solid var(--line);border-radius:6px;padding:14px;margin:8px 0 12px}
.hero .vword{font-size:30px;font-weight:800;line-height:1.1}.hero .vtext{color:var(--muted);margin-top:4px}
.st-NORMAL .vword{color:var(--ok)}.st-CHANGED .vword{color:var(--info)}.st-WARNING .vword{color:var(--warn)}.st-ERROR .vword{color:var(--fail)}
ol.chain{margin:0;padding-left:20px;font-size:13.5px}ol.chain li{margin:2px 0}ol.chain li.fired{font-weight:700;background:var(--chg);padding:0 4px}
ol.chain li.skip{color:#9aa4b1}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin:0 0 6px}
.kpi{border:1px solid var(--line);border-radius:6px;padding:10px 12px}.kpi .k{color:var(--muted);font-size:13px}
.kpi .v{font-size:26px;font-weight:700;line-height:1.2}.kpi .s{font-size:12.5px;color:var(--muted);font-family:var(--mono)}
.qa{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:12px;margin-top:10px}
.qa>div{border:1px solid var(--line);border-radius:6px;padding:10px 14px}.qa h3{margin:0 0 6px;font-size:14.5px}.qa ul{margin:0;padding-left:18px;font-size:13.5px}
ol.flow{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(auto-fit,minmax(178px,1fr));gap:8px}
.stage{border:1px solid var(--line);border-top:4px solid var(--line);border-radius:4px;padding:8px 10px;font-size:12.5px;height:100%;background:#fbfcfd}
.stage.s-ok{border-top-color:var(--ok)}.stage.s-info{border-top-color:var(--info)}.stage.s-warn{border-top-color:var(--warn)}
.stage.s-fail{border-top-color:var(--fail)}.stage.s-na{border-top-color:#aab3bf;background:#f1f3f5}
.stage b{display:block;font-size:13.5px;margin-bottom:2px}.stage .io{color:var(--muted)}.stage .out{margin-top:3px}
.stage .was{color:var(--prev);font-size:12px;margin-top:3px}.stage a{text-decoration:none;color:inherit}
.bar{background:#e6eaef;height:9px;border-radius:5px;min-width:90px;overflow:hidden}.bar i{display:block;height:100%;background:var(--curr)}
.bar.full i{background:var(--ok)}.bar.low i{background:var(--warn)}
.cand{border:1px dashed #b9a06a;background:#fffbef;border-radius:6px;padding:10px 14px;margin:8px 0}
.cand h4{margin:0 0 4px;font-size:14.5px}.cand ul{margin:4px 0;padding-left:18px;font-size:13.5px}.cand .imp{font-size:13px;color:#5b4a1b}
details>summary{cursor:pointer;font-weight:600}details.sec>summary{font-size:18px}
details.grp{margin:10px 0}details.grp>summary{font-size:14.5px;padding:2px 0}
.note{font-size:12.5px;color:var(--muted)}.warnline{color:var(--warn);font-size:13px}
.only-changed tr.same{display:none}.toolbar{display:flex;gap:16px;align-items:center;margin:6px 0 10px;font-size:14px}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(420px,1fr));gap:14px}
.card{border:1px solid var(--line);border-radius:6px;padding:10px 12px}.card h4{margin:0 0 6px;font-size:14.5px}
.demo{background:var(--warnbg);border:1px solid #e3c987;color:#5b3d00;padding:8px 12px;border-radius:6px;margin:0 0 14px;font-size:13.5px}
@media (max-width:760px){.hero{grid-template-columns:1fr}header.top nav{margin-left:0}}
"""


def e(x) -> str:
    return html.escape("" if x is None else str(x))


def _sd(d, nd) -> str:
    if not isnum(d):
        return ""
    d = float(d)
    if d != 0 and abs(d) < 10 ** (-nd):
        return ("+" if d > 0 else "-") + f"{abs(d):.2e}"
    return f"{d:+,.{nd}f}"


def delta(p, c, nd=4) -> str:
    if isnum(p) and isnum(c):
        d = float(c) - float(p)
        cls = "d0" if abs(d) < 1e-12 else ("up" if d > 0 else "dn")
        return f'<span class="{cls}">Δ {e(_sd(d, nd))}</span>'
    return ""


def pc(p, c, nd=4, has_prev=True) -> str:
    """이전 → 현재 (Δ) 한 칸."""
    if not has_prev:
        return f'<span class="cv">{e(show(c, nd))}</span> <span class="note">(이전 실행 없음)</span>'
    return (f'<span class="pv">{e(show(p, nd))}</span><span class="ar">→</span>'
            f'<span class="cv">{e(show(c, nd))}</span> {delta(p, c, nd)}')


def badge(text, kind) -> str:
    return f'<span class="badge b-{kind}">{e(text)}</span>'


def _pass(b) -> str:
    return badge("PASS", "ok") if b else badge("FAIL", "fail")


def _table(head: List[str], rows: List[str], cls="") -> str:
    th = "".join(f"<th>{h}</th>" for h in head)
    return f'<div class="scroll"><table class="{cls}"><thead><tr>{th}</tr></thead><tbody>{"".join(rows)}</tbody></table></div>'


# ----------------------------------------------------------------------------- ① 현재 상태
def sec_status(r: Dict[str, Any]) -> str:
    s, ps = r["summary"], r["prev_summary"]
    hp = ps is not None
    chain = "".join(
        f'<li class="{"fired" if c["fired"] else ("skip" if not c["evaluated"] else "")}">'
        f'{e(c["question"])} — {e(c["actual"])} → <b>{e(c["result"])}</b>'
        f'{" ◀ 판정" if c["fired"] else ("" if c["evaluated"] else " (앞에서 결정되어 미평가)")}</li>'
        for c in r["status_chain"])
    ch = s["changes"]
    a = s["arena"]
    kpis = [
        ('신뢰도 (0~100)', e(s["score"]), f'{e(r["reliability"]["score_substituted"])}',
         pc(ps["score"], s["score"], 1) if hp else ""),
        ('검증', f'{s["validation"]["passed_count"]}/{s["validation"]["total"]} 통과',
         "6개 검증기 기준 → 실측 → 판정 (③)",
         pc(ps["validation"]["passed_count"], s["validation"]["passed_count"], 0) if hp else ""),
        ('변경된 행', f'{ch["changed_count"]}행', f'추가 {ch["added"]} · 수정 {ch["modified"]} · 삭제 {ch["removed"]}',
         pc(ps["changes"]["changed_count"], ch["changed_count"], 0) if hp else ""),
    ]
    if a.get("available"):
        kpis.append(('Regime / 최우선 모델', e(a["regime"]), f'Priority {e(a["priority"]["name"] or "없음")}',
                     pc(ps["arena"].get("regime"), a["regime"], 0) if hp and ps["arena"].get("available") else ""))
    else:
        kpis.append(('Regime / 최우선 모델', "미연결", "Arena 를 연결하면 표시됩니다", ""))
    k_html = "".join(f'<div class="kpi"><div class="k">{k}</div><div class="v">{v}</div><div class="s">{sub}</div>'
                     f'<div class="s">{cmp_}</div></div>' for k, v, sub, cmp_ in kpis)

    ans = r["answers"]
    qa = ('<div class="qa"><div><h3>왜 신뢰도가 %s점인가?</h3><ul>%s</ul></div>' % (
        e(s["score"]), "".join(f"<li>{e(x)}</li>" for x in ans["why_score"])))
    qa += ('<div><h3>어떤 데이터 변화로 모델 결과가 바뀌었나?</h3><ul>%s</ul></div></div>' % (
        "".join(f"<li>{e(x)}</li>" for x in ans["why_model"]) if ans["why_model"]
        else "<li>Arena 미연결 또는 모델 출력 없음 (Arena 세부에서 사유 확인)</li>"))

    stages = []
    pst = {x["id"]: x for x in (r["prev_stages"] or [])}
    for st in r["stages"]:
        was = ""
        if st["id"] in pst and pst[st["id"]]["output"] != st["output"]:
            was = f'<div class="was">이전: {e(pst[st["id"]]["output"])}</div>'
        stages.append(f'<li class="stage s-{st["status"]}"><a href="#{st["anchor"]}"><b>{e(st["name"])}</b>'
                      f'<div class="io">입력: {e(st["input"])}</div><div class="out">출력: {e(st["output"])}</div>{was}</a></li>')
    flow = f'<h3 id="sec-flow">데이터 → 결과 추적 흐름 (각 단계의 입력과 출력)</h3><ol class="flow">{"".join(stages)}</ol>'
    return (f'<section id="sec-status"><h2>① 현재 상태</h2><p class="lead">{e(s["symbol"])} · {e(s["rows"])}행 · '
            f'실행 {e(s["generated_at"])}</p>'
            f'<div class="hero st-{e(s["status"])}"><div><div class="vword">{e(s["status"])}</div>'
            f'<div class="vtext">{e(STATUS_TEXT.get(s["status"], ""))}</div></div>'
            f'<div><b>판정 경로</b> (위에서부터 처음 걸린 규칙이 상태가 됩니다)<ol class="chain">{chain}</ol></div></div>'
            f'<div class="kpis">{k_html}</div>{qa}{flow}</section>')


# ----------------------------------------------------------------------------- ② 데이터 전후 비교
def sec_change(r: Dict[str, Any]) -> str:
    c = r["changes"]
    s, ps, m = r["summary"], r["prev_summary"], r["meta"]
    sm = c["summary"]
    if m["has_prev_snapshot"]:
        head = (f'이전 Snapshot {m["prev_snapshot_rows"]:,}행 ({e(str(ps["last_ts"])[:16]) if ps else "?"} 까지) → '
                f'현재 {s["rows"]:,}행 ({e(str(s["last_ts"])[:16])} 까지)')
    else:
        head = "이전 Snapshot 이 없어 비교할 수 없습니다. 이번 실행이 다음 비교의 기준이 됩니다."
    chips = " ".join(badge(f"{k} {v}", "info" if v and k != "동일" else "na") for k, v in
                     (("추가", sm["added"]), ("삭제", sm["removed"]), ("수정", sm["modified"]), ("동일", sm["unchanged"])))
    formulas = ('<div class="formula">Δ  (절대 변화량) = 현재값 - 이전값\n'
                'Δ% (변화율)    = (현재값 - 이전값) ÷ 이전값 × 100</div>')
    rows = []
    for x in c["rows"]:
        cls = "noise" if x["kind"] == "부동소수점 잡음 의심" else "chg"
        cons = ", ".join(x["consumers"]) or "—"
        calc = (f'<div class="mono">{e(x["delta_formula"])}</div>'
                + (f'<div class="mono">{e(x["pct_formula"])}</div>' if x["pct_formula"] else ""))
        rows.append(f'<tr class="{cls}"><td class="mono">{e(x["key"])}</td><td><b>{e(x["field"])}</b></td>'
                    f'<td>{e(x["kind"])}</td><td class="num">{e(show(x["prev"]))}</td><td class="num"><b>{e(show(x["curr"]))}</b></td>'
                    f'<td>{calc}</td><td class="note">{e(cons)}</td></tr>')
    mod_tbl = (_table(["행(symbol @ 시각)", "필드", "종류", "이전", "현재", "계산 (실제 값 대입)", "이 값이 들어가는 계산"], rows)
               if rows else '<p class="note">값이 바뀐 기존 행이 없습니다.</p>')
    more = (f'<p class="note">변경 필드 {c["rows_total"]}건 중 {len(c["rows"])}건만 표시했습니다.</p>'
            if c["rows_total"] > len(c["rows"]) else "")
    noise = (f'<p class="warnline">부동소수점 잡음 의심 {c["noise_count"]}건(|Δ%| &lt; 1e-9, 보라색 행)이 있습니다. 개선 후보 ⑤ 참고.</p>'
             if c["noise_count"] else "")

    def rowset(items, title, total):
        if not items:
            return ""
        body = "".join(
            f'<tr><td class="mono">{e(i["key"])}</td>' + "".join(
                f'<td class="num">{e(show(i.get(k)))}</td>' for k in ("open", "high", "low", "close", "volume"))
            + f'<td>{e(i.get("source"))}</td></tr>' for i in items)
        more2 = f'<p class="note">{total}행 중 {len(items)}행만 표시</p>' if total > len(items) else ""
        return (f"<h3>{title} ({total}행)</h3>"
                + _table(["행(symbol @ 시각)", "open", "high", "low", "close", "volume", "source"], [body]) + more2)
    return (f'<section id="sec-change"><h2>② 데이터 전후 비교</h2><p class="lead">{head}</p>{chips}{formulas}'
            f'<h3>값이 바뀐 기존 행 ({sm["modified"]}행)</h3>{mod_tbl}{more}{noise}'
            f'{rowset(c["added"], "새로 추가된 행", c["added_total"])}{rowset(c["removed"], "삭제된 행", c["removed_total"])}</section>')


# ----------------------------------------------------------------------------- ③ 검증
def sec_valid(r: Dict[str, Any]) -> str:
    ps = r["prev_summary"]
    rows = []
    for v in r["validation"]:
        prev_meas = ps["validation"]["items"].get(v["id"], {}).get("measured") if ps else None
        cmp_ = (pc(prev_meas, v["measured"], 6) if ps else '<span class="note">이전 없음</span>')
        rows.append(
            f'<tr><td><b>{e(v["name"])}</b><div class="note">{e(v["id"])}</div></td><td>{e(v["criterion"])}</td>'
            f'<td class="mono">{e(v["formula"])}</td><td class="mono">{e(v["substituted"])}'
            f'{"<div class=warnline>" + e(v["note"]) + "</div>" if v["note"] else ""}</td>'
            f'<td><b>{e(v["measured_text"])}</b></td><td>{_pass(v["passed"])}</td><td>{cmp_}</td></tr>')
    s = r["summary"]["validation"]
    return (f'<section id="sec-valid"><h2>③ 검증</h2><p class="lead">각 검증은 기준 → 실제 측정값 → 판정 순서로 봅니다. '
            f'전체 {s["passed_count"]}/{s["total"]} 통과.</p>'
            + _table(["검증", "기준", "측정 공식", "실제 대입", "실측", "판정", "이전 실행 → 현재 실측"], rows) + "</section>")


# ----------------------------------------------------------------------------- ④ 신뢰도
def sec_rel(r: Dict[str, Any]) -> str:
    rel, ps = r["reliability"], r["prev_summary"]
    rows = []
    for i in rel["items"]:
        pv = ps["reliability"].get(i["key"]) if ps else None
        w = max(0.0, min(100.0, i["contribution"] / (100 / 6) * 100))
        cls = "full" if i["full"] else "low"
        chk = "" if i["match"] else f' <span class="badge b-warn">재계산 {e(f4(i["recomputed"]))} ≠ 엔진</span>'
        linked = ", ".join(i["linked"]) or "—"
        rows.append(
            f'<tr class="{"same" if i["full"] else "chg"}"><td><b>{e(i["name"])}</b></td>'
            f'<td class="mono">{e(i["formula"])}</td><td>{e(i["inputs"])}</td><td class="mono">{e(i["substituted"])}{chk}</td>'
            f'<td class="num"><b>{e(f4(i["value"]))}</b><div>{pc(pv, i["value"], 4) if ps else ""}</div></td>'
            f'<td><div class="bar {cls}"><i style="width:{w:.1f}%"></i></div><div class="mono">{i["contribution"]:.2f} / 16.67점</div></td>'
            f'<td>{badge(i["verdict"], "ok" if i["full"] else "warn")}<div class="note">연결 검증: {e(linked)}</div></td></tr>')
    total = (f'<div class="formula">{e(rel["score_formula"])}\n{e(rel["sum_str"])}\n{e(rel["score_substituted"])}   '
             f'(엔진 값 {e(rel["score_engine"])} · {"일치" if rel["score_match"] else "불일치"})</div>')
    chain = "".join(
        f'<tr class="{"chg" if c["fired"] else ""}"><td>{c["n"]}</td><td>{e(c["question"])}</td><td class="mono">{e(c["actual"])}</td>'
        f'<td>{"<b>" + e(c["result"]) + " ◀ 판정</b>" if c["fired"] else (e(c["result"]) if c["evaluated"] else "미평가")}</td></tr>'
        for c in r["status_chain"])
    cross = r["cross"]
    cross_html = ""
    if r["meta"]["n_sources"] >= 2 and cross.get("comparisons"):
        crow = "".join(
            f'<tr><td>{e(sn)}</td><td class="num">{e(show(c["close"]))}</td><td class="num">{e(show(c["close_diff"]))}</td>'
            f'<td class="num">{e(show(c["volume"]))}</td><td class="num">{e(show(c["volume_diff_ratio"]))}</td>'
            f'<td>{_pass(c["match"])}</td></tr>' for sn, c in cross["comparisons"].items())
        cross_html = ("<h3>원천 간 비교 (원천 일치 항목의 입력)</h3><p class='note'>기준 = 원천들의 최대 종가·최대 거래량 · "
                      "허용: 종가 차이 ≤ 0.01, 거래량 차이비 ≤ 0.05</p>"
                      + _table(["원천", "마지막 종가", "기준과 종가 차이", "마지막 거래량", "거래량 차이비", "일치"], [crow]))
    cands = "".join(
        f'<div class="cand"><h4>{e(c["title"])} {badge("엔진에 적용 안 됨", "warn")}</h4><ul>'
        + "".join(f"<li>{e(x)}</li>" for x in c["evidence"]) + f'</ul><div class="imp">{e(c["impact"])}</div></div>'
        for c in r["candidates"])
    return (f'<section id="sec-rel"><h2>④ 신뢰도 계산</h2><p class="lead">신뢰도는 6개 항목 값(0~1)의 평균에 100을 곱한 값입니다. '
            f'각 항목의 공식·입력값·계산값·기여도를 그대로 펼쳤습니다.</p>{total}'
            + _table(["항목", "공식", "입력값", "대입", "값 (이전 → 현재)", "기여도", "판정"], rows)
            + f'<p class="note">기여도 = 항목 값 ÷ 6 × 100 (항목당 최대 16.67점). 오염도는 리포트에 저장되지 않는 파생 항목이라 같은 식으로 계산해 표시합니다.</p>'
            + f'<h3>상태는 어떻게 정해졌나</h3>' + _table(["순서", "규칙", "실제 값", "결과"], [chain]) + cross_html
            + '<h3>개선 후보 (참고용 · 이번 계산에는 반영하지 않음)</h3>'
              '<p class="note">엔진 공식은 그대로 두고, 현재 데이터로 계산한 근거만 붙였습니다. 반영 여부는 별도 승인 후 결정합니다.</p>'
            + cands + '</section>')


# ----------------------------------------------------------------------------- ⑤ 이전 실행 대비
def sec_compare(r: Dict[str, Any]) -> str:
    cp = r["compare"]
    if not cp["has_prev"]:
        return ('<section id="sec-compare"><h2>⑤ 이전 실행 대비 변화</h2><p class="lead">이전 실행 기록이 없습니다. '
                '이번 실행이 저장되었으므로 다음 실행부터 신뢰도·검증·센서·모델·OOS 의 이전 → 현재 변화가 표시됩니다.</p></section>')
    groups = []
    for gp in cp["groups"]:
        rows = []
        for x in gp["rows"]:
            nd = x["nd"]
            rows.append(f'<tr class="{"chg" if x["changed"] else "same"}"><td>{e(x["label"])}</td>'
                        f'<td class="num pv">{e(show(x["prev"], nd))}</td><td class="num cv">{e(show(x["curr"], nd))}</td>'
                        f'<td class="num">{delta(x["prev"], x["curr"], nd) if x["changed"] else ""}</td></tr>')
        n_ch = sum(1 for x in gp["rows"] if x["changed"])
        groups.append(f'<details class="grp" open><summary>{e(gp["group"])} — 변경 {n_ch}/{len(gp["rows"])}</summary>'
                      + _table(["항목", "이전 실행", "현재 실행", "변화"], rows) + "</details>")
    return (f'<section id="sec-compare"><h2>⑤ 이전 실행 대비 변화</h2><p class="lead">이전 실행 {e(cp["prev_time"])} → 현재 실행 '
            f'{e(r["summary"]["generated_at"])}. 전체 {cp["n_total"]}개 값 중 {cp["n_changed"]}개가 바뀌었습니다.</p>'
            '<div class="toolbar"><label><input type="checkbox" id="onlychg"> 바뀐 항목만 보기</label></div>'
            + "".join(groups) + '</section>')


# ----------------------------------------------------------------------------- Arena 세부
def _steps_table(steps: List[Dict[str, Any]], has_prev: bool) -> str:
    rows = []
    for s in steps:
        if s["kind"] == "text":
            ch = has_prev and s["prev"] != s["curr"]
            pv, cv, dl = e(show(s["prev"])), e(show(s["curr"])), ""
        else:
            ch = has_prev and isnum(s["prev"]) and isnum(s["curr"]) and abs(s["prev"] - s["curr"]) > 1e-12
            pv, cv, dl = e(show(s["prev"], s["nd"])), e(show(s["curr"], s["nd"])), (delta(s["prev"], s["curr"], s["nd"]) if ch else "")
        rows.append(f'<tr class="{"chg" if ch else ""}"><td><b>{e(s["label"])}</b></td><td class="mono">{e(s["formula"])}</td>'
                    f'<td class="mono">{e(s["subst"])}</td><td class="num pv">{pv if has_prev else "—"}</td>'
                    f'<td class="num cv">{cv}</td><td class="num">{dl}</td></tr>')
    return _table(["단계", "공식", "실제 값 대입 (현재)", "이전", "현재", "변화"], rows)


def sec_arena(r: Dict[str, Any]) -> str:
    s, ps = r["summary"], r["prev_summary"]
    a = s["arena"]
    if not a.get("available"):
        how = ('<p>Arena 파일 경로를 지정하면 이 영역이 채워집니다: <code>--arena-path 폴더또는파일</code> 또는 '
               '환경변수 <code>UME_ARENA_PATH</code>. Arena 파일은 수정하지 않고 읽기만 합니다.</p>')
        return (f'<details class="sec" id="sec-arena"><summary>Arena 세부 — 미연결</summary>'
                f'<p class="warnline">사유: {e(a.get("error") or "알 수 없음")}</p>{how}</details>')
    pa = ps["arena"] if (ps and ps["arena"].get("available")) else None
    hp = pa is not None
    parts = []

    ck = r["arena_checks"]
    ok_n = sum(1 for c in ck if c["ok"])
    ck_rows = "".join(f'<tr class="{"" if c["ok"] else "chg"}"><td>{e(c["model"])}</td><td class="mono">{e(c["name"])}</td>'
                      f'<td class="num">{e(show(c["recomputed"], 8))}</td><td class="num">{e(show(c["engine"], 8))}</td>'
                      f'<td>{badge("재현", "ok") if c["ok"] else badge("불일치", "fail")}</td></tr>' for c in ck)
    parts.append(f'<details class="grp"><summary>화면 공식이 Arena 결과를 재현하는가 — {ok_n}/{len(ck)}</summary>'
                 f'<p class="note">이 화면의 공식을 실제 입력값으로 다시 계산해 Arena 출력과 대조했습니다. 불일치가 있으면 화면 공식이 실제와 다르다는 뜻입니다.</p>'
                 + _table(["대상", "식", "재계산", "Arena 출력", "결과"], [ck_rows]) + "</details>")

    hits = r["window_hits"]
    parts.append("<h3>Regime</h3>" + _steps_table(model_steps("Regime", a, pa), hp))
    rr = "".join(
        f'<tr class="{"chg" if x["fired"] else ""}"><td>{e(x["name"])}</td><td>{e(x["cond"])}</td><td class="mono">{e(x["subst"])}</td>'
        f'<td>{"<b>◀ 판정</b>" if x["fired"] else ("" if x["evaluated"] else "미평가")}</td></tr>' for x in regime_rules(a))
    parts.append("<h4>Regime 규칙 대조</h4>" + _table(["결과", "조건", "실제 값", ""], [rr]))

    parts.append("<h3>센서</h3>")
    parts.append("<h4>StateSpace</h4>" + _steps_table(model_steps("StateSpace", a, pa), hp))
    srows = []
    for nm in ("TIR_v1", "TIR_v2", "Friction"):
        cs = a["sensors"].get(nm)
        if not cs:
            continue
        p_ = pa["sensors"].get(nm, {}) if hp else {}
        srows.append(f'<tr><td><b>{e(nm)}</b></td><td>{pc(p_.get("signal"), cs.get("signal"), 0, hp)}</td>'
                     f'<td>{pc(p_.get("strength"), cs.get("strength"), 4, hp)}</td><td class="note">'
                     + ("원본 TIR 함수 내부 계산 — 입력/출력만 표시" if nm.startswith("TIR") else
                        "호가(orderbook)가 없으면 ORDERBOOK_UNAVAILABLE") + "</td></tr>")
    parts.append(_table(["센서", "신호 (이전 → 현재)", "강도 (이전 → 현재)", "비고"], srows))

    parts.append("<h3>모델 — 입력 → 공식 → 결과</h3><div class=\"grid2\">")
    from .model_calc import WINDOWS
    for nm in ("Momentum", "Hook_OU", "Threshold", "Breakout"):
        if nm not in a["models"]:
            continue
        parts.append(f'<div class="card"><h4>{e(nm)} <span class="note">입력 창 최근 {WINDOWS[nm]}봉 · '
                     f'그 안의 변경/추가 행 {hits.get(nm, 0)}개</span></h4>' + _steps_table(model_steps(nm, a, pa), hp) + "</div>")
    parts.append("</div>")

    cand = a["priority"]["candidates"]
    pcand = {c["model"]: c for c in pa["priority"]["candidates"]} if hp else {}
    prow = []
    for i, c in enumerate(cand):
        if c["score"] is None:
            prow.append(f'<tr class="same"><td>{e(c["model"])}</td><td colspan="5">제외 (중립 신호 · actionable=False)</td></tr>')
            continue
        prow.append(f'<tr class="{"chg" if c["model"] == a["priority"]["name"] else ""}"><td><b>{e(c["model"])}</b></td>'
                    f'<td class="num">{e(show(c["strength"]))}</td><td class="num">{e(show(c["fit"], 2))}</td>'
                    f'<td class="num">{e(show(c["multiplier"]))}</td>'
                    f'<td class="mono">{e(g(c["strength"]))} × {e(g(c["fit"]))} × {e(g(c["multiplier"]))} = <b>{e(g(c["score"]))}</b></td>'
                    f'<td class="num">{pc((pcand.get(c["model"]) or {}).get("score"), c["score"], 4, hp)}</td>'
                    f'<td>{"◀ Priority" if c["model"] == a["priority"]["name"] else ""}</td></tr>')
    parts.append("<h3>Priority 점수</h3><p class='note'>점수 = 신호강도 × Regime 적합도(사람이 정한 prior) × OOS 승수 "
                 "(VERIFIED 1+edge 계수, NO_EDGE 0.85, 미검증 1.0)</p>"
                 + _table(["모델", "강도", "Regime 적합도", "OOS 승수", "점수 계산 (현재)", "점수 (이전 → 현재)", ""], prow))

    z = 1.96
    minn = a["constants"]["MIN_VERIFIED_N"]
    orow = []
    for nm, o in a["oos"].items():
        po = pa["oos"].get(nm, {}) if hp else {}
        k, n_eff = o.get("k"), o.get("n_eff")
        wl = wilson_parts(k, n_eff, z) if (k is not None and n_eff) else None
        if wl:
            wsub = (f"p = {k}/{n_eff} = {g(wl['p'])}\n({g(wl['centre'])} - {g(wl['margin'])}) ÷ {g(wl['denom'])} = {g(wl['lower'])}")
            okw = isnum(o.get("da_ci_low")) and abs(wl["lower"] - o["da_ci_low"]) < 1e-9
        else:
            wsub, okw = "표본 없음", True
        ci = o.get("da_ci_low")
        rule = (f"n={o.get('n')} {'≥' if (o.get('n') or 0) >= minn else '<'} {minn} · CI하한={g(ci)} "
                f"{'>' if isnum(ci) and ci > .5 else '≤'} 0.5 → {o.get('status')}")
        orow.append(f'<tr><td><b>{e(nm)}</b><div class="note">{e(o.get("task"))}</div></td>'
                    f'<td>{pc(po.get("n"), o.get("n"), 0, hp)}</td><td>{pc(po.get("directional_accuracy"), o.get("directional_accuracy"), 4, hp)}</td>'
                    f'<td class="mono">{e(wsub)}</td><td>{pc(po.get("da_ci_low"), ci, 4, hp)}'
                    f'{"" if okw else " " + badge("재계산 불일치", "warn")}</td><td class="mono">{e(rule)}</td>'
                    f'<td>{pc(po.get("status"), o.get("status"), 0, hp)}</td></tr>')
    parts.append(f"<h3>OOS · 통계 검증</h3><p class='note'>Wilson 95% 하한 = (p + z²/2n - z·√(p(1-p)/n + z²/4n²)) ÷ (1 + z²/n), z = 1.96. "
                 f"VERIFIED = 표본 n ≥ {minn} 그리고 하한 &gt; 0.5.</p>"
                 + _table(["모델", "표본 n", "방향적중률 DA = k/n", "Wilson 하한 계산", "하한 (이전 → 현재)", "판정 규칙 대조", "상태"], orow))
    led = a["ledger"]
    parts.append(f'<p class="note">예측 원장 {led["records"]:,}건 · 상태 {e(led["status"])} · OOS 우수 모델 {e(a["oos_leader"] or "없음")} · '
                 f'TIR v1 원본 함수 {"사용" if a["tir_v1_frozen"] else "미사용(내장 폴백)"}</p>')
    return ('<details class="sec" id="sec-arena"><summary>Arena 세부 — Regime · 센서 · 모델 · Priority · OOS (펼쳐서 보기)</summary>'
            + "".join(parts) + "</details>")


# ----------------------------------------------------------------------------- 새로고침
def sec_refresh(r: Dict[str, Any]) -> str:
    return ('<section id="sec-refresh"><h2>최신 데이터로 새로고침</h2>'
            '<div class="formula">python run_dashboard.py --csv 새데이터.csv --arena-path Arena폴더 --out dashboard.html\n'
            'python run_dashboard.py --csv 새데이터.csv --arena-path Arena폴더 --serve      # 127.0.0.1 에서 열기, 주소창에 /refresh 로 재실행</div>'
            '<p class="note">실행할 때마다 현재 데이터가 다음 실행의 "이전 Snapshot"이 되고, 이번 요약이 "이전 실행"으로 저장됩니다. '
            '이 화면은 표시만 하며 엔진·Arena 의 계산을 바꾸지 않습니다. 서버는 127.0.0.1 에만 바인딩합니다(SEC-001/002).</p></section>')


def render_html(r: Dict[str, Any]) -> str:
    s, m = r["summary"], r["meta"]
    note = f'<div class="demo">{e(m["note"])}</div>' if m.get("note") else ""
    nav = ('<nav><a href="#sec-status">① 현재 상태</a><a href="#sec-change">② 전후 비교</a><a href="#sec-valid">③ 검증</a>'
           '<a href="#sec-rel">④ 신뢰도</a><a href="#sec-compare">⑤ 이전 실행 대비</a><a href="#sec-arena">Arena 세부</a></nav>')
    body = (sec_status(r) + note + sec_change(r) + sec_valid(r) + sec_rel(r) + sec_compare(r) + sec_arena(r) + sec_refresh(r))
    js = ("<script>var b=document.getElementById('onlychg');if(b){b.addEventListener('change',function(){"
          "document.getElementById('sec-compare').classList.toggle('only-changed',this.checked);});}</script>")
    return (f'<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<title>UME 데이터 추적 대시보드 · {e(s["symbol"])}</title><style>{CSS}</style></head><body>'
            f'<header class="top"><h1>UME 데이터 추적 대시보드</h1><span class="meta">{e(s["symbol"])} · {e(s["generated_at"])}</span>{nav}</header>'
            f'<main>{body}</main>{js}</body></html>')
