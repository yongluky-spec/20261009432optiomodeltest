"""ARENA BRIDGE — 기존 Arena 파일을 '수정 없이' 불러와 결과만 꺼낸다.

- 우선순위: ① 인자 arena_path ② 환경변수 UME_ARENA_PATH (파일 또는 폴더)
  ③ 지정이 없으면 01_strategy/kospi_arena 모듈 묶음(원본 알고리즘을 분리한 것)을 사용.
- 폴더를 주면 kospi-model-arena-observatory*.py / kospi_model_arena_observatory*.py 를 찾는다.
- 불러오지 못하면 예외 대신 available=False 와 사유(error)를 남긴다.
  → 대시보드는 Arena 단계를 '미연결'로 표시하고 나머지(데이터·검증·신뢰도)는 정상 동작한다.
- Arena 계산 로직은 호출만 하며 어떤 부분도 바꾸거나 재정의하지 않는다.
"""
import importlib.util
import os
import sys
import warnings
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

PATTERNS = ["kospi-model-arena-observatory*.py", "kospi_model_arena_observatory*.py"]
REQUIRED_ATTRS = ["Arena", "normalize_bars", "REGIME_FIT", "_obs_score", "OOSAnalyzer"]
_CACHE: Dict[str, Any] = {}


def find_arena_file(directory) -> Optional[Path]:
    d = Path(directory)
    for pat in PATTERNS:
        hits = sorted(d.glob(pat))
        if hits:
            return hits[0]
    return None


def load_arena_module(path=None):
    """(module | None, resolved_path | None, error | None)"""
    path = path or os.environ.get("UME_ARENA_PATH")
    if not path:
        return _load_package()
    p = Path(path)
    if p.is_dir():
        found = find_arena_file(p)
        if not found:
            return None, None, f"폴더에서 Arena 파일을 찾지 못함: {p}"
        p = found
    if not p.exists():
        return None, None, f"Arena 파일 없음: {p}"
    key = str(p.resolve())
    if key in _CACHE:
        return _CACHE[key], key, None
    name = f"_ume_arena_{abs(hash(key))}"
    try:
        spec = importlib.util.spec_from_file_location(name, key)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module  # dataclass 가 모듈을 조회하므로 등록 필요
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            spec.loader.exec_module(module)
    except Exception as exc:  # noqa: BLE001 - 사유를 화면에 보이기 위해 넓게 잡는다
        sys.modules.pop(name, None)
        return None, key, f"Arena 로드 실패: {type(exc).__name__}: {exc}"
    missing = [a for a in REQUIRED_ATTRS if not hasattr(module, a)]
    if missing:
        return None, key, f"Arena 인터페이스 불일치(없는 항목: {missing})"
    _CACHE[key] = module
    return module, key, None


def _load_package():
    """01_strategy/kospi_arena 를 불러온다 (이 파일 기준 ../../../01_strategy)."""
    strategy = Path(__file__).resolve().parents[3] / "01_strategy"
    if strategy.is_dir() and str(strategy) not in sys.path:
        sys.path.insert(0, str(strategy))
    try:
        import kospi_arena as module  # type: ignore
    except Exception as exc:  # noqa: BLE001
        return None, None, f"Arena 경로 미지정이고 kospi_arena 모듈도 불러오지 못함: {type(exc).__name__}: {exc}"
    missing = [a for a in REQUIRED_ATTRS if not hasattr(module, a)]
    if missing:
        return None, None, f"kospi_arena 인터페이스 불일치(없는 항목: {missing})"
    return module, f"kospi_arena {getattr(module, '__version__', '')} ({strategy})", None


class ArenaBridge:
    def __init__(self, path=None):
        self.module, self.path, self.error = load_arena_module(path)

    @property
    def available(self) -> bool:
        return self.module is not None

    def normalize(self, df: pd.DataFrame) -> pd.DataFrame:
        """Arena 가 실제로 쓰는 정규화. Arena 없으면 최소 정규화(시간 변환·정렬)."""
        if self.available:
            return self.module.normalize_bars(df, "dashboard")
        x = df.copy()
        x["timestamp"] = pd.to_datetime(x["timestamp"])
        return x.sort_values("timestamp").reset_index(drop=True)

    def run(self, x: pd.DataFrame, orderbook=None, horizon: int = 5) -> Dict[str, Any]:
        """정규화된 봉 전체로 walk-forward 리플레이를 돌리고 결과를 dict 로 돌려준다."""
        if not self.available:
            return {"available": False, "error": self.error}
        m = self.module
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                arena = m.Arena()  # ledger_path=None → 디스크에 아무것도 쓰지 않는다
                res = arena.run_backtest_replay(x, horizon=horizon)
                if orderbook:
                    res = arena.evaluate_current(x, "dashboard", "GOOD", orderbook=orderbook,
                                                 horizon=horizon, record=False)
        except Exception as exc:  # noqa: BLE001
            return {"available": False, "error": f"Arena 실행 실패: {type(exc).__name__}: {exc}"}

        oos_df = res.oos if isinstance(res.oos, pd.DataFrame) else pd.DataFrame()
        ledger_df = arena.ledger.dataframe()

        oos_detail: Dict[str, Dict[str, Any]] = {}
        ledger_status: Dict[str, int] = {}
        if not ledger_df.empty:
            ledger_status = {str(k): int(v) for k, v in ledger_df["status"].value_counts().items()}
            for (model, task), g in ledger_df.groupby(["model", "task"]):
                g = g[g["status"] == "EVALUATED"]
                dc = pd.to_numeric(g["direction_correct"], errors="coerce")
                oos_detail[str(model)] = {
                    "task": str(task),
                    "k": int(dc.dropna().sum()) if dc.notna().any() else 0,
                    "n_eff": int(dc.notna().sum()),
                }

        # Priority 후보표: Arena 의 _obs_score 를 그대로 호출해 분해만 한다.
        candidates = []
        for p in res.predictions:
            name = p["model"]
            strength = float(np.clip(p.get("strength", 0), 0, 1))
            fit = float(m.REGIME_FIT.get(name, {}).get(res.regime, .5))
            actionable = bool(p.get("actionable", True))
            score = evidence = validated = None
            if actionable:
                score, evidence, validated = m._obs_score(name, strength, res.regime, oos_df)
            base = strength * fit
            mult = (score / base) if (score is not None and base > 0) else None
            candidates.append({
                "model": name, "actionable": actionable, "strength": strength, "fit": fit,
                "base": base, "multiplier": mult, "score": score,
                "evidence": evidence, "validated": validated,
            })
        candidates.sort(key=lambda c: (c["score"] is not None, c["score"] or 0), reverse=True)

        return {
            "available": True,
            "error": None,
            "timestamp": str(res.timestamp),
            "regime": res.regime,
            "state": dict(res.market_state),
            "predictions": list(res.predictions),
            "sensors": list(res.sensors),
            "oos": oos_df.to_dict("records"),
            "oos_detail": oos_detail,
            "priority": {"name": res.current_priority, "reason": res.current_reason,
                         "candidates": candidates},
            "oos_leader": res.oos_leader,
            "ledger": {"records": int(len(ledger_df)), "status": ledger_status},
            "constants": {
                "MIN_VERIFIED_N": int(getattr(m.OOSAnalyzer, "MIN_VERIFIED_N", 30)),
                "MIN_HISTORY": int(getattr(getattr(m, "RegimeEngine", None), "MIN_HISTORY", 120)),
                "REGIME_FIT": {k: dict(v) for k, v in m.REGIME_FIT.items()},
            },
            "tir_v1_frozen": bool(any(s.get("frozen_baseline") for s in res.sensors)),
        }
