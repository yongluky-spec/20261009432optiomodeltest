"""PIPELINE — 데이터 → 정규화 → 검증 → Snapshot 변화 → 신뢰도 → Regime/Sensor → Model → Prediction → OOS

각 단계의 입력과 출력을 report 로 모은다. 기존 엔진(MonitoringEngine)과 Arena 는 호출만 하고
계산 로직을 바꾸지 않는다. 결과 report 는 render.py 가 HTML 로 그린다.
"""
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from ..monitoring.engine import MonitoringEngine
from .arena_bridge import ArenaBridge
from .model_calc import WINDOWS, compute_inputs, crosscheck, window_hits
from .run_store import RoundTripSnapshotStore, RunStore
from .traces import (change_trace, improvement_candidates, reliability_trace, status_chain,
                     validation_trace)
from .util import clean, f4, g, isnum, pct, sgn, show

REQUIRED_ARENA_COLUMNS = {"timestamp", "symbol", "open", "high", "low", "close", "volume", "trade_amount"}


# ----------------------------------------------------------------------------- 요약 (JSON 저장 단위)
def build_summary(cur: pd.DataFrame, x: Optional[pd.DataFrame], mon, now: pd.Timestamp, symbol: str,
                  val_rows: List[dict], rel: dict, ch: dict, arena_out: dict, inputs: Optional[dict],
                  source_name: str) -> Dict[str, Any]:
    ts = pd.to_datetime(cur["timestamp"])
    last = cur.iloc[-1] if len(cur) else {}
    passed_count = sum(1 for r in val_rows if r["passed"])
    s: Dict[str, Any] = {
        "run_id": now.strftime("%Y%m%dT%H%M%S"),
        "generated_at": now.strftime("%Y-%m-%d %H:%M:%S"),
        "symbol": symbol, "rows": len(cur), "cols": len(cur.columns),
        "first_ts": str(ts.min()) if len(ts) else None, "last_ts": str(ts.max()) if len(ts) else None,
        "source": source_name,
        "last_bar": {k: (last.get(k) if len(cur) else None) for k in ("open", "high", "low", "close", "volume")},
        "norm": {"rows_in": len(cur), "rows_out": len(x) if x is not None else None,
                 "sorted_in": bool(ts.is_monotonic_increasing)},
        "status": mon.status, "score": mon.overall_score,
        "validation": {"passed": bool(mon.validation.get("passed")), "passed_count": passed_count,
                       "total": len(val_rows),
                       "items": {r["id"]: {"name": r["name"], "passed": r["passed"], "measured": r["measured"],
                                           "measured_text": r["measured_text"]} for r in val_rows}},
        "reliability": {i["key"]: i["value"] for i in rel["items"]},
        "changes": {**ch["summary"], "fields": ch["field_counts"]},
        "arena": {"available": False, "error": arena_out.get("error")},
    }
    if arena_out.get("available"):
        s["arena"] = {
            "available": True,
            "regime": arena_out["regime"],
            "regime_parts": arena_out["state"],
            "inputs": inputs,
            "models": {p["model"]: {k: p.get(k) for k in
                                    ("direction", "signal", "p_up", "strength", "predicted_return", "actionable")}
                       for p in arena_out["predictions"]},
            "sensors": {p["model"]: {k: p.get(k) for k in ("signal", "strength", "x", "v", "a", "status")}
                        for p in arena_out["sensors"]},
            "priority": {"name": arena_out["priority"]["name"], "candidates": arena_out["priority"]["candidates"]},
            "oos": {r["model"]: {**{k: r.get(k) for k in ("task", "n", "directional_accuracy", "da_ci_low",
                                                        "brier", "profit_factor", "sharpe", "mdd", "status")},
                                 **arena_out["oos_detail"].get(r["model"], {})}
                    for r in arena_out["oos"]},
            "oos_leader": arena_out["oos_leader"],
            "ledger": arena_out["ledger"],
            "constants": arena_out["constants"],
            "tir_v1_frozen": arena_out["tir_v1_frozen"],
        }
    return clean(s)


# ----------------------------------------------------------------------------- 단계 (입력/출력)
def stages_from_summary(s: Dict[str, Any]) -> List[Dict[str, Any]]:
    """요약 하나에서 9단계의 입력/출력 문장을 만든다. 이전·현재에 같은 함수를 쓴다."""
    a = s.get("arena", {})
    ch = s["changes"]
    val = s["validation"]
    st_map = {"NORMAL": "ok", "CHANGED": "info", "WARNING": "warn", "ERROR": "fail"}
    out = [
        {"id": "raw", "name": "원본 데이터", "anchor": "sec-flow",
         "input": f"입력 표 {s['cols']}열",
         "output": f"{s['rows']:,}행 · {str(s['first_ts'])[:16]} ~ {str(s['last_ts'])[:16]} · 원천 {s['source']}",
         "status": "ok"},
        {"id": "norm", "name": "정규화", "anchor": "sec-flow",
         "input": f"원본 {s['norm']['rows_in']:,}행 (시간 순서 {'정렬됨' if s['norm']['sorted_in'] else '섞임'})",
         "output": (f"{s['norm']['rows_out']:,}행 · 시간 오름차순 · 타임존 통일" if s["norm"]["rows_out"] is not None
                    else "정규화 실패"),
         "status": "ok" if s["norm"]["rows_out"] is not None else "fail"},
        {"id": "valid", "name": "검증·품질", "anchor": "sec-valid",
         "input": "6개 검증기(결측·중복·시간·OHLC·이상치·연속성)",
         "output": f"{val['passed_count']}/{val['total']} 통과",
         "status": "ok" if val["passed"] else "fail"},
        {"id": "snap", "name": "Snapshot 변화", "anchor": "sec-change",
         "input": "이전 Snapshot vs 현재 (symbol + timestamp 키)",
         "output": (f"추가 {ch['added']} · 삭제 {ch['removed']} · 수정 {ch['modified']} · 동일 {ch['unchanged']}"),
         "status": "info" if ch["changed_count"] else "ok"},
        {"id": "rel", "name": "신뢰도", "anchor": "sec-rel",
         "input": "검증 결과 + 최신성 + 원천 일치",
         "output": f"{s['score']}점 → {s['status']}",
         "status": st_map.get(s["status"], "info")},
    ]
    if a.get("available"):
        sens = a["sensors"]
        ss = sens.get("StateSpace", {})
        t2 = sens.get("TIR_v2", {})
        preds = a["models"]
        led = a["ledger"]["status"]
        out += [
            {"id": "regime", "name": "Regime·Sensor", "anchor": "sec-arena",
             "input": "정규화된 봉 (모델별 최근 6~22봉)",
             "output": f"{a['regime']} · StateSpace {ss.get('signal')} · TIR_v2 {t2.get('signal')}", "status": "ok"},
            {"id": "model", "name": "Model", "anchor": "sec-arena",
             "input": "정규화된 봉 + Regime",
             "output": " · ".join(f"{k} {(v.get('direction') or v.get('signal') or '—')}" for k, v in preds.items()),
             "status": "ok"},
            {"id": "pred", "name": "Prediction", "anchor": "sec-arena",
             "input": "모델 출력(actionable 만 기록)",
             "output": (f"원장 {a['ledger']['records']:,}건 (평가 완료 {led.get('EVALUATED', 0):,} · "
                        f"대기 {led.get('PENDING', 0):,})"), "status": "ok"},
            {"id": "oos", "name": "OOS·Scoring", "anchor": "sec-arena",
             "input": "원장의 평가 완료 예측 + Regime 적합도",
             "output": f"Priority {a['priority']['name'] or '없음'} · OOS 우수 {a['oos_leader'] or '없음'}",
             "status": "ok"},
        ]
    else:
        for sid, name in (("regime", "Regime·Sensor"), ("model", "Model"), ("pred", "Prediction"),
                          ("oos", "OOS·Scoring")):
            out.append({"id": sid, "name": name, "anchor": "sec-arena", "input": "Arena 필요",
                        "output": f"미연결 — {a.get('error') or '사유 없음'}", "status": "na"})
    return out


# ----------------------------------------------------------------------------- 이전 실행 대비
def _row(label, p, c, nd=4, kind="num"):
    changed = (p != c)
    delta = None
    if isnum(p) and isnum(c):
        changed = abs(float(p) - float(c)) > 1e-12
        delta = float(c) - float(p)
    return {"label": label, "prev": p, "curr": c, "delta": delta, "changed": bool(changed), "nd": nd, "kind": kind}


def compare_runs(prev: Optional[dict], curr: dict) -> Dict[str, Any]:
    if not prev:
        return {"has_prev": False, "groups": []}
    G: List[Dict[str, Any]] = []
    pa, ca = prev.get("arena", {}), curr.get("arena", {})

    G.append({"group": "종합", "rows": [
        _row("상태", prev["status"], curr["status"], kind="text"),
        _row("신뢰도(점)", prev["score"], curr["score"], 1),
        _row("검증 통과 수", prev["validation"]["passed_count"], curr["validation"]["passed_count"], 0),
    ]})
    names = {"freshness": "최신성", "completeness": "완결성", "consistency": "일관성",
             "timestamp_quality": "시간 품질", "cross_source_agreement": "원천 일치", "contamination": "오염도"}
    G.append({"group": "신뢰도 항목 (값 0~1)", "rows": [
        _row(names[k], prev["reliability"].get(k), curr["reliability"].get(k), 4) for k in names]})
    G.append({"group": "검증 실측값", "rows": [
        _row(f"{v['name']} ({vid})", prev["validation"]["items"].get(vid, {}).get("measured"), v["measured"], 6)
        for vid, v in curr["validation"]["items"].items()]})
    G.append({"group": "변경된 데이터 행/필드", "rows": [
        _row("행 수", prev["rows"], curr["rows"], 0),
        _row("마지막 봉 시각", str(prev["last_ts"])[:19], str(curr["last_ts"])[:19], kind="text"),
        _row("마지막 종가", prev["last_bar"].get("close"), curr["last_bar"].get("close"), 4),
        _row("마지막 거래량", prev["last_bar"].get("volume"), curr["last_bar"].get("volume"), 2),
        _row("추가 행", prev["changes"].get("added"), curr["changes"]["added"], 0),
        _row("수정 행", prev["changes"].get("modified"), curr["changes"]["modified"], 0),
        _row("삭제 행", prev["changes"].get("removed"), curr["changes"]["removed"], 0),
    ]})
    if pa.get("available") and ca.get("available"):
        srows = []
        for nm in ca["sensors"]:
            cs, ps = ca["sensors"][nm], pa["sensors"].get(nm, {})
            srows.append(_row(f"{nm} 신호", ps.get("signal"), cs.get("signal"), kind="text"))
            srows.append(_row(f"{nm} 강도", ps.get("strength"), cs.get("strength"), 4))
            for k in ("x", "v", "a"):
                if cs.get(k) is not None:
                    srows.append(_row(f"{nm} {k}", ps.get(k), cs.get(k), 4))
        G.append({"group": "주요 센서값", "rows": srows})
        rp, rc = pa["regime_parts"], ca["regime_parts"]
        G.append({"group": "Regime", "rows": [
            _row("Regime", pa["regime"], ca["regime"], kind="text"),
            _row("trend", rp.get("trend"), rc.get("trend"), 4),
            _row("momentum", rp.get("momentum"), rc.get("momentum"), 4),
            _row("volatility(분위수)", rp.get("volatility"), rc.get("volatility"), 4),
            _row("distance_ma", rp.get("distance_ma"), rc.get("distance_ma"), 6),
        ]})
        mrows = []
        for nm, cm in ca["models"].items():
            pm = pa["models"].get(nm, {})
            mrows.append(_row(f"{nm} 방향/신호", pm.get("direction") or pm.get("signal"),
                              cm.get("direction") or cm.get("signal"), kind="text"))
            mrows.append(_row(f"{nm} p_up", pm.get("p_up"), cm.get("p_up"), 4))
            mrows.append(_row(f"{nm} 강도", pm.get("strength"), cm.get("strength"), 4))
        G.append({"group": "모델 출력", "rows": mrows})
        orows = [_row("Priority 모델", pa["priority"]["name"], ca["priority"]["name"], kind="text"),
                 _row("OOS 우수 모델", pa.get("oos_leader"), ca.get("oos_leader"), kind="text")]
        for nm, co in ca["oos"].items():
            po = pa["oos"].get(nm, {})
            orows += [_row(f"{nm} 표본 n", po.get("n"), co.get("n"), 0),
                      _row(f"{nm} 방향적중률", po.get("directional_accuracy"), co.get("directional_accuracy"), 4),
                      _row(f"{nm} Wilson 하한", po.get("da_ci_low"), co.get("da_ci_low"), 4),
                      _row(f"{nm} 상태", po.get("status"), co.get("status"), kind="text")]
        G.append({"group": "OOS·Scoring", "rows": orows})
    n_changed = sum(1 for grp in G for r in grp["rows"] if r["changed"])
    n_total = sum(len(grp["rows"]) for grp in G)
    return {"has_prev": True, "groups": G, "n_changed": n_changed, "n_total": n_total,
            "prev_time": prev.get("generated_at")}


# ----------------------------------------------------------------------------- 역추적 답변
def build_answers(curr: dict, prev: Optional[dict], rel: dict, hits: Dict[str, int]) -> Dict[str, List[str]]:
    why_score: List[str] = []
    lost = sorted((i for i in rel["items"] if not i["full"]), key=lambda i: -i["loss"])
    why_score.append(f"신뢰도 {curr['score']}점 = {rel['score_substituted']}")
    if lost:
        why_score.append(f"100점에서 {100 - curr['score']:.1f}점이 빠진 원인은 다음과 같습니다.")
        for i in lost:
            why_score.append(f"{i['name']}: -{i['loss']:.2f}점  ({i['substituted']})")
    else:
        why_score.append("6개 항목이 모두 만점입니다.")
    if prev:
        moved = []
        for i in rel["items"]:
            pv = prev["reliability"].get(i["key"])
            if isnum(pv) and abs(pv - i["value"]) > 1e-9:
                moved.append(f"{i['name']} {f4(pv)} → {f4(i['value'])}")
        if isnum(prev.get("score")):
            why_score.append(f"이전 실행 {prev['score']}점 → 현재 {curr['score']}점 (Δ {sgn(curr['score'] - prev['score'], 1)}점)"
                             + (f", 값이 바뀐 항목: {', '.join(moved)}" if moved else ", 항목 값은 모두 동일"))

    why_model: List[str] = []
    ca, pa = curr.get("arena", {}), (prev or {}).get("arena", {})
    if ca.get("available"):
        for nm, cm in ca["models"].items():
            if cm.get("p_up") is None:
                continue
            pm = pa.get("models", {}).get(nm, {}) if pa.get("available") else {}
            key = {"Hook_OU": "Hook_OU", "Momentum": "Momentum", "Threshold": "Threshold",
                   "Breakout": "Breakout"}.get(nm, nm)
            w = WINDOWS.get(key)
            hit = hits.get(key)
            tail = f" · 입력 창(최근 {w}봉) 안의 변경/추가 행 {hit}개" if w is not None and hit is not None else ""
            if pm.get("p_up") is not None:
                d = cm["p_up"] - pm["p_up"]
                why_model.append(f"{nm}: p_up {f4(pm['p_up'])} → {f4(cm['p_up'])} (Δ {sgn(d, 4)}){tail}")
            else:
                why_model.append(f"{nm}: p_up {f4(cm['p_up'])} (이전 실행 없음){tail}")
        if pa.get("available") and pa.get("regime") != ca["regime"]:
            why_model.append(f"Regime: {pa['regime']} → {ca['regime']}")
    return {"why_score": why_score, "why_model": why_model}


# ----------------------------------------------------------------------------- 실행기
class DashboardRunner:
    """감시 엔진 + Arena 를 한 번 돌려 대시보드용 report 를 만든다.

    저장(save=True): 현재 데이터를 Snapshot 으로, 요약을 Run 이력으로 남겨 다음 실행의 '이전'이 된다.
    """

    def __init__(self, data_dir="monitor_data", arena_path=None, engine: Optional[MonitoringEngine] = None):
        self.data_dir = Path(data_dir)
        self.snapshots = RoundTripSnapshotStore(self.data_dir)
        self.runs = RunStore(self.data_dir / "runs")
        self.engine = engine or MonitoringEngine()
        self.arena = ArenaBridge(arena_path)

    def run(self, current: pd.DataFrame, symbol: Optional[str] = None,
            source_frames: Optional[Dict[str, pd.DataFrame]] = None, orderbook=None,
            previous: Optional[pd.DataFrame] = None, save: bool = True) -> Dict[str, Any]:
        cur = current.copy().reset_index(drop=True)
        cur["timestamp"] = pd.to_datetime(cur["timestamp"])
        if "symbol" not in cur.columns:
            cur["symbol"] = symbol or "UNKNOWN"
        symbol = symbol or str(cur["symbol"].iloc[0])
        source_name = str(cur["source"].iloc[0]) if "source" in cur.columns and len(cur) else "unknown"

        prev_df = previous if previous is not None else self.snapshots.load(symbol)
        prev_summary = self.runs.load_latest(symbol)

        # 1) 엔진 (변경 감지 + 검증 + 신뢰도 + 상태) — 수정 없이 호출
        mon = self.engine.run(current=cur, previous=prev_df, source_frames=source_frames)
        now = pd.Timestamp(datetime.now())
        n_sources = len(source_frames) if source_frames else 1

        # 2) 설명 구조
        ch = change_trace(mon.changes)
        val_rows = validation_trace(mon.validation, cur)
        rel_report = dict(mon.reliability)
        rel_report["checks"] = mon.validation.get("validators", {})
        rel = reliability_trace(rel_report, mon.validation, cur, now, self.engine.reliability.halflife,
                                mon.cross_source, n_sources, mon.overall_score)
        chain = status_chain(mon.validation, mon.overall_score,
                             mon.cross_source.get("agreement", 1.0), mon.changes.get("changed_count", 0), mon.status)
        cands = improvement_candidates(rel_report, cur, rel, mon.cross_source, n_sources, source_name, ch)

        # 3) 정규화 + Arena (Regime/Sensor/Model/Prediction/OOS)
        x, arena_out, inputs, checks, hits = None, {"available": False, "error": None}, None, [], {}
        try:
            missing = REQUIRED_ARENA_COLUMNS - set(cur.columns)
            if missing:
                raise ValueError(f"Arena 필수 컬럼 없음: {sorted(missing)}")
            x = self.arena.normalize(cur)
            inputs = compute_inputs(x)
            arena_out = self.arena.run(x, orderbook=orderbook)
            if arena_out.get("available"):
                checks = crosscheck(inputs, arena_out)
                changed_ts = [pd.Timestamp(str(k[1])) for it in mon.changes.get("modified", []) for k in [it["key"]]]
                changed_ts += [pd.Timestamp(str(a["key"][1])) for a in mon.changes.get("added", [])]
                hits = window_hits(inputs, changed_ts)
        except Exception as exc:  # noqa: BLE001 - 화면에 사유를 남기고 나머지 단계는 계속 진행
            arena_out = {"available": False, "error": f"{type(exc).__name__}: {exc}"}
        if not arena_out.get("available") and arena_out.get("error") is None:
            arena_out["error"] = self.arena.error

        summary = build_summary(cur, x, mon, now, symbol, val_rows, rel, ch, arena_out, inputs, source_name)
        compare = compare_runs(prev_summary, summary)
        report = {
            "meta": {"generated_at": summary["generated_at"], "symbol": symbol,
                     "arena": {"available": bool(arena_out.get("available")),
                               "error": arena_out.get("error"), "path": self.arena.path},
                     "has_prev_snapshot": prev_df is not None,
                     "prev_snapshot_rows": (len(prev_df) if prev_df is not None else None),
                     "has_prev_run": prev_summary is not None,
                     "n_sources": n_sources, "halflife": self.engine.reliability.halflife},
            "summary": summary, "prev_summary": prev_summary,
            "status_chain": chain, "changes": ch, "validation": val_rows, "reliability": rel,
            "cross": clean(mon.cross_source), "candidates": cands, "compare": compare,
            "stages": stages_from_summary(summary),
            "prev_stages": stages_from_summary(prev_summary) if prev_summary else None,
            "answers": build_answers(summary, prev_summary, rel, hits),
            "arena_checks": clean(checks), "window_hits": hits,
        }
        if save:
            self.snapshots.save(symbol, cur)
            self.runs.save(symbol, summary)
        return report
