"""MODEL CALC — 모델/센서/레짐 공식의 '입력값'을 꺼내고, Arena 결과와 일치하는지 대조한다.

이 모듈은 Arena 의 공식을 '화면에 펼쳐 보이기 위해' 같은 식을 다시 계산할 뿐,
Arena 를 대체하거나 바꾸지 않는다. 재계산 값이 Arena 출력과 다르면 crosscheck 가
불일치로 표시한다(= 화면에 보이는 공식이 실제 계산과 어긋났다는 경고).
"""
import math
from typing import Any, Dict, List

import numpy as np
import pandas as pd

from .util import isnum

# 각 계산이 마지막 몇 개의 봉을 입력으로 쓰는지 (Arena 코드의 rolling/shift 기준)
WINDOWS = {
    "Momentum": 6,      # close.pct_change(5)  → 현재 + 5봉 전
    "Hook_OU": 20,      # close.rolling(20)
    "Threshold": 21,    # pct_change 후 rolling(20)
    "Breakout": 21,     # 직전 20봉 고저 + 현재 종가
    "Regime": 21,       # pct_change 후 rolling(20) (변동성 분위수는 이력 전체)
    "StateSpace": 22,   # 위치 x 의 2차 차분 (MA20 + 2봉)
}


def sigmoid(x: float) -> float:
    x = float(np.clip(x, -30, 30))
    return 1.0 / (1.0 + math.exp(-x))


def _f(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def compute_inputs(x: pd.DataFrame) -> Dict[str, Any]:
    """정규화된 봉(x)에서 각 공식의 입력값과 중간값을 뽑는다. Arena 와 같은 pandas 식을 쓴다."""
    c, h, lo = x["close"], x["high"], x["low"]
    n = len(x)
    px = _f(c.iloc[-1]) if n else None
    out: Dict[str, Any] = {"n": n, "last_ts": str(x["timestamp"].iloc[-1]) if n else None}

    # Momentum
    out["Momentum"] = {
        "close_t": px,
        "close_t5": _f(c.iloc[-6]) if n >= 6 else None,
        "ret5": _f(c.pct_change(5).iloc[-1]) if n else None,
        "k": 120,
    }
    # Hook_OU (평균회귀)
    ma20 = _f(c.rolling(20).mean().iloc[-1]) if n else None
    z = (px / ma20 - 1) if (px is not None and ma20) else 0.0
    out["Hook_OU"] = {"px": px, "ma20": ma20, "z": _f(z), "k": 80}
    # Threshold
    pc = c.pct_change()
    r10 = _f(pc.rolling(10).mean().iloc[-1]) if n else None
    v20 = _f(pc.rolling(20).std().iloc[-1]) if n else None
    score = (r10 / v20) if (r10 is not None and v20 not in (None, 0)) else 0.0
    out["Threshold"] = {"r10": r10, "v20": v20, "score": _f(score)}
    # Breakout (직전 20봉 = 현재 봉 제외)
    hh = _f(h.rolling(20).max().iloc[-2]) if n >= 2 else None
    ll = _f(lo.rolling(20).min().iloc[-2]) if n >= 2 else None
    out["Breakout"] = {"px": px, "hh": hh, "ll": ll, "ma20": ma20}
    # Regime 구성요소
    dist = (px / ma20 - 1) if (px is not None and ma20) else 0.0
    mom10 = _f(pc.rolling(10).mean().iloc[-1]) if n else None
    vol20 = _f(pc.rolling(20).std().iloc[-1]) if n else None
    out["Regime"] = {
        "px": px, "ma20": ma20, "dist": _f(dist), "mom10": mom10, "vol20": vol20,
        "trend": _f(np.clip(abs(dist) * 40, 0, 1)),
        "momentum": _f(np.clip(abs(mom10 if mom10 is not None else 0) * 200, 0, 1)),
    }
    # StateSpace
    atr = (h - lo).rolling(14).mean().replace(0, np.nan)
    pos = (c - c.rolling(20).mean()) / atr
    vel = pos.diff()
    acc = vel.diff()
    out["StateSpace"] = {
        "px": px, "ma20": ma20, "atr14": _f(atr.iloc[-1]) if n else None,
        "x_t": _f(pos.iloc[-1]) if n else None,
        "x_t1": _f(pos.iloc[-2]) if n >= 2 else None,
        "x_t2": _f(pos.iloc[-3]) if n >= 3 else None,
        "v": _f(vel.iloc[-1]) if n else None,
        "a": _f(acc.iloc[-1]) if n else None,
    }
    # 입력 창 시작 시각 (변경된 행이 창 안에 있는지 판단하는 데 사용)
    out["window_start"] = {k: (str(x["timestamp"].iloc[-w]) if n >= w else None)
                           for k, w in WINDOWS.items()}
    return out


def _chk(name, model, recomputed, engine, tol=1e-9) -> Dict[str, Any]:
    if isinstance(recomputed, str) or isinstance(engine, str):
        ok = recomputed == engine
    elif recomputed is None or engine is None:
        ok = recomputed == engine
    else:
        ok = abs(float(recomputed) - float(engine)) <= tol * max(1.0, abs(float(engine)))
    return {"name": name, "model": model, "recomputed": recomputed, "engine": engine, "ok": bool(ok)}


def crosscheck(inputs: Dict[str, Any], arena_out: Dict[str, Any]) -> List[Dict[str, Any]]:
    """재계산 값 vs Arena 출력. 화면에 보이는 공식이 실제 결과를 재현하는지 확인."""
    if not arena_out.get("available"):
        return []
    preds = {p["model"]: p for p in arena_out["predictions"]}
    sens = {s["model"]: s for s in arena_out["sensors"]}
    st = arena_out["state"]
    rows: List[Dict[str, Any]] = []

    m = inputs["Momentum"]
    if "Momentum" in preds and m["ret5"] is not None:
        rows.append(_chk("p_up = sigmoid(ret5 × 120)", "Momentum",
                         sigmoid(m["ret5"] * m["k"]), preds["Momentum"]["p_up"]))
        rows.append(_chk("ret5 = close_t / close_t-5 - 1", "Momentum",
                         (m["close_t"] / m["close_t5"] - 1) if m["close_t5"] else None,
                         preds["Momentum"]["predicted_return"]))
    h = inputs["Hook_OU"]
    if "Hook_OU" in preds:
        rows.append(_chk("p_up = sigmoid(-z × 80)", "Hook_OU",
                         sigmoid(-(h["z"] or 0) * h["k"]), preds["Hook_OU"]["p_up"]))
    t = inputs["Threshold"]
    if "Threshold" in preds:
        rows.append(_chk("p_up = sigmoid(r10 ÷ v20)", "Threshold",
                         sigmoid(t["score"] or 0), preds["Threshold"]["p_up"]))
        rows.append(_chk("strength = min(1, |score| ÷ 3)", "Threshold",
                         min(1, abs(t["score"] or 0) / 3), preds["Threshold"]["strength"]))
    b = inputs["Breakout"]
    if "Breakout" in preds and b["hh"] is not None and b["ll"] is not None:
        if b["px"] > b["hh"]:
            sig = "UP_BREAKOUT"
        elif b["px"] < b["ll"]:
            sig = "DOWN_BREAKOUT"
        else:
            sig = "NO_BREAKOUT"
        rows.append(_chk("signal 판정(종가 vs 직전 20봉 고저)", "Breakout", sig, preds["Breakout"].get("signal")))
    r = inputs["Regime"]
    rows.append(_chk("trend = clip(|dist| × 40, 0, 1)", "Regime", r["trend"], st.get("trend")))
    rows.append(_chk("momentum = clip(|mom10| × 200, 0, 1)", "Regime", r["momentum"], st.get("momentum")))
    rows.append(_chk("distance_ma = close ÷ MA20 - 1", "Regime", r["dist"], st.get("distance_ma")))
    s = inputs["StateSpace"]
    if "StateSpace" in sens:
        rows.append(_chk("x = (close - MA20) ÷ ATR14", "StateSpace", s["x_t"] or 0.0, sens["StateSpace"].get("x")))
        rows.append(_chk("v = x_t - x_t-1", "StateSpace", s["v"] or 0.0, sens["StateSpace"].get("v")))
        rows.append(_chk("a = v_t - v_t-1", "StateSpace", s["a"] or 0.0, sens["StateSpace"].get("a")))
    cands = arena_out["priority"]["candidates"]
    scored = [c for c in cands if c["score"] is not None]
    if scored and arena_out["priority"]["name"] is not None:
        rows.append(_chk("Priority = 점수 최대 모델", "Priority", scored[0]["model"], arena_out["priority"]["name"]))
    return rows


def window_hits(inputs: Dict[str, Any], changed_ts: List[pd.Timestamp]) -> Dict[str, int]:
    """모델별 입력 창(마지막 W봉) 안에 들어 있는 변경/추가 행 개수."""
    hits = {}
    for name, start in (inputs.get("window_start") or {}).items():
        if start is None:
            hits[name] = 0
            continue
        s = pd.Timestamp(start)
        hits[name] = int(sum(1 for t in changed_ts if t >= s))
    return hits
