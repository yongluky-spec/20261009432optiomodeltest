"""공통 표시 도구 — 숫자 서식과 JSON 정리. 계산 로직은 여기에 두지 않는다."""
import math
from typing import Any

import numpy as np
import pandas as pd


def isnum(x: Any) -> bool:
    """유한한 숫자인지(NaN/inf/bool/문자열 제외)."""
    if isinstance(x, (bool, np.bool_)):
        return False
    if isinstance(x, (int, float, np.integer, np.floating)):
        return math.isfinite(float(x))
    return False


def g(x: Any) -> str:
    """공식 치환용 숫자 표기: 값을 그대로 읽을 수 있게 불필요한 0만 제거한다."""
    if x is None or (isinstance(x, (float, np.floating)) and math.isnan(float(x))):
        return "결측"
    if not isnum(x):
        return str(x)
    x = float(x)
    if x == 0:
        return "0"
    if abs(x) < 1e-4:
        return f"{x:.3e}"
    s = f"{x:.6f}".rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def f4(x: Any) -> str:
    """4자리 고정 소수 (신뢰도 항목 값)."""
    return f"{float(x):.4f}" if isnum(x) else "—"


def sgn(x: Any, nd: int = 2) -> str:
    """부호가 붙은 숫자."""
    if not isnum(x):
        return "—"
    return f"{float(x):+,.{nd}f}"


def pct(x: Any, nd: int = 2) -> str:
    """부호가 붙은 퍼센트."""
    if not isnum(x):
        return "—"
    return f"{float(x):+,.{nd}f}%"


def show(x: Any, nd: int = 4) -> str:
    """표에 넣는 일반 값 표기."""
    if x is None:
        return "—"
    if isinstance(x, (float, np.floating)) and math.isnan(float(x)):
        return "결측"
    if isinstance(x, (bool, np.bool_)):
        return "예" if x else "아니오"
    if isnum(x):
        x = float(x)
        if x == int(x) and abs(x) < 1e15:
            return f"{int(x):,}"
        return f"{x:,.{nd}f}".rstrip("0").rstrip(".") if abs(x) >= 1e-4 else f"{x:.3e}"
    return str(x)


def clean(obj: Any) -> Any:
    """numpy/pandas 값을 JSON 저장 가능한 순수 파이썬 값으로 바꾼다 (NaN → None)."""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return {str(k): clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [clean(v) for v in obj]
    if isinstance(obj, (bool, np.bool_)):
        return bool(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (float, np.floating)):
        v = float(obj)
        return v if math.isfinite(v) else None
    if isinstance(obj, (pd.Timestamp,)):
        return None if pd.isna(obj) else str(obj)
    if obj is pd.NaT:
        return None
    if isinstance(obj, (int, str)):
        return obj
    try:
        if pd.isna(obj):
            return None
    except (TypeError, ValueError):
        pass
    return str(obj)
