"""RUN STORE — 실행마다 요약(JSON)을 저장해 '이전 실행 vs 현재 실행'을 비교한다.

- 데이터 Snapshot(SnapshotStore)과 별개로, 그 실행 당시의 신뢰도·검증·모델·OOS 수치를 보관한다.
- 저장 내용은 수치 요약뿐이다. 비밀값·계정정보·원본 응답은 저장하지 않는다(SEC-301/304).
- 최근 MAX_KEEP 개 이력만 유지한다(SEC-305).
"""
import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

import pandas as pd

from ..monitoring.snapshot import SnapshotStore

MAX_KEEP = 30


class RunStore:
    def __init__(self, directory="monitor_data/runs"):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _safe(symbol) -> str:
        return "".join(c if c.isalnum() or c in "-_" else "_" for c in str(symbol))

    def latest_path(self, symbol) -> Path:
        return self.directory / f"{self._safe(symbol)}_latest.json"

    def load_latest(self, symbol) -> Optional[Dict[str, Any]]:
        p = self.latest_path(symbol)
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def save(self, symbol, summary: Dict[str, Any]) -> Path:
        text = json.dumps(summary, ensure_ascii=False, indent=1)
        safe = self._safe(symbol)
        hist = self.directory / f"{safe}_{summary['run_id']}.json"
        for path in (hist, self.latest_path(symbol)):
            tmp = path.with_suffix(f".tmp{os.getpid()}")
            tmp.write_text(text, encoding="utf-8")
            os.replace(tmp, path)  # 원자적 교체
        files = sorted(p for p in self.directory.glob(f"{safe}_2*.json"))
        for old in files[:-MAX_KEEP]:
            old.unlink(missing_ok=True)
        return hist


class RoundTripSnapshotStore(SnapshotStore):
    """SnapshotStore 와 같은 파일 형식. 로드할 때만 float 를 round_trip 정밀도로 읽는다.

    기본 CSV 파서는 저장했던 값과 끝자리(1 ulp)가 달라질 수 있어, 변화가 없는 데이터가
    '수정'으로 잡힌다. 기존 SnapshotStore 는 수정하지 않고 이 대시보드에서만 대체한다.
    """

    def load(self, symbol):
        path = self.path(symbol)
        if not path.exists():
            return None
        return pd.read_csv(path, parse_dates=["timestamp"], float_precision="round_trip")
