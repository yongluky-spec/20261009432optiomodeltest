"""TRACES — 엔진이 이미 낸 결과에 '공식 + 실제 입력값 대입'을 붙여 설명 구조로 만든다.

원칙: 여기서는 엔진(ChangeDetector / DataValidator / ReliabilityEngine / MonitoringEngine)의
숫자를 그대로 쓴다. 재계산은 '검증용'으로만 하고, 엔진 값과 다르면 match=False 로 드러낸다.
엔진의 공식·임계값을 바꾸지 않는다.
"""
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from .util import f4, g, isnum, pct, sgn, show

N_COMPONENTS = 6
COMPONENT_MAX = 100.0 / N_COMPONENTS  # 항목당 최대 기여도(점)

# 어떤 필드가 어떤 계산의 입력으로 들어가는지 (코드 열람 결과)
FIELD_CONSUMERS: Dict[str, List[str]] = {
    "open": ["OHLC 검증"],
    "high": ["OHLC 검증", "Breakout(직전 20봉 고가)", "StateSpace(ATR14)"],
    "low": ["OHLC 검증", "Breakout(직전 20봉 저가)", "StateSpace(ATR14)"],
    "close": ["OHLC 검증", "이상치 검증(로그수익률 z)", "교차 원천 일치", "Momentum", "Hook_OU",
              "Threshold", "Regime", "StateSpace"],
    "volume": ["결측 검증", "교차 원천 일치(거래량)"],
    "trade_amount": ["TIR v1/v2 (거래대금 κ)"],
    "timestamp": ["최신성", "시간 검증", "연속성 검증", "중복 검증"],
    "source": ["신뢰도 리포트 원천", "예측 원장 source"],
    "quality": ["표시용 등급"],
}


# ----------------------------------------------------------------------------- 변경(전·후)
def _signed(d) -> str:
    """Δ 표기: 아주 작은 값은 과학표기로 남겨 '+0'으로 뭉개지지 않게 한다."""
    if not isnum(d):
        return "—"
    d = float(d)
    if d != 0 and abs(d) < 1e-4:
        return ("+" if d > 0 else "-") + f"{abs(d):.3e}"
    return f"{d:+,.4f}".rstrip("0").rstrip(".")


def _pct_signed(p) -> str:
    if not isnum(p):
        return "—"
    p = float(p)
    if p != 0 and abs(p) < 1e-4:
        return ("+" if p > 0 else "-") + f"{abs(p):.3e}%"
    return pct(p)


def _key_str(key) -> str:
    return " @ ".join(str(k) for k in key) if isinstance(key, (list, tuple)) else str(key)


def change_trace(changes: dict, max_rows: int = 40) -> Dict[str, Any]:
    """ChangeDetector 결과 → 필드별 (이전, 현재, Δ, Δ%) + 치환된 공식."""
    rows: List[Dict[str, Any]] = []
    for item in changes.get("modified", []):
        key = _key_str(item["key"])
        for field, ch in item["changes"].items():
            prev, curr = ch.get("previous"), ch.get("current")
            row = {"key": key, "field": field, "prev": prev, "curr": curr,
                   "numeric": "delta" in ch, "delta": ch.get("delta"), "pct": ch.get("pct_change"),
                   "delta_formula": "", "pct_formula": "", "kind": "값 변경",
                   "consumers": FIELD_CONSUMERS.get(field, [])}
            if row["numeric"]:
                d = ch["delta"]
                row["delta_formula"] = f"Δ = 현재 - 이전 = {g(curr)} - {g(prev)} = {_signed(d)}"
                if ch.get("pct_change") is None:
                    row["pct_formula"] = "Δ% : 이전값이 0 이라 계산할 수 없음"
                else:
                    row["pct_formula"] = (f"Δ% = (현재 - 이전) ÷ 이전 × 100 = ({g(curr)} - {g(prev)}) ÷ {g(prev)} × 100"
                                          f" = {_pct_signed(ch['pct_change'])}")
                    if abs(ch["pct_change"]) < 1e-9:
                        row["kind"] = "부동소수점 잡음 의심"
            else:
                if prev is not None and curr is None:
                    row["kind"] = "결측 발생"
                elif prev is None and curr is not None:
                    row["kind"] = "결측 해소"
                else:
                    row["kind"] = "값 변경(비수치)"
                row["delta_formula"] = f"{show(prev)} → {show(curr)}"
            rows.append(row)

    added = [{"key": _key_str(a["key"]), **{k: a["current"].get(k) for k in
             ("open", "high", "low", "close", "volume", "source", "quality")}} for a in changes.get("added", [])]
    removed = [{"key": _key_str(r["key"]), **{k: r["previous"].get(k) for k in
               ("open", "high", "low", "close", "volume", "source", "quality")}} for r in changes.get("removed", [])]
    noise = sum(1 for r in rows if r["kind"] == "부동소수점 잡음 의심")
    field_counts: Dict[str, int] = {}
    for r in rows:
        field_counts[r["field"]] = field_counts.get(r["field"], 0) + 1
    return {
        "summary": {"added": len(added), "removed": len(removed), "modified": len(changes.get("modified", [])),
                    "unchanged": changes.get("unchanged", 0), "changed_count": changes.get("changed_count", 0)},
        "rows": rows[:max_rows], "rows_total": len(rows),
        "added": added[:12], "added_total": len(added),
        "removed": removed[:12], "removed_total": len(removed),
        "field_counts": field_counts, "noise_count": noise,
    }


# ----------------------------------------------------------------------------- 검증
def validation_trace(validation: dict, data: pd.DataFrame) -> List[Dict[str, Any]]:
    """검증마다 '기준 → 실제 측정값 → 판정' 과 실제 대입식."""
    v = validation.get("validators", {})
    n = len(data)
    cols = len(data.columns)
    rows: List[Dict[str, Any]] = []

    def base(vid, name, criterion, formula):
        r = v.get(vid, {})
        d = r.get("details", {})
        return {"id": vid, "name": name, "criterion": criterion, "formula": formula,
                "passed": bool(r.get("passed", False)), "details": d, "error": d.get("error"),
                "substituted": "", "measured": None, "measured_text": "—", "note": ""}

    r = base("missing", "결측", "결측률 < 1%", "결측률 = 결측 셀 ÷ (행 수 × 열 수)")
    d = r["details"]
    if not r["error"]:
        rate = d.get("missing_rate", 0.0)
        r["measured"] = rate
        r["substituted"] = f"{d.get('missing_cells', 0)} ÷ ({n} × {cols}) = {rate * 100:.4f}%"
        r["measured_text"] = f"{rate * 100:.4f}%"
    rows.append(r)

    r = base("duplicate", "중복", "중복률 < 1%", "중복률 = 같은 timestamp 의 중복 행 ÷ 행 수")
    d = r["details"]
    if not r["error"]:
        rate = d.get("duplicate_rate", 0.0)
        r["measured"] = rate
        r["substituted"] = f"{d.get('duplicates', 0)} ÷ {n} = {rate * 100:.4f}%"
        r["measured_text"] = f"{rate * 100:.4f}%"
    rows.append(r)

    r = base("timestamp", "시간 순서", "timestamp 단조 증가 (역행 0건)", "역행 수 = (이전 봉보다 시각이 앞선 봉)의 개수")
    d = r["details"]
    if not r["error"]:
        b = d.get("backward_steps", 0)
        r["measured"] = b
        r["substituted"] = f"역행 {b}건 · 단조 증가 = {d.get('monotonic')}"
        r["measured_text"] = f"역행 {b}건"
    rows.append(r)

    r = base("ohlc", "OHLC 관계", "위반 0건", "위반 = high < max(open,close,low) 또는 low > min(open,close,high) 또는 high < low")
    d = r["details"]
    if not r["error"]:
        b = d.get("violations", 0)
        r["measured"] = b
        r["substituted"] = f"위반 {b}건 / 전체 {n}행"
        r["measured_text"] = f"위반 {b}건"
    rows.append(r)

    r = base("outlier", "이상치", "|z| > 4 인 수익률 0건",
             "z = (r - 평균) ÷ 표준편차, r = ln(close_t / close_t-1)")
    d = r["details"]
    if not r["error"]:
        cnt = d.get("outliers", 0)
        m = max(n - 1, 0)
        if m < 10:
            r["substituted"] = f"수익률 {m}개 < 10 → 표본 부족으로 자동 통과"
        else:
            r["substituted"] = f"|z|>4 : {cnt}건 ÷ 수익률 {m}개 = {cnt / m * 100:.4f}%"
        r["measured"] = cnt
        r["measured_text"] = f"{cnt}건"
    rows.append(r)

    r = base("continuity", "연속성", "봉 간격 5일 초과 0건", "큰 간격 = (이전 봉과의 간격을 '일' 단위로 잘랐을 때 5 초과)인 봉의 개수")
    d = r["details"]
    if not r["error"]:
        gaps = pd.to_datetime(data["timestamp"]).diff().dropna()
        mx = gaps.max() if len(gaps) else pd.Timedelta(0)
        r["measured"] = d.get("large_gaps", 0)
        r["substituted"] = f"큰 간격 {d.get('large_gaps', 0)}건 (관측 최대 간격 {mx})"
        r["measured_text"] = f"큰 간격 {d.get('large_gaps', 0)}건"
        if len(gaps) and gaps.median() < pd.Timedelta(days=1):
            r["note"] = "봉 간격이 1일 미만이라 '일' 단위 검사는 항상 통과합니다(개선 후보 ④)."
    rows.append(r)

    for r in rows:
        if r["error"]:
            r["substituted"] = f"검증기 오류: {r['error']}"
            r["measured_text"] = "오류"
    return rows


# ----------------------------------------------------------------------------- 신뢰도
def reliability_trace(report: dict, validation: dict, data: pd.DataFrame, now: pd.Timestamp,
                      halflife: float, cross: dict, n_sources: int, engine_score: float) -> Dict[str, Any]:
    """신뢰도 6개 항목 각각의 공식/입력값/계산값/기여도/판정 + 합산식."""
    v = validation.get("validators", {})
    fresh = report["freshness"]
    comp = report["completeness"]
    cons = report["consistency"]
    tsq = report["timestamp_quality"]
    agree = report["cross_source_agreement"]
    dup, mis, out = report["duplicate_rate"], report["missing_rate"], report["outlier_rate"]
    contam = 1.0 - min(dup + mis + out, 1.0)

    # 최신성 재계산(검증용): 엔진 내부 시각과 수 초 차이가 나므로 허용 오차를 둔다
    last_ts = pd.to_datetime(data["timestamp"]).iloc[-1] if len(data) else None
    hours = max((now - last_ts).total_seconds() / 3600.0, 0.0) if last_ts is not None else None
    fresh_re = (0.5 ** (hours / halflife)) if hours is not None else 0.0
    fresh_match = abs(fresh_re - fresh) <= 1e-3

    ohlc_ok = bool(v.get("ohlc", {}).get("passed", False))
    cont_ok = bool(v.get("continuity", {}).get("passed", False))
    ts_ok = bool(v.get("timestamp", {}).get("passed", False))
    cons_re = max(1.0 - 0.5 * (not ohlc_ok) - 0.25 * (not cont_ok), 0.0)

    def item(key, name, formula, inputs, substituted, value, recomputed, linked, extra_verdict=None):
        contribution = value / N_COMPONENTS * 100.0
        loss = COMPONENT_MAX - contribution
        if extra_verdict:
            verdict = extra_verdict
        else:
            verdict = "만점" if loss < 0.005 else f"감점 -{loss:.2f}점"
        return {"key": key, "name": name, "formula": formula, "inputs": inputs,
                "substituted": substituted, "value": value, "recomputed": recomputed,
                "match": (recomputed is None) or abs(recomputed - value) <= 1e-3,
                "contribution": contribution, "loss": loss, "verdict": verdict,
                "linked": linked, "full": loss < 0.005}

    items = [
        item("freshness", "최신성", "0.5 ^ (경과시간 ÷ 반감기)",
             (f"마지막 봉 {last_ts} · 현재 {now.strftime('%Y-%m-%d %H:%M:%S')} · 경과 {hours:,.1f}시간 · 반감기 {g(halflife)}시간"
              if hours is not None else "데이터 없음"),
             (f"0.5 ^ ({hours:,.1f} ÷ {g(halflife)}) = {f4(fresh_re)}" if hours is not None else "0"),
             fresh, fresh_re if hours is not None else None, []),
        item("completeness", "완결성", "1 - 결측률",
             f"결측률 = {mis * 100:.4f}%", f"1 - {g(mis)} = {f4(1 - mis)}",
             comp, max(1.0 - mis, 0.0), ["결측"]),
        item("consistency", "일관성", "1 - 0.5×[OHLC 실패] - 0.25×[연속성 실패]  (최소 0)",
             f"OHLC 검증 {'통과' if ohlc_ok else '실패'} · 연속성 검증 {'통과' if cont_ok else '실패'}",
             f"1 - 0.5×{int(not ohlc_ok)} - 0.25×{int(not cont_ok)} = {f4(cons_re)}",
             cons, cons_re, ["OHLC 관계", "연속성"]),
        item("timestamp_quality", "시간 품질", "시간 검증 통과 1.0 / 실패 0.5",
             f"시간 순서 검증 {'통과' if ts_ok else '실패'}",
             f"{'1.0' if ts_ok else '0.5'}", tsq, 1.0 if ts_ok else 0.5, ["시간 순서"]),
        item("cross_source_agreement", "원천 일치", "일치한 원천 수 ÷ 비교한 원천 수",
             (f"원천 {n_sources}개 비교" if n_sources >= 2 else "원천 1개 → 비교 없음, 기본값 1.0 적용"),
             (" + ".join(f"{int(c['match'])}" for c in cross.get("comparisons", {}).values())
              + f" ÷ {len(cross.get('comparisons', {}))} = {f4(agree)}" if n_sources >= 2 and cross.get("comparisons")
              else f"{f4(agree)} (기본값)"),
             agree, None, []),
        item("contamination", "오염도", "1 - min(중복률 + 결측률 + 이상치율, 1)",
             f"중복률 {dup * 100:.4f}% · 결측률 {mis * 100:.4f}% · 이상치율 {out * 100:.4f}%",
             f"1 - min({g(dup)} + {g(mis)} + {g(out)}, 1) = {f4(contam)}",
             contam, contam, ["중복", "결측", "이상치"]),
    ]
    # 오염도는 report 에 저장되지 않는 파생값 → 엔진 overall_score 와 같은 식으로 직접 계산한 값이다
    total = sum(i["value"] for i in items)
    score_calc = round(total / N_COMPONENTS * 100, 1)
    sum_str = " + ".join(f4(i["value"]) for i in items)
    return {
        "items": items,
        "sum": total,
        "sum_str": f"{sum_str} = {total:.4f}",
        "score_formula": "신뢰도 = (6개 항목 값의 합) ÷ 6 × 100",
        "score_substituted": f"{total:.4f} ÷ 6 × 100 = {score_calc}",
        "score_calc": score_calc,
        "score_engine": engine_score,
        "score_match": abs(score_calc - engine_score) < 1e-9,
        "freshness_match": fresh_match,
        "hours": hours,
    }


def status_chain(validation: dict, score: float, agreement: float, changed_count: int,
                 final_status: str) -> List[Dict[str, Any]]:
    """MonitoringEngine._status 의 판정 순서를 실제 값으로 보여준다 (위에서부터 처음 걸린 규칙이 결과)."""
    v_ok = bool(validation.get("passed", False))
    rules = [
        ("검증 전체 통과?", f"검증 통과 = {v_ok}", (not v_ok), "ERROR"),
        ("신뢰도 < 70 또는 원천 일치 < 0.67?",
         f"신뢰도 {score} {'<' if score < 70 else '≥'} 70 · 일치 {g(agreement)} {'<' if agreement < 0.67 else '≥'} 0.67",
         (score < 70.0 or agreement < 0.67), "WARNING"),
        ("데이터 변경 있음?", f"변경 {changed_count}행", changed_count > 0, "CHANGED"),
        ("위 조건 모두 아님", "—", True, "NORMAL"),
    ]
    out, decided = [], False
    for i, (q, actual, fires, result) in enumerate(rules, 1):
        if decided:
            out.append({"n": i, "question": q, "actual": actual, "fired": False, "evaluated": False, "result": result})
            continue
        out.append({"n": i, "question": q, "actual": actual, "fired": bool(fires), "evaluated": True, "result": result})
        if fires:
            decided = True
    return out


# ----------------------------------------------------------------------------- 개선 후보 (적용 안 됨)
def improvement_candidates(report: dict, data: pd.DataFrame, rel: Dict[str, Any], cross: dict,
                           n_sources: int, source_name: str, ch: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """앞서 발견한 문제를 '현재 데이터로 계산한 근거'와 함께 보여준다. 엔진 계산에는 반영하지 않는다."""
    score = rel["score_engine"]
    fresh = report["freshness"]
    lost_fresh = (1 - fresh) / N_COMPONENTS * 100
    mis, dup, out = report["missing_rate"], report["duplicate_rate"], report["outlier_rate"]
    last_close = float(data["close"].iloc[-1]) if len(data) and isnum(data["close"].iloc[-1]) else None

    cands = []
    cands.append({
        "id": "C1", "title": "① 최신성: 가상·재생 데이터도 실시간처럼 시간이 지나면 감점",
        "evidence": [
            f"원천 이름: {source_name}",
            f"마지막 봉과 현재의 차이 {rel['hours']:,.1f}시간 → 최신성 {f4(fresh)}" if rel["hours"] is not None else "데이터 없음",
            f"최신성으로 잃은 점수 = (1 - {f4(fresh)}) ÷ 6 × 100 = {lost_fresh:.2f}점",
            f"참고 계산: 최신성을 1.0 으로 가정하면 신뢰도 {score} → {round(score + lost_fresh, 1)}",
        ],
        "impact": "가상·백테스트 데이터는 항상 낮은 점수가 나옵니다. 판단 기준(가상/실시간 구분)을 정한 뒤 반영 여부를 결정해야 합니다.",
    })
    both = mis / N_COMPONENTS * 100
    cands.append({
        "id": "C2", "title": "② 결측률이 두 항목에서 함께 감점 (이중 감점)",
        "evidence": [
            f"결측률 {mis * 100:.4f}% 는 완결성(1 - 결측률)과 오염도(1 - min(중복+결측+이상치, 1))에 모두 들어감",
            f"결측으로 인한 감점 = {both:.4f}점(완결성) + {both:.4f}점(오염도) = {both * 2:.4f}점",
            f"한 번만 반영하면 {both:.4f}점",
            f"중복률 {dup * 100:.4f}% · 이상치율 {out * 100:.4f}% 는 오염도에만 들어가 1회 반영",
        ],
        "impact": "결측만 다른 문제보다 두 배로 감점됩니다. 결측이 커질수록 차이가 벌어집니다.",
    })
    tol = 0.01
    ev3 = ["원천 일치 = 일치 원천 수 ÷ 비교 원천 수 (기준값 = 원천들의 최대 종가, 허용 오차 = 절대 0.01)"]
    if last_close:
        ev3.append(f"허용 오차 0.01 은 현재 종가 {g(last_close)} 의 {tol / last_close * 100:.4f}%")
    if n_sources >= 2 and cross.get("comparisons"):
        for s, c in cross["comparisons"].items():
            ev3.append(f"{s}: 종가 {g(c['close'])} · 기준과 차이 {g(c['close_diff'])} · 거래량 차이비 {g(c['volume_diff_ratio'])} · "
                       f"{'일치' if c['match'] else '불일치'}")
        ev3.append("기준값이 최대 종가라서 최대 종가 원천은 자기 자신과 비교되어 항상 일치로 처리됨")
    else:
        ev3.append("현재 원천 1개 → 비교를 수행하지 않고 1.0 을 사용")
    cands.append({
        "id": "C3", "title": "③ 원천 일치 기준: 최대값 기준 + 고정 절대 허용 오차",
        "evidence": ev3,
        "impact": "가격대가 다른 종목에 같은 절대 오차를 쓰면 판정 강도가 달라지고, 최대 종가 원천은 비교 대상에서 사실상 빠집니다.",
    })
    gaps = pd.to_datetime(data["timestamp"]).diff().dropna() if len(data) else pd.Series(dtype="timedelta64[ns]")
    med = gaps.median() if len(gaps) else None
    cands.append({
        "id": "C4", "title": "④ 연속성 검증: 분봉에는 '일' 단위 검사가 무의미",
        "evidence": [
            f"관측된 봉 간격 중앙값 {med}" if med is not None else "간격 데이터 없음",
            "검사는 '간격을 일 수로 자른 값 > 5'인 봉을 세므로 1일 미만 간격은 항상 0일 → 항상 통과",
            f"현재 연속성 검증 결과: 큰 간격 {report['checks'].get('continuity', {}).get('details', {}).get('large_gaps', 0)}건",
        ],
        "impact": "분봉 데이터의 결측 구간(중간에 빠진 봉)은 이 검증으로 잡히지 않습니다.",
    })
    noise = (ch or {}).get("noise_count", 0)
    cands.append({
        "id": "C5", "title": "⑤ 변경 감지에 수치 허용 오차가 없음 (1 ulp 차이도 '수정'으로 집계)",
        "evidence": [
            "비교식은 이전 != 현재 이므로 부동소수점 끝자리(1e-12 수준) 차이도 변경 행이 됨",
            f"이번 실행에서 |Δ%| < 1e-9 인 '잡음 의심' 변경: {noise}건",
            "기본 SnapshotStore(CSV 기본 파서)로 저장·재로드하면 같은 데이터가 수정 행으로 잡히는 것을 테스트에서 확인함 "
            "→ 대시보드는 자체 로더(round_trip 파싱)로 이 현상을 피하지만 ChangeDetector 자체는 그대로임",
        ],
        "impact": "원천이 다르거나 재저장을 거친 데이터에서 실제 변화가 없는데도 CHANGED 로 표시될 수 있습니다.",
    })
    return cands
