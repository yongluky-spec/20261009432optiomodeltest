"""DEMO — 대시보드 동작 확인용 시나리오 (이전 / 현재 데이터 한 쌍을 만든다).

수집기가 만든 CSV(예: kospi_synthetic_bars.csv)의 앞 390행(= 09:00~15:29 정규장 1일)을 '이전',
그 위에 다음 변경을 얹은 것을 '현재'로 쓴다. 값은 모두 CSV 에서 가져오고 새로 만들지 않는다.
  - 마지막 3봉의 종가/고가를 수정   - 뒤에 5봉 추가   - 추가 봉 일부의 거래량을 결측으로
"""
import pandas as pd


def build_demo_pair(csv_path, base_rows: int = 390, add_rows: int = 5):
    d = pd.read_csv(csv_path, parse_dates=["timestamp"])
    prev = d.iloc[:base_rows].copy().reset_index(drop=True)
    cur = d.iloc[:base_rows + add_rows].copy().reset_index(drop=True)
    idx = list(range(base_rows - 3, base_rows))
    for i, dc in zip(idx, (0.10, -0.05, 0.15)):
        cur.loc[i, "close"] = float(prev.loc[i, "close"]) + dc
        cur.loc[i, "high"] = max(float(cur.loc[i, "high"]), float(cur.loc[i, "close"]))
        cur.loc[i, "low"] = min(float(cur.loc[i, "low"]), float(cur.loc[i, "close"]))
    cur.loc[[base_rows + 1, base_rows + 3], "volume"] = float("nan")
    # 두 번째 원천(같은 봉을 다른 곳에서 받았다고 가정): 마지막 종가가 0.004 다르고 거래량이 2% 다름
    alt = cur.copy()
    alt.loc[alt.index[-1], "close"] = float(alt["close"].iloc[-1]) + 0.004
    alt.loc[alt.index[-1], "volume"] = float(alt["volume"].iloc[-1] or 0) * 1.02 if pd.notna(alt["volume"].iloc[-1]) else 0
    alt["source"] = "synthetic_alt"
    return prev, cur, {"synthetic_collector": cur, "synthetic_alt": alt}
