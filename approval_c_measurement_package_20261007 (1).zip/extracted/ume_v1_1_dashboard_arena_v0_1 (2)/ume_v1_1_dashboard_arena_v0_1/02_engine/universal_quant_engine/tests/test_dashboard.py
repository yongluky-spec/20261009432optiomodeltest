"""대시보드 테스트 — 공식 표시, 신뢰도 재계산, 검증 표, 이전/현재 비교, 렌더링, 미연결 처리, 서버.
실행: python 02_engine/universal_quant_engine/tests/test_dashboard.py  (프로젝트 루트에서)
"""
import json
import os
import sys
import tempfile
import threading
import urllib.request
import warnings

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "02_engine"))
sys.path.insert(0, os.path.join(ROOT, "01_strategy"))
sys.path.insert(0, ROOT)
warnings.simplefilter("ignore")

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from universal_quant_engine.dashboard import DashboardRunner  # noqa: E402
from universal_quant_engine.dashboard.demo import build_demo_pair  # noqa: E402
from universal_quant_engine.dashboard.render import render_html  # noqa: E402
from universal_quant_engine.dashboard.server import make_server  # noqa: E402
from universal_quant_engine.monitoring import MonitoringEngine  # noqa: E402

DEMO_CSV = os.path.join(ROOT, "04_data", "demo_kospi_synthetic_bars.csv")
results = []


def check(name, cond):
    results.append((name, bool(cond)))
    print(f"{'PASS' if cond else 'FAIL'} - {name}")


def mock5():
    ts = pd.date_range("2026-09-28 09:00", periods=5, freq="min")
    close = [100.0, 101.0, 102.0, 103.0, 104.5]
    return pd.DataFrame({
        "timestamp": ts, "symbol": "KOSPI", "open": [c - 0.5 for c in close], "high": [c + 0.5 for c in close],
        "low": [c - 1.0 for c in close], "close": close, "volume": [1000, 1100, 1200, 1300, 1400],
        "trade_amount": [c * v for c, v in zip(close, [1000, 1100, 1200, 1300, 1400])],
        "source": "mock", "quality": "GOOD"})


def main():
    # ---- 1. 공식 표시 (변경 5행 데이터)
    d = tempfile.mkdtemp()
    r = DashboardRunner(d, arena_path="__none__")
    prev = mock5()
    cur = prev.copy()
    cur.loc[4, "close"], cur.loc[4, "high"], cur.loc[4, "volume"] = 106.5, 107.0, 1800
    r.run(prev, symbol="KOSPI")
    rep = r.run(cur, symbol="KOSPI")
    rows = {(x["field"]): x for x in rep["changes"]["rows"]}
    check("Δ 공식 대입: 106.5 - 104.5 = +2", "= 106.5 - 104.5 = +2" in rows["close"]["delta_formula"])
    check("Δ% 공식 대입: (106.5 - 104.5) ÷ 104.5 × 100 = +1.91%",
          "(106.5 - 104.5) ÷ 104.5 × 100 = +1.91%" in rows["close"]["pct_formula"])
    check("거래량 Δ% = +28.57%", "+28.57%" in rows["volume"]["pct_formula"])
    check("변경 필드가 들어가는 계산이 연결됨", "이상치 검증(로그수익률 z)" in rows["close"]["consumers"])

    # ---- 2. 신뢰도 재계산 = 엔진
    rel = rep["reliability"]
    check("신뢰도 합산식이 엔진 점수와 일치", rel["score_match"])
    check("신뢰도 항목 6개", len(rel["items"]) == 6)
    check("항목별 재계산 일치(최신성 포함)", all(i["match"] for i in rel["items"]))
    check("합산식 표시: '÷ 6 × 100 ='", "÷ 6 × 100 =" in rel["score_substituted"])
    check("기여도 합 = 점수(반올림 오차 내)",
          abs(sum(i["contribution"] for i in rel["items"]) - rep["summary"]["score"]) < 0.06)
    direct = MonitoringEngine().run(current=cur, previous=prev)
    check("대시보드 점수 == 엔진 직접 호출 점수(계산 로직 무변경)", abs(direct.overall_score - rep["summary"]["score"]) < 0.11)
    check("상태 == 엔진 직접 호출 상태", direct.status == rep["summary"]["status"])

    # ---- 3. 검증 표
    check("검증 6개 행", len(rep["validation"]) == 6)
    check("검증 행 = 기준→실측→판정", all(v["criterion"] and v["measured_text"] and isinstance(v["passed"], bool)
                                       for v in rep["validation"]))
    check("검증 판정이 엔진과 동일",
          all(v["passed"] == direct.validation["validators"][v["id"]]["passed"] for v in rep["validation"]))

    # ---- 4. 이전 실행 비교
    check("두 번째 실행: 이전 실행 있음", rep["compare"]["has_prev"] and rep["meta"]["has_prev_run"])
    r0 = DashboardRunner(tempfile.mkdtemp(), arena_path="__none__").run(prev, symbol="KOSPI")
    check("첫 실행: 이전 없음 표시", not r0["compare"]["has_prev"])
    ch_labels = [x["label"] for g in rep["compare"]["groups"] for x in g["rows"] if x["changed"]]
    check("이전 실행 대비 변경 항목 감지(마지막 종가)", "마지막 종가" in ch_labels)
    rp = DashboardRunner(d, arena_path="__none__").run(cur, symbol="KOSPI")
    check("같은 데이터 재실행: 변경 0행(부동소수점 잡음 없음)", rp["changes"]["summary"]["changed_count"] == 0)

    # ---- 5. 검증 실패 경로
    bad = prev.copy()
    bad.loc[2, "high"] = 90.0  # OHLC 위반
    rb = DashboardRunner(tempfile.mkdtemp(), arena_path="__none__").run(bad, symbol="KOSPI")
    check("OHLC 위반 → 상태 ERROR", rb["summary"]["status"] == "ERROR")
    check("판정 경로 1번 규칙에서 결정", rb["status_chain"][0]["fired"] and not rb["status_chain"][1]["evaluated"])
    check("실패 검증이 표에 FAIL 로 표시", any(v["id"] == "ohlc" and not v["passed"] for v in rb["validation"]))

    # ---- 6. Arena 연결 (kospi_arena 모듈)
    prev2, cur2, frames = build_demo_pair(DEMO_CSV)
    d2 = tempfile.mkdtemp()
    ra = DashboardRunner(d2)
    ra.run(prev2, symbol="KOSPI")
    rep2 = ra.run(cur2, symbol="KOSPI", source_frames=frames)
    check("Arena 연결됨", rep2["meta"]["arena"]["available"])
    ck = rep2["arena_checks"]
    check(f"화면 공식이 Arena 결과를 재현 ({sum(c['ok'] for c in ck)}/{len(ck)})", len(ck) >= 10 and all(c["ok"] for c in ck))
    check("9개 단계(입력/출력) 표시", len(rep2["stages"]) == 9 and all(s["input"] and s["output"] for s in rep2["stages"]))
    check("모델 입력 창 안의 변경 행 수 계산", rep2["window_hits"].get("Momentum", 0) >= 1)
    check("원천 2개 비교 표시", rep2["meta"]["n_sources"] == 2 and len(rep2["cross"]["comparisons"]) == 2)
    check("개선 후보 5건, 엔진 미반영", len(rep2["candidates"]) == 5)
    check("OOS Wilson 하한 재계산이 Arena 값과 일치", all(
        (o.get("k") is None) or abs(__import__("universal_quant_engine.dashboard.steps", fromlist=["x"]).wilson_parts(
            o["k"], o["n_eff"])["lower"] - o["da_ci_low"]) < 1e-9
        for o in rep2["summary"]["arena"]["oos"].values() if o.get("da_ci_low") is not None and o.get("n_eff")))

    # ---- 7. 렌더링
    html = render_html(rep2)
    order = [html.find(f'id="{s}"') for s in ("sec-status", "sec-change", "sec-valid", "sec-rel", "sec-compare", "sec-arena")]
    check("섹션 순서 ① 상태 ② 전후 ③ 검증 ④ 신뢰도 ⑤ 이전대비 → Arena 접기", all(o > 0 for o in order) and order == sorted(order))
    check("Arena 세부는 접기 영역(details)", '<details class="sec" id="sec-arena">' in html)
    check("신뢰도 계산 과정 표시", "÷ 6 × 100" in html and "= 83.3" in html)
    check("외부 스크립트/이미지/폰트 없음", "<script src" not in html and "http://" not in html.replace("http://127.0.0.1", "")
          and "https://" not in html and "@import" not in html)
    check("NaN/None/undefined 문자열 노출 없음", all(t not in html for t in (">nan<", ">None<", "undefined", ">NaN<")))

    # ---- 8. Arena 미연결 시에도 나머지는 동작
    rn = DashboardRunner(tempfile.mkdtemp(), arena_path="__없는경로__").run(cur2, symbol="KOSPI")
    hn = render_html(rn)
    check("Arena 경로 오류 → 미연결 표시 + 사유", (not rn["meta"]["arena"]["available"]) and "미연결" in hn)
    check("미연결이어도 ①~⑤ 렌더링", all(f'id="{s}"' in hn for s in ("sec-status", "sec-change", "sec-valid", "sec-rel", "sec-compare")))
    check("미연결이어도 신뢰도 계산 일치", rn["reliability"]["score_match"])

    # ---- 9. 서버
    srv, refresh = make_server(lambda: ra.run(cur2, symbol="KOSPI", source_frames=frames), port=0)
    host, port = srv.server_address
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    try:
        check("서버 127.0.0.1 바인딩", host == "127.0.0.1")
        body = urllib.request.urlopen(f"http://127.0.0.1:{port}/").read().decode("utf-8")
        check("GET / 화면 응답", "UME 데이터 추적 대시보드" in body)
        js = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{port}/state.json").read().decode("utf-8"))
        check("GET /state.json 요약 응답", "score" in js and "status" in js)

        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None
        try:
            urllib.request.build_opener(NoRedirect).open(f"http://127.0.0.1:{port}/refresh")
            ok = False
        except urllib.error.HTTPError as e:  # 303 → 리다이렉트 응답
            ok = e.code == 303
        check("GET /refresh 재실행 후 303 이동", ok)
    finally:
        srv.shutdown()
        srv.server_close()

    failed = [n for n, ok in results if not ok]
    print(f"\n결과: {len(results) - len(failed)}/{len(results)} 통과")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
