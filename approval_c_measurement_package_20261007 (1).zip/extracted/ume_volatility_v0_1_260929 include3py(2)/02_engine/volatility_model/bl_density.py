"""volatility_model.bl_density — Breeden-Litzenberger 위험중립 밀도.

상태: **BL v1.4 후보 코드 — B단계 실행 검증 대기.**  '검증 완료'가 아니다.
  - 기존 B단계 검증 스크립트(bl_synthetic_validation_v1)가 이 로직의 원본(breeden_litzenberger_v1.py)을 쓴다.
    검증 결과에 따라 로직이 바뀌면 두 파일을 함께 갱신해야 한다 (이 파일은 원본의 로직 변경 없는 이동본).
  - 합성 로그정규 데이터에서만 확인했고 실제 호가·시장 분포에서는 확인하지 않았다.
  - 미확정: NEG_TOL_REL(상대 허용오차 1e-6, 잠정), warn_T/stop_T(None=미작동), 평활 강도 s 규칙(가설),
            ① 회귀 기준, ④ 만기 민감도 재설계.

입력: 행사가와 콜 가격 곡선 (implied_vol.otm_call_curve / smoothed_call_curve_from_iv 의 결과),
      선도가 F(상·하방 질량 기준), 만기 T, 이자율 r.
      IV 경로(smoothed_call_curve_from_iv)의 결과는 이미 평활된 곡선이므로 smoothing_s=None 으로 쓴다.
출력: q(K) = e^{rT} * d2C/dK2, 진단(음수 밀도, 적분, 단조성/볼록성), F 기준 상·하방 위험중립 질량.
      질량은 위험중립 질량이며 실제 발생확률이 아니다.
이 모듈은 거래 차단(no_trade)을 판정하지 않는다 (gate 계층의 몫).
"""

from dataclasses import dataclass, field
import numpy as np
from scipy.interpolate import CubicSpline, UnivariateSpline

_trapz = getattr(np, "trapezoid", None) or np.trapz
NEG_TOL_REL = 1e-6


@dataclass
class BLResult:
    strikes: np.ndarray
    density: np.ndarray
    integral: float
    integral_clipped: float
    neg_density_ratio: float
    monotonic_violations: int
    convexity_violations: int
    downside_mass: float
    upside_mass: float
    clipped_negative: bool
    status: str
    warnings: list = field(default_factory=list)


def _validate_inputs(strikes, call_prices, T, forward):
    k = np.asarray(strikes, dtype=float)
    c = np.asarray(call_prices, dtype=float)
    if k.ndim != 1 or c.ndim != 1 or k.shape != c.shape:
        raise ValueError("strikes/call_prices는 같은 길이의 1차원 배열이어야 합니다.")
    if len(k) < 5:
        raise ValueError("행사가 격자는 5점 이상이어야 합니다.")
    if not (np.all(np.isfinite(k)) and np.all(np.isfinite(c))):
        raise ValueError("NaN 또는 비유한 값이 있습니다.")
    if not np.isfinite(forward) or forward <= 0:
        raise ValueError("forward는 양의 유한 값이어야 합니다.")
    if T <= 0:
        raise ValueError("T는 양수여야 합니다.")


def _rel_tol_mask(values, tol_rel=NEG_TOL_REL):
    peak = np.max(np.abs(values)) if len(values) else 0.0
    thr = tol_rel * peak if peak > 0 else 0.0
    return values < -thr


def bl_density(strikes, call_prices, forward, T, r=0.0,
               smoothing_s=None, warn_T=None, stop_T=None) -> BLResult:
    _validate_inputs(strikes, call_prices, T, forward)
    order = np.argsort(strikes)
    k = np.asarray(strikes, dtype=float)[order]
    c = np.asarray(call_prices, dtype=float)[order]
    if np.any(np.diff(k) <= 0):
        raise ValueError("행사가 중복이 존재합니다.")
    if np.any(c < -1e-12):
        raise ValueError("콜 가격에 음수가 있습니다.")

    warnings, status = [], "OK"
    if stop_T is not None and T < stop_T:
        status = "STOP"; warnings.append("stop")
    elif warn_T is not None and T < warn_T:
        status = "WARN"; warnings.append("warn")

    if smoothing_s is None:
        spline = CubicSpline(k, c)
        d1 = spline(k, 1); d2 = spline(k, 2)
    else:
        spline = UnivariateSpline(k, c, s=smoothing_s, k=3)
        d1 = spline.derivative(1)(k); d2 = spline.derivative(2)(k)
    q = np.exp(r * T) * d2

    monotonic_violations = int(np.sum(_rel_tol_mask(-d1)))
    neg_mask = _rel_tol_mask(q)
    neg_ratio = float(np.mean(neg_mask))
    convexity_violations = int(np.sum(_rel_tol_mask(d2)))

    integral = float(_trapz(q, k))
    q_pos = np.clip(q, 0.0, None)
    clipped_negative = bool(np.any(q < 0))
    integral_clipped = float(_trapz(q_pos, k))
    if neg_ratio > 0:
        warnings.append(f"음수 밀도 비율 {neg_ratio:.4f}")

    if k[0] <= forward <= k[-1]:
        q_spline = CubicSpline(k, q_pos)
        grid_lo = np.concatenate([k[k < forward], [forward]])
        grid_hi = np.concatenate([[forward], k[k > forward]])
        downside_mass = float(_trapz(q_spline(grid_lo), grid_lo))
        upside_mass = float(_trapz(q_spline(grid_hi), grid_hi))
    else:
        warnings.append("forward outside grid")
        below = k <= forward
        downside_mass = float(_trapz(q_pos[below], k[below])) if below.any() else 0.0
        upside_mass = float(_trapz(q_pos[~below], k[~below])) if (~below).any() else 0.0

    return BLResult(k, q, integral, integral_clipped, neg_ratio,
                    monotonic_violations, convexity_violations,
                    downside_mass, upside_mass, clipped_negative, status, warnings)

VALIDATION_STATUS = "BL v1.4 후보 코드 — B단계 실행 검증 대기"
