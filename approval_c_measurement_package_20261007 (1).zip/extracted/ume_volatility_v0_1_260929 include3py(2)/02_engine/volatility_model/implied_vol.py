"""volatility_model.implied_vol — 호가 중간값, OTM 선택, IV 역산, IV 곡선 평활.

확정 원칙: 체결가가 아니라 호가 중간값 / OTM 중심(K<F 풋, K>=F 콜) / IV 곡선 평활 → 옵션가격 환산.
두 경로를 제공한다 (bl_density 입력용 콜 가격 곡선을 만든다):
  - otm_call_curve                : OTM 호가 중간값 → (풋은 패러티로 콜 환산) → 콜 가격 곡선   ('price' 경로)
  - smoothed_call_curve_from_iv   : OTM IV 역산 → IV 곡선 평활 → 조밀 격자 콜 가격 환산      ('iv' 경로)
미확정: IV 평활 강도 smoothing_s 규칙(가격 공간의 s = n·σ_noise² 는 합성 데이터에서만 지지된 가설이며
        IV 공간에는 검증하지 않았다). smoothing_s=None 이면 보간(평활 없음).
품질 문제는 예외가 아니라 flags 로 보고한다 (교차호가, 매수호가 0, 호가 누락, 중복 호가, IV 역산 실패).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.interpolate import CubicSpline, UnivariateSpline
from scipy.optimize import brentq
from scipy.stats import norm

from .contracts import OptionChain, OptionQuote


def black_price(F, K, T, r, sigma, right: str):
    """선도가 기준 Black 가격 (할인 e^{-rT} 포함). K, sigma 는 배열 가능."""
    K = np.asarray(K, dtype=float)
    sigma = np.asarray(sigma, dtype=float)
    disc = math.exp(-r * T)
    sd = sigma * math.sqrt(T)
    d1 = (np.log(F / K) + 0.5 * sd**2) / sd
    d2 = d1 - sd
    if right == "C":
        return disc * (F * norm.cdf(d1) - K * norm.cdf(d2))
    if right == "P":
        return disc * (K * norm.cdf(-d2) - F * norm.cdf(-d1))
    raise ValueError("right는 'C' 또는 'P' 이어야 합니다.")


def implied_vol(price: float, F: float, K: float, T: float, r: float, right: str,
                lo: float = 1e-6, hi: float = 10.0) -> float:
    """호가 → 내재변동성. 무차원(연 변동성). 무차익 경계 밖이거나 해가 없으면 NaN."""
    disc = math.exp(-r * T)
    if right == "C":
        intrinsic, upper = disc * max(F - K, 0.0), disc * F
    elif right == "P":
        intrinsic, upper = disc * max(K - F, 0.0), disc * K
    else:
        raise ValueError("right는 'C' 또는 'P' 이어야 합니다.")
    if not (math.isfinite(price) and intrinsic + 1e-12 < price < upper - 1e-12):
        return float("nan")

    def f(s):
        return float(black_price(F, K, T, r, s, right)) - price

    if f(lo) > 0 or f(hi) < 0:
        return float("nan")
    return float(brentq(f, lo, hi, xtol=1e-12, rtol=1e-12, maxiter=200))


def quote_mid(q: OptionQuote) -> Tuple[Optional[float], Optional[str]]:
    """호가 중간값. (mid, None) 또는 사용 불가 시 (None, 사유)."""
    if q.bid is None or q.ask is None:
        return None, "missing_quote"
    if q.bid <= 0:
        return None, "zero_bid"
    if q.ask < q.bid:
        return None, "crossed_quote"
    return 0.5 * (q.bid + q.ask), None


@dataclass(frozen=True, eq=False)
class CallCurve:
    """bl_density 입력용 콜 가격 곡선 (행사가 오름차순)."""
    strikes: np.ndarray
    call_prices: np.ndarray
    route: str                      # "price" | "iv"
    flags: Tuple[str, ...]
    n_input_points: int             # 곡선 구성에 쓰인 원 행사가 수


@dataclass(frozen=True, eq=False)
class IVSlice:
    strikes: np.ndarray
    ivs: np.ndarray
    rights: Tuple[str, ...]
    flags: Tuple[str, ...]


def _otm_mids(chain: OptionChain) -> Tuple[List[float], List[float], List[str], List[str]]:
    """행사가별 OTM 쪽 호가 중간값. (strikes, mids, rights, flags)."""
    by_strike: Dict[float, Dict[str, OptionQuote]] = {}
    flags: List[str] = []
    for q in chain.quotes:
        slot = by_strike.setdefault(q.strike, {})
        if q.right in slot:
            flags.append(f"duplicate_quote@{q.strike:g}{q.right}")
            continue                # 첫 호가만 사용
        slot[q.right] = q
    ks, mids, rights = [], [], []
    for k in sorted(by_strike):
        right = "P" if k < chain.forward else "C"
        q = by_strike[k].get(right)
        if q is None:
            flags.append(f"missing_otm_side@{k:g}{right}")
            continue
        mid, why = quote_mid(q)
        if mid is None:
            flags.append(f"{why}@{k:g}{right}")
            continue
        ks.append(k); mids.append(mid); rights.append(right)
    return ks, mids, rights, flags


def otm_call_curve(chain: OptionChain, min_points: int = 5) -> CallCurve:
    """OTM 호가 중간값 → 풋은 패러티(C = P + e^{-rT}(F-K))로 콜 환산 → 콜 가격 곡선."""
    ks, mids, rights, flags = _otm_mids(chain)
    if len(ks) < min_points:
        raise ValueError(f"사용 가능한 OTM 행사가가 {len(ks)}개 (최소 {min_points}개 필요). flags={flags}")
    disc = math.exp(-chain.rate * chain.T)
    calls = [m if rt == "C" else m + disc * (chain.forward - k) for k, m, rt in zip(ks, mids, rights)]
    return CallCurve(np.asarray(ks), np.asarray(calls), "price", tuple(flags), len(ks))


def otm_implied_vols(chain: OptionChain) -> IVSlice:
    """행사가별 OTM 옵션의 내재변동성. 역산 실패는 제외하고 플래그를 남긴다."""
    ks, mids, rights, flags = _otm_mids(chain)
    out_k, out_iv, out_r = [], [], []
    for k, m, rt in zip(ks, mids, rights):
        iv = implied_vol(m, chain.forward, k, chain.T, chain.rate, rt)
        if math.isnan(iv):
            flags.append(f"iv_failed@{k:g}{rt}")
            continue
        out_k.append(k); out_iv.append(iv); out_r.append(rt)
    return IVSlice(np.asarray(out_k), np.asarray(out_iv), tuple(out_r), tuple(flags))


def smoothed_call_curve_from_iv(chain: OptionChain, smoothing_s: Optional[float] = None,
                                n_grid: int = 401, min_points: int = 5) -> CallCurve:
    """OTM IV 역산 → 로그 머니니스(ln(K/F)) 축에서 IV 곡선 평활 → 균등 K 격자 콜 가격 환산.

    smoothing_s=None: 보간 스플라인(평활 없음), 값이 있으면 평활 스플라인(UnivariateSpline s).
    관측 행사가 범위 밖으로는 외삽하지 않는다.
    """
    sl = otm_implied_vols(chain)
    if len(sl.strikes) < min_points:
        raise ValueError(f"IV 역산에 성공한 행사가가 {len(sl.strikes)}개 (최소 {min_points}개 필요). flags={sl.flags}")
    F = chain.forward
    x = np.log(sl.strikes / F)
    if smoothing_s is None:
        spline = CubicSpline(x, sl.ivs)
    else:
        spline = UnivariateSpline(x, sl.ivs, s=smoothing_s, k=3)
    grid_k = np.linspace(sl.strikes[0], sl.strikes[-1], n_grid)
    iv_grid = np.asarray(spline(np.log(grid_k / F)), dtype=float)
    flags = list(sl.flags)
    if np.any(iv_grid <= 1e-6):
        flags.append("iv_clipped")
        iv_grid = np.clip(iv_grid, 1e-6, None)
    calls = black_price(F, grid_k, chain.T, chain.rate, iv_grid, "C")
    return CallCurve(grid_k, np.asarray(calls, dtype=float), "iv", tuple(flags), len(sl.strikes))
