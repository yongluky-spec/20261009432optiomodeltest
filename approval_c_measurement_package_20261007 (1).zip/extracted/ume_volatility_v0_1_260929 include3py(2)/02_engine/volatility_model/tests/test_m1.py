"""volatility_model M1 테스트 — 합성 데이터만 사용, 네트워크·실제 계정 불필요.

주의: 여기의 임계값은 '모듈 연결이 맞게 동작하는지' 보는 회귀 기준이다.
      B단계 BL 검증 기준(①~④)이 아니며, bl_density 를 검증 완료로 만들지 않는다.

실행:  cd 02_engine && python -m volatility_model.tests.test_m1
"""
import dataclasses
import math
import os
import random
import re
import sys
from datetime import datetime, timedelta

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))

from volatility_model import contracts as ct  # noqa: E402
from volatility_model import implied_vol as iv  # noqa: E402
from volatility_model import synthetic as syn  # noqa: E402
from volatility_model.bl_density import VALIDATION_STATUS, bl_density  # noqa: E402

_trapz = getattr(np, "trapezoid", None) or np.trapz
results = []


def check(name, cond):
    results.append(bool(cond))
    print(f"{'PASS' if cond else 'FAIL'} - {name}")


def raises(fn, exc=ValueError):
    try:
        fn()
    except exc:
        return True
    except Exception:
        return False
    return False


def norm_tv(k, q_hat, q_true):
    a, b = np.clip(q_hat, 0, None), np.clip(q_true, 0, None)
    ma, mb = float(_trapz(a, k)), float(_trapz(b, k))
    return 0.5 * float(_trapz(np.abs(a / ma - b / mb), k))


def true_masses(k, q, F):
    below = k <= F
    g_lo = np.concatenate([k[below], [F]]); g_hi = np.concatenate([[F], k[~below]])
    return (float(_trapz(np.interp(g_lo, k, q), g_lo)), float(_trapz(np.interp(g_hi, k, q), g_hi)))


S, R, T, SIG = 250.0, 0.03, 0.25, 0.25
F = S * math.exp(R * T)
WIDE = np.linspace(0.5 * S, 2.0 * S, 161)


def test_contracts():
    print("-- contracts --")
    q = ct.OptionQuote(250.0, "C", 1.0, 1.2)
    ok_chain = dict(underlying="X", timestamp=datetime(2026, 1, 1), T=0.25, forward=250.0, rate=0.03, quotes=(q,))
    check("OptionQuote: 정상 생성", q.strike == 250.0 and q.right == "C")
    check("OptionQuote: 잘못된 right/strike/음수 호가 거부",
          raises(lambda: ct.OptionQuote(250.0, "X")) and raises(lambda: ct.OptionQuote(0.0, "C"))
          and raises(lambda: ct.OptionQuote(250.0, "C", bid=-1.0)) and raises(lambda: ct.OptionQuote(float("nan"), "C")))
    check("OptionChain: 정상 생성", ct.OptionChain(**ok_chain).T == 0.25)
    check("OptionChain: T<=0, F<=0, 빈 quotes, 비-datetime 거부",
          raises(lambda: ct.OptionChain(**{**ok_chain, "T": 0.0}))
          and raises(lambda: ct.OptionChain(**{**ok_chain, "forward": -1.0}))
          and raises(lambda: ct.OptionChain(**{**ok_chain, "quotes": ()}))
          and raises(lambda: ct.OptionChain(**{**ok_chain, "timestamp": "2026-01-01"})))
    t0 = datetime(2026, 1, 1)
    check("PriceSeries: 정상 생성", len(ct.PriceSeries("X", (t0, t0 + timedelta(days=1)), [1.0, 2.0]).close) == 2)
    check("PriceSeries: 길이 불일치/비유한/비양수/비오름차순 거부",
          raises(lambda: ct.PriceSeries("X", (t0,), [1.0, 2.0]))
          and raises(lambda: ct.PriceSeries("X", (t0,), [float("nan")]))
          and raises(lambda: ct.PriceSeries("X", (t0,), [0.0]))
          and raises(lambda: ct.PriceSeries("X", (t0, t0), [1.0, 2.0])))
    ms = ct.MarketState(timestamp=t0, expiry_T=0.25)
    check("MarketState: 점수·판정 필드는 기본 미설정(None), no_trade 미판정",
          ms.upside_score is None and ms.downside_score is None and ms.whipsaw_score is None
          and ms.no_trade is None and ms.state_name is None and ms.reasons == ())
    check("MarketState: 필드 이름에 'prob'(확률) 없음", not any("prob" in f.name.lower() for f in dataclasses.fields(ms)))
    check("StateName: 후보 6개", len(list(ct.StateName)) == 6)
    class _Fake:
        def get_option_chain(self, underlying, expiry):
            return ct.OptionChain(**ok_chain)
    check("OptionChainSource: 인터페이스 충족 여부 판별 가능", isinstance(_Fake(), ct.OptionChainSource)
          and not isinstance(object(), ct.OptionChainSource))
    pkg = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
    bad = []
    for fn in os.listdir(pkg):
        if fn.endswith(".py"):
            for line in open(os.path.join(pkg, fn), encoding="utf-8"):
                if re.match(r"\s*(import|from)\s+.*universal_quant_engine", line):
                    bad.append(fn)
    check("독립성: 패키지가 UME를 import 하지 않음", not bad)


def test_synthetic():
    print("-- synthetic --")
    K = np.array([200.0, 250.0, 300.0])
    check("풋콜 패러티: C - P = e^{-rT}(F-K)",
          np.max(np.abs(syn.bs_call(S, K, R, T, SIG) - syn.bs_put(S, K, R, T, SIG) - math.exp(-R * T) * (F - K))) < 1e-10)
    kk = np.linspace(20.0, 2000.0, 20001)
    q = syn.lognormal_pdf(S, kk, R, T, SIG)
    check("로그정규 밀도: 적분≈1, 평균≈F", abs(float(_trapz(q, kk)) - 1.0) < 1e-4 and abs(float(_trapz(kk * q, kk)) - F) < 0.05)
    c1, c2 = syn.make_option_chain(seed=3, noise_abs=0.01), syn.make_option_chain(seed=3, noise_abs=0.01)
    c3 = syn.make_option_chain(seed=4, noise_abs=0.01)
    check("make_option_chain: 같은 시드 재현, 다른 시드는 다름", c1.quotes == c2.quotes and c1.quotes != c3.quotes)
    check("make_option_chain: F = S·e^{rT}, 모든 호가 bid<=ask",
          abs(c1.forward - F) < 1e-9 and all(q.bid <= q.ask for q in syn.make_option_chain(half_spread=0.05, tick=0.01).quotes))
    p1, p2 = syn.make_price_series(seed=1), syn.make_price_series(seed=1)
    check("make_price_series: 길이·양수·재현", len(p1.close) == 250 and np.all(p1.close > 0) and np.array_equal(p1.close, p2.close))


def test_implied_vol():
    print("-- implied_vol --")
    ok_recover, ok_nan, n_rec, n_nan = True, True, 0, 0
    disc = math.exp(-R * T)
    for right in ("C", "P"):
        for K in (150.0, 220.0, 250.0, 280.0, 400.0):
            for s in (0.1, 0.25, 0.6):
                px = float(iv.black_price(F, K, T, R, s, right))
                intrinsic = disc * max(F - K, 0.0) if right == "C" else disc * max(K - F, 0.0)
                time_value = px - intrinsic
                got = iv.implied_vol(px, F, K, T, R, right)
                if time_value > 1e-6:            # 시간가치가 충분하면 sigma 를 복원해야 한다
                    n_rec += 1
                    ok_recover &= abs(got - s) < 1e-6
                elif time_value < 1e-9:          # 시간가치가 사실상 0(깊은 내가격)이면 IV 는 정의되지 않으므로 NaN
                    n_nan += 1
                    ok_nan &= math.isnan(got)
    check(f"IV 역산 왕복: 시간가치가 충분한 {n_rec}개 경우에서 sigma 복원(1e-6)", ok_recover and n_rec > 20)
    check(f"IV 역산: 시간가치가 사실상 0인 {n_nan}개 경우(깊은 내가격)는 NaN", ok_nan and n_nan >= 1)
    check("black_price(F 기준) 가 합성 bs_call(S 기준)과 일치(교차검증)",
          np.max(np.abs(iv.black_price(F, WIDE, T, R, SIG, "C") - syn.bs_call(S, WIDE, R, T, SIG))) < 1e-9)
    check("IV 역산: 무차익 경계 밖(내재가치 이하) 가격은 NaN", math.isnan(iv.implied_vol(1.0, F, 200.0, T, R, "C")))
    check("quote_mid: 정상/0매수/교차/누락 구분", iv.quote_mid(ct.OptionQuote(1.0, "C", 1.0, 1.2))[0] == 1.1
          and iv.quote_mid(ct.OptionQuote(1.0, "C", 0.0, 0.2))[1] == "zero_bid"
          and iv.quote_mid(ct.OptionQuote(1.0, "C", 2.0, 1.0))[1] == "crossed_quote"
          and iv.quote_mid(ct.OptionQuote(1.0, "C", 1.0, None))[1] == "missing_quote")

    chain = syn.make_option_chain(strikes=WIDE)
    cur = iv.otm_call_curve(chain)
    check("otm_call_curve(무잡음): 풋→콜 패러티 환산이 이론 콜 가격과 일치(1e-8)",
          np.max(np.abs(cur.call_prices - syn.bs_call(S, cur.strikes, R, T, SIG))) < 1e-8
          and cur.route == "price" and len(cur.strikes) == len(WIDE) and cur.flags == ())
    check("otm_call_curve: 호가 순서를 섞어도 결과 동일",
          (lambda sh: np.array_equal(iv.otm_call_curve(sh).call_prices, cur.call_prices))(
              dataclasses.replace(chain, quotes=tuple(random.Random(7).sample(list(chain.quotes), len(chain.quotes))))))
    ivc = iv.smoothed_call_curve_from_iv(chain)
    check("IV 경로(무잡음, 상수 sigma): 재환산 콜 가격이 이론가와 일치(1e-6)",
          ivc.route == "iv" and np.max(np.abs(ivc.call_prices - syn.bs_call(S, ivc.strikes, R, T, SIG))) < 1e-6)

    smile = lambda K_: 0.22 + 0.6 * np.log(K_ / S) ** 2
    sch = syn.make_option_chain(sigma=smile, strikes=np.linspace(0.6 * S, 1.6 * S, 101))
    sl = iv.otm_implied_vols(sch)
    check("otm_implied_vols(스마일): 역산 IV가 입력 스마일과 일치(1e-6)", np.max(np.abs(sl.ivs - smile(sl.strikes))) < 1e-6)
    sc = iv.smoothed_call_curve_from_iv(sch)
    check("IV 경로(스마일): 재환산 콜 가격이 이론가와 일치(1e-4)",
          np.max(np.abs(sc.call_prices - syn.bs_call(S, sc.strikes, R, T, smile(sc.strikes)))) < 1e-4)

    base = syn.make_option_chain(strikes=np.arange(200.0, 310.0, 10.0))
    qs = list(base.quotes)
    def put_at(k): return next(i for i, q in enumerate(qs) if q.strike == k and q.right == "P")
    def call_at(k): return next(i for i, q in enumerate(qs) if q.strike == k and q.right == "C")
    i = put_at(210.0); qs[i] = ct.OptionQuote(210.0, "P", 5.0, 3.0)
    i = put_at(220.0); qs[i] = ct.OptionQuote(220.0, "P", 0.0, 0.5)
    i = call_at(290.0); qs[i] = ct.OptionQuote(290.0, "C", 1.0, None)
    dup = ct.OptionQuote(250.0, "P", 99.0, 99.0)
    first_put_250 = qs[put_at(250.0)]
    flagged = dataclasses.replace(base, quotes=tuple(qs) + (dup,))
    fc = iv.otm_call_curve(flagged)
    txt = " ".join(fc.flags)
    check("품질 플래그: 교차/0매수/누락/중복 호가를 보고하고 해당 행사가는 제외",
          all(w in txt for w in ("crossed_quote@210P", "zero_bid@220P", "missing_quote@290C", "duplicate_quote@250P"))
          and 210.0 not in fc.strikes and 220.0 not in fc.strikes and 290.0 not in fc.strikes)
    exp_250 = 0.5 * (first_put_250.bid + first_put_250.ask) + math.exp(-R * T) * (F - 250.0)
    check("중복 호가: 첫 호가만 사용", abs(float(fc.call_prices[list(fc.strikes).index(250.0)]) - exp_250) < 1e-9)
    check("사용 가능 행사가가 최소 개수 미만이면 ValueError",
          raises(lambda: iv.otm_call_curve(dataclasses.replace(base, quotes=base.quotes[:3]))))


def test_bl_density():
    print("-- bl_density (v1.4 후보 코드, 연결 확인용 회귀) --")
    check("상태 문구가 '검증 대기'로 유지됨", "검증 대기" in VALIDATION_STATUS and "v1.4 후보" in VALIDATION_STATUS)
    chain = syn.make_option_chain(strikes=WIDE)
    q_true = syn.lognormal_pdf(S, WIDE, R, T, SIG)
    lo_t, hi_t = true_masses(WIDE, q_true, F)
    cur = iv.otm_call_curve(chain)
    res = bl_density(cur.strikes, cur.call_prices, forward=chain.forward, T=chain.T, r=chain.rate)
    check("price 경로 → BL(무잡음): 정규화 TV ≤ 0.005", norm_tv(res.strikes, res.density, q_true) <= 0.005)
    check("price 경로: F 기준 하방/상방 질량 오차 ≤ 0.005",
          abs(res.downside_mass - lo_t) <= 0.005 and abs(res.upside_mass - hi_t) <= 0.005)
    check("price 경로: 음수 밀도 없음, 볼록·단조 위반 없음",
          res.neg_density_ratio == 0.0 and res.convexity_violations == 0 and res.monotonic_violations == 0)
    ivc = iv.smoothed_call_curve_from_iv(chain)
    res_iv = bl_density(ivc.strikes, ivc.call_prices, forward=chain.forward, T=chain.T, r=chain.rate)
    q_iv = syn.lognormal_pdf(S, res_iv.strikes, R, T, SIG)
    check("iv 경로 → BL(무잡음): 정규화 TV ≤ 0.005", norm_tv(res_iv.strikes, res_iv.density, q_iv) <= 0.005)

    perm = np.random.default_rng(5).permutation(len(cur.strikes))
    res_p = bl_density(cur.strikes[perm], cur.call_prices[perm], forward=chain.forward, T=chain.T, r=chain.rate)
    check("BL: 입력 순서를 섞어도 밀도 동일(K·C 정렬 일관성)", np.array_equal(res_p.density, res.density))
    k, c = cur.strikes, cur.call_prices
    check("BL 입력 검증: 행사가 중복 / 5점 미만 / T<=0 / NaN 거부",
          raises(lambda: bl_density(np.r_[k, k[0]], np.r_[c, c[0]], F, T, R))
          and raises(lambda: bl_density(k[:4], c[:4], F, T, R))
          and raises(lambda: bl_density(k, c, F, 0.0, R))
          and raises(lambda: bl_density(k, np.r_[np.nan, c[1:]], F, T, R)))

    noisy = syn.make_option_chain(noise_abs=0.01, noise_rel=0.001, tick=0.01, half_spread=0.01, seed=11)
    nc = iv.otm_call_curve(noisy)
    r1 = bl_density(nc.strikes, nc.call_prices, forward=noisy.forward, T=noisy.T, r=noisy.rate,
                    smoothing_s=len(nc.strikes) * 0.02**2)
    ni = iv.smoothed_call_curve_from_iv(noisy, smoothing_s=None)
    r2 = bl_density(ni.strikes, ni.call_prices, forward=noisy.forward, T=noisy.T, r=noisy.rate)
    check("잡음·틱·스프레드 체인: 두 경로 모두 예외 없이 유한한 밀도 산출 (정확도 주장 아님)",
          np.all(np.isfinite(r1.density)) and np.all(np.isfinite(r2.density)))


def run():
    test_contracts(); test_synthetic(); test_implied_vol(); test_bl_density()
    print("\n" + "=" * 50)
    print(f"{sum(results)}/{len(results)} 통과")
    return 0 if all(results) else 1


if __name__ == "__main__":
    raise SystemExit(run())
