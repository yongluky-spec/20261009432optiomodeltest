"""volatility_model.contracts — 데이터 계약 (수집 모듈과의 접점).

- OptionChain / PriceSeries : 수집 모듈(LS, UME 등)이 채워서 넘기는 입력 계약
- MarketState               : 이 모델이 의사결정/게이트 계층에 넘길 출력 계약 (이 단계에서는 정의만, 채우지 않음)
- OptionChainSource / PriceSeriesSource : 나중에 어댑터가 따를 인터페이스 (구현 없음)

구조적 검증(타입·범위)만 여기서 한다. 호가의 '품질'(교차호가, 0 매수호가 등)은 데이터일 수 있으므로
계약에서 거부하지 않고 implied_vol 에서 플래그로 보고한다.

UME 연결 메모(어댑터는 아직 없음): UME MarketBar(일봉) → PriceSeries(timestamps, close) 로 옮길 수 있다.
UME 에는 옵션체인 수집 기능이 없으므로 OptionChain 은 별도 어댑터(예: LS)가 필요하다.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Mapping, Optional, Protocol, Tuple, runtime_checkable

import numpy as np

CONTRACT_VERSION = "1"
RIGHTS = ("C", "P")


def _finite(x) -> bool:
    return x is not None and isinstance(x, (int, float)) and math.isfinite(x)


@dataclass(frozen=True)
class OptionQuote:
    strike: float
    right: str                     # "C"(콜) | "P"(풋)
    bid: Optional[float] = None
    ask: Optional[float] = None
    last: Optional[float] = None

    def __post_init__(self):
        if not (_finite(self.strike) and self.strike > 0):
            raise ValueError("strike는 양의 유한 값이어야 합니다.")
        if self.right not in RIGHTS:
            raise ValueError("right는 'C' 또는 'P' 이어야 합니다.")
        for name in ("bid", "ask", "last"):
            v = getattr(self, name)
            if v is not None and not (_finite(v) and v >= 0):
                raise ValueError(f"{name}는 0 이상의 유한 값이거나 None 이어야 합니다.")


@dataclass(frozen=True)
class OptionChain:
    """한 기초자산·한 만기의 옵션 스냅샷.

    T: 만기까지 남은 시간(년), forward: 선도(선물)가 F, rate: 무위험 이자율 r(연, 연속복리).
    """
    underlying: str
    timestamp: datetime
    T: float
    forward: float
    rate: float
    quotes: Tuple[OptionQuote, ...]
    source: str = "unknown"
    spot: Optional[float] = None

    def __post_init__(self):
        object.__setattr__(self, "quotes", tuple(self.quotes))
        if not isinstance(self.timestamp, datetime):
            raise ValueError("timestamp는 datetime 이어야 합니다.")
        if not (_finite(self.T) and self.T > 0):
            raise ValueError("T는 양의 유한 값이어야 합니다.")
        if not (_finite(self.forward) and self.forward > 0):
            raise ValueError("forward는 양의 유한 값이어야 합니다.")
        if not _finite(self.rate):
            raise ValueError("rate는 유한 값이어야 합니다.")
        if self.spot is not None and not (_finite(self.spot) and self.spot > 0):
            raise ValueError("spot은 양의 유한 값이거나 None 이어야 합니다.")
        if len(self.quotes) == 0:
            raise ValueError("quotes가 비어 있습니다.")
        if not all(isinstance(q, OptionQuote) for q in self.quotes):
            raise ValueError("quotes의 모든 원소는 OptionQuote 여야 합니다.")


@dataclass(frozen=True, eq=False)
class PriceSeries:
    """기초자산 가격 시계열 (일봉·분봉 공통). 시각은 오름차순."""
    symbol: str
    timestamps: Tuple[datetime, ...]
    close: np.ndarray
    freq: str = "1d"
    source: str = "unknown"

    def __post_init__(self):
        ts = tuple(self.timestamps)
        c = np.asarray(self.close, dtype=float)
        object.__setattr__(self, "timestamps", ts)
        object.__setattr__(self, "close", c)
        if c.ndim != 1 or len(ts) != len(c):
            raise ValueError("timestamps와 close는 같은 길이의 1차원이어야 합니다.")
        if len(ts) == 0:
            raise ValueError("시계열이 비어 있습니다.")
        if not np.all(np.isfinite(c)) or np.any(c <= 0):
            raise ValueError("close는 양의 유한 값이어야 합니다.")
        if not all(isinstance(t, datetime) for t in ts):
            raise ValueError("timestamps의 모든 원소는 datetime 이어야 합니다.")
        if any(b <= a for a, b in zip(ts, ts[1:])):
            raise ValueError("timestamps는 엄격한 오름차순이어야 합니다.")


class StateName(str, Enum):
    """시장 상태 후보 (분류 로직은 아직 없음)."""
    NORMAL = "NORMAL"
    VOL_EXPANSION = "VOL_EXPANSION"
    VOL_CRUSH = "VOL_CRUSH"
    CALL_PUT_PREMIUM_EXPANSION = "CALL_PUT_PREMIUM_EXPANSION"
    VOL_PRICE_DIVERGENCE = "VOL_PRICE_DIVERGENCE"
    TRAP_CANDIDATE = "TRAP_CANDIDATE"


@dataclass(frozen=True)
class MarketState:
    """변동성 모델의 출력 계약. 이 단계에서는 정의만 있고 어떤 모듈도 채우지 않는다.

    - *_mass : 선도 F 기준 위험중립 질량 (실제 발생확률이 아님)
    - *_score: 보정 전 점수. 확률이 아니다 (과거 데이터 calibration 이후에만 '확률'로 부른다).
    - no_trade / reasons: gate 계층이 채운다. 변동성 모듈은 설정하지 않는다 (None = 미판정).
    """
    timestamp: datetime
    expiry_T: float
    state_name: Optional[StateName] = None
    downside_mass: Optional[float] = None
    upside_mass: Optional[float] = None
    upside_score: Optional[float] = None
    downside_score: Optional[float] = None
    whipsaw_score: Optional[float] = None
    no_trade: Optional[bool] = None
    reasons: Tuple[str, ...] = ()
    data_quality_flags: Tuple[str, ...] = ()
    module_versions: Mapping[str, str] = field(default_factory=dict)


@runtime_checkable
class OptionChainSource(Protocol):
    """옵션체인 수집 어댑터가 따를 인터페이스 (구현 없음). expiry 예: 'YYYY-MM-DD'."""
    def get_option_chain(self, underlying: str, expiry: str) -> OptionChain: ...


@runtime_checkable
class PriceSeriesSource(Protocol):
    """가격 시계열 수집 어댑터가 따를 인터페이스 (구현 없음). start/end 예: 'YYYY-MM-DD'."""
    def get_price_series(self, symbol: str, start: str, end: str, freq: str = "1d") -> PriceSeries: ...
