"""volatility_model.synthetic — 합성 데이터 생성 (테스트용).

implied_vol / bl_density 와 독립적으로 구현했다 (검증 대상 코드를 재사용하면 검증이 순환하므로).
블랙-숄즈 기준: S(현물), r, T, sigma. 선도가 F = S * exp(r*T).

참 분포 lognormal_pdf 는 sigma 가 상수일 때만 성립한다 (스마일이 있으면 참 밀도가 로그정규가 아니다).
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Callable, Optional, Sequence, Union

import numpy as np
from scipy.stats import norm

from .contracts import OptionChain, OptionQuote, PriceSeries

_DEFAULT_TS = datetime(2026, 1, 1, 9, 0)
Sigma = Union[float, Callable[[np.ndarray], np.ndarray]]


def bs_call(S, K, r, T, sigma):
    K = np.asarray(K, dtype=float)
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    return S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d1 - sigma * np.sqrt(T))


def bs_put(S, K, r, T, sigma):
    K = np.asarray(K, dtype=float)
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    return K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)


def lognormal_pdf(S, K, r, T, sigma):
    """만기 위험중립 밀도 (sigma 상수). 할인 인자 없음."""
    K = np.asarray(K, dtype=float)
    sT = sigma * np.sqrt(T)
    x = (np.log(K / S) - (r - 0.5 * sigma**2) * T) / sT
    return np.exp(-0.5 * x**2) / (K * sT * np.sqrt(2 * np.pi))


def make_option_chain(S: float = 250.0, r: float = 0.03, T: float = 0.25, sigma: Sigma = 0.25,
                      strikes: Optional[Sequence[float]] = None,
                      noise_abs: float = 0.0, noise_rel: float = 0.0,
                      tick: Optional[float] = None, half_spread: float = 0.0,
                      seed: int = 0, timestamp: Optional[datetime] = None,
                      underlying: str = "SYN") -> OptionChain:
    """합성 옵션체인. 행사가마다 콜·풋 호가를 만든다.

    mid = 이론가 + noise_abs*u + 이론가*noise_rel*u (u~U(-1,1), 콜·풋 독립), 0 미만은 0으로 자른다.
    bid = mid - half_spread (0 하한), ask = mid + half_spread, tick 이 있으면 호가 단위로 반올림.
    sigma 는 상수 또는 행사가 배열 -> 변동성 함수(스마일).
    """
    K = (np.arange(0.7 * S, 1.3 * S + 0.005 * S, 0.01 * S) if strikes is None
         else np.asarray(strikes, dtype=float))
    sig = np.asarray(sigma(K), dtype=float) if callable(sigma) else np.full(K.shape, float(sigma))
    rng = np.random.default_rng(seed)
    quotes = []
    for right, theo in (("C", bs_call(S, K, r, T, sig)), ("P", bs_put(S, K, r, T, sig))):
        u = rng.uniform(-1.0, 1.0, size=K.shape)
        mid = np.clip(theo + noise_abs * u + theo * noise_rel * u, 0.0, None)
        bid = np.clip(mid - half_spread, 0.0, None)
        ask = mid + half_spread
        if tick:
            bid = np.round(bid / tick) * tick
            ask = np.round(ask / tick) * tick
        quotes.extend(OptionQuote(float(k), right, float(b), float(a)) for k, b, a in zip(K, bid, ask))
    return OptionChain(underlying=underlying, timestamp=timestamp or _DEFAULT_TS, T=T,
                       forward=float(S * np.exp(r * T)), rate=r, quotes=tuple(quotes),
                       source="synthetic", spot=S)


def make_price_series(S0: float = 250.0, mu: float = 0.0, sigma: float = 0.25, n: int = 250,
                      dt: float = 1.0 / 252.0, seed: int = 0, symbol: str = "SYN", freq: str = "1d",
                      step: timedelta = timedelta(days=1),
                      start: Optional[datetime] = None) -> PriceSeries:
    """기하 브라운 운동 가격 경로."""
    rng = np.random.default_rng(seed)
    z = rng.standard_normal(n - 1)
    logret = (mu - 0.5 * sigma**2) * dt + sigma * np.sqrt(dt) * z
    close = S0 * np.exp(np.concatenate([[0.0], np.cumsum(logret)]))
    t0 = start or _DEFAULT_TS
    return PriceSeries(symbol=symbol, timestamps=tuple(t0 + i * step for i in range(n)),
                       close=close, freq=freq, source="synthetic")
