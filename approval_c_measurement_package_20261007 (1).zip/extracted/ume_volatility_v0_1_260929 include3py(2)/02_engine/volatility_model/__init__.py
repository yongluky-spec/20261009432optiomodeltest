"""volatility_model — 독립 변동성 모델 패키지 (M1, 구현 진행 중).

상태 (2026-09-29):
  - M1(구조·합성 검증) 범위의 앞 4개 모듈만 구현: contracts, synthetic, implied_vol, bl_density
  - bl_density 는 '검증 완료'가 아니다 = BL v1.4 후보 코드, B단계 실행 검증 대기.
    (기존 B단계의 ①~④ 기준은 아직 확정되지 않았고, 이 패키지 개발이 그 검증을 대신하지 않는다.)
  - 아직 없음: whipsaw, scenario_score, gate, pipeline, 실데이터(LS/UME) 어댑터, 백테스트, calibration
  - '확률'이라는 이름은 M3(과거 데이터 calibration) 이전에는 사용하지 않는다 (점수 = score).
  - 거래 차단(no_trade) 판정은 이 패키지 안에서 하지 않는다 (이후 gate 계층의 몫).

독립성:
  - 이 패키지는 데이터 수집 모듈(UME 등)을 import 하지 않는다.
    수집 모듈과의 접점은 contracts 의 데이터 계약(OptionChain, PriceSeries)뿐이며, 어댑터는 나중에 붙인다.

의존성: numpy, scipy  (실제 환경 버전 확인 전이라 버전은 고정하지 않았다)
실행(테스트):  cd 02_engine && python -m volatility_model.tests.test_m1
"""
__version__ = "0.1.0-M1"
