"""LS증권 모의투자 계정(아이디/비밀번호) 로더 (v1.2).

- 모의투자 전용이다. 실전 계정용 이름(LS_ID, LS_PASSWORD 등)은 읽지 않는다 (Dev ≠ Production 인증정보, 규칙 3-4).
- 환경변수(Codespaces Secrets)에서만 읽는다 (SEC-204). 코드·파일에 적지 않는다.
- 아이디·비밀번호 값은 repr/print/로그/오류 메시지 어디에도 남기지 않는다 (SEC-205, SEC-301, SEC-303).
  '있음/없음'만 알려준다.

환경변수 이름:  LS_MOCK_ID,  LS_MOCK_PASSWORD

※ 값을 읽기만 한다. LS증권 로그인/서버 호출 자체는 포함하지 않는다.
"""
import os
from dataclasses import dataclass
from typing import Mapping, Optional

from ._common import ProviderError

ENV_NAMES = ("LS_MOCK_ID", "LS_MOCK_PASSWORD")


@dataclass(frozen=True, repr=False)
class LsMockAccount:
    """모의투자 아이디/비밀번호. repr·str·format 어디에도 값이 나오지 않는다."""
    user_id: str
    password: str

    def __repr__(self) -> str:
        return "LsMockAccount(user_id=***, password=***)"

    __str__ = __repr__

    def __format__(self, spec: str) -> str:
        return format(repr(self), spec)


def _read(env: Optional[Mapping[str, str]]):
    env = os.environ if env is None else env
    uid = (env.get(ENV_NAMES[0]) or "").strip() or None      # 아이디: 앞뒤 공백 제거
    pw = env.get(ENV_NAMES[1]) or None                       # 비밀번호: 그대로 사용 (공백도 비밀번호의 일부일 수 있음)
    missing = tuple(n for n, v in zip(ENV_NAMES, (uid, pw)) if not v)
    return uid, pw, missing


def load_ls_mock_account(env: Optional[Mapping[str, str]] = None) -> Optional[LsMockAccount]:
    """둘 다 설정되어 있으면 LsMockAccount, 아니면 None."""
    uid, pw, missing = _read(env)
    return None if missing else LsMockAccount(uid, pw)


def require_ls_mock_account(env: Optional[Mapping[str, str]] = None) -> LsMockAccount:
    """없으면 ProviderError(kind='config'). 메시지에는 변수 '이름'만 넣는다."""
    uid, pw, missing = _read(env)
    if missing:
        raise ProviderError(f"LS증권 모의투자 계정 없음 (환경변수 {', '.join(missing)} 설정 필요)", "config")
    return LsMockAccount(uid, pw)


def ls_mock_account_status(env: Optional[Mapping[str, str]] = None) -> dict:
    """설정 여부만 반환 (값 없음). 로그·화면 표시용."""
    _, _, missing = _read(env)
    return {"configured": not missing, "missing": list(missing)}
