"""LS증권 모의투자 계정 로더 테스트 — 네트워크·실제 계정 없이 가짜 값으로 검증한다.

실행:  cd 02_engine && python -m universal_quant_engine.tests.test_ls_mock_credentials
"""
import json
import logging
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))

from universal_quant_engine.collectors import ls_mock_credentials as lc  # noqa: E402
from universal_quant_engine.collectors._common import ProviderError  # noqa: E402

UID, PW = "fake_user_71bc", "Fake Pw 9f3a!"
FULL = {"LS_MOCK_ID": UID, "LS_MOCK_PASSWORD": PW}
results = []


def check(name, cond):
    results.append(bool(cond))
    print(f"{'PASS' if cond else 'FAIL'} - {name}")


def run():
    a = lc.load_ls_mock_account(FULL)
    check("환경변수 한 쌍이 있으면 로드", a is not None and a.user_id == UID and a.password == PW)
    check("없으면 None", lc.load_ls_mock_account({}) is None)
    check("한쪽만 있으면 None", lc.load_ls_mock_account({"LS_MOCK_ID": UID}) is None)
    check("빈 값은 없음 취급", lc.load_ls_mock_account({"LS_MOCK_ID": UID, "LS_MOCK_PASSWORD": ""}) is None)
    check("아이디는 앞뒤 공백 제거", lc.load_ls_mock_account(
        {"LS_MOCK_ID": f"  {UID} ", "LS_MOCK_PASSWORD": PW}).user_id == UID)
    check("비밀번호는 공백 포함 그대로 보존", lc.load_ls_mock_account(
        {"LS_MOCK_ID": UID, "LS_MOCK_PASSWORD": " a b "}).password == " a b ")
    check("실전 이름(LS_ID/LS_PASSWORD)은 읽지 않음 (Dev≠Prod 분리)",
          lc.load_ls_mock_account({"LS_ID": UID, "LS_PASSWORD": PW}) is None)

    shown = " | ".join([repr(a), str(a), f"{a}", f"{a!s:>60}", "%s" % (a,), "%r" % (a,)])
    check("repr/str/format/% 어디에도 아이디·비밀번호가 없음", UID not in shown and PW not in shown)
    st = lc.ls_mock_account_status(FULL)
    check("status에 값 없음", UID not in json.dumps(st) and PW not in json.dumps(st)
          and st == {"configured": True, "missing": []})
    check("status: 누락된 변수 '이름'만 알려줌",
          lc.ls_mock_account_status({"LS_MOCK_ID": UID}) == {"configured": False, "missing": ["LS_MOCK_PASSWORD"]})

    try:
        lc.require_ls_mock_account({"LS_MOCK_ID": UID})
        err = None
    except ProviderError as e:
        err = e
    check("require: 없으면 ProviderError(kind=config), 메시지에 값 없음",
          err is not None and err.kind == "config" and UID not in str(err) and "LS_MOCK_PASSWORD" in str(err))

    class Cap(logging.Handler):
        def __init__(self):
            super().__init__(); self.msgs = []
        def emit(self, rec):
            self.msgs.append(rec.getMessage())
    cap, root = Cap(), logging.getLogger()
    old = root.level; root.addHandler(cap); root.setLevel(logging.DEBUG)
    lc.load_ls_mock_account(FULL); lc.ls_mock_account_status(FULL)
    try:
        lc.require_ls_mock_account({})
    except ProviderError:
        pass
    root.removeHandler(cap); root.setLevel(old)
    check("사용 중 로그에 값이 남지 않음", not any(UID in m or PW in m for m in cap.msgs))

    print("\n" + "=" * 50)
    print(f"{sum(results)}/{len(results)} 통과")
    return 0 if all(results) else 1


if __name__ == "__main__":
    raise SystemExit(run())
