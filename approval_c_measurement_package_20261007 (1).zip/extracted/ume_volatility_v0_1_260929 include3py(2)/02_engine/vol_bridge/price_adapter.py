"""vol_bridge.price_adapter — UME 일봉 → volatility_model.PriceSeries.

UME 표준 DataFrame 컬럼: source, timestamp, open, high, low, close, volume, quality
정책(제안, 변경 가능):
  - quality == "missing", 종가 NaN/비양수, 시각 NaT 인 행은 제외하고 개수를 플래그로 남긴다.
  - quality "delayed"/"manual" 은 포함하되 개수를 플래그로 표시한다.
  - 같은 시각이 중복이면 마지막 행만 남긴다(플래그). 시각 오름차순으로 정렬한다.
한계:
  - UME market() 은 날짜 범위가 아니라 개수(count)로 받는다. start/end 는 받은 데이터를 자르는 방식이며,
    받은 데이터가 start 보다 늦게 시작하면 data_starts_after_requested_start 플래그를 남긴다.
  - 실제 사이트(KRX/네이버/야후) 수집은 이 패키지에서 검증하지 않았다 (Mock 으로만 확인).
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd

from volatility_model.contracts import PriceSeries


def frame_to_price_series(df: pd.DataFrame, symbol: str, freq: str = "1d") -> Tuple[PriceSeries, Tuple[str, ...]]:
    """UME 표준 DataFrame → (PriceSeries, 플래그). 입력 df 는 수정하지 않는다."""
    if df is None or len(df) == 0:
        raise ValueError("빈 데이터입니다.")
    absent = [c for c in ("timestamp", "close") if c not in df.columns]
    if absent:
        raise ValueError(f"필수 컬럼 없음: {absent}")

    work = pd.DataFrame({
        "timestamp": pd.to_datetime(df["timestamp"], errors="coerce"),
        "close": pd.to_numeric(df["close"], errors="coerce"),
        "quality": df["quality"].astype(str) if "quality" in df.columns else "normal",
        "source": df["source"].astype(str) if "source" in df.columns else "unknown",
    })
    flags = []

    n = int((work["quality"] == "missing").sum())
    if n:
        flags.append(f"quality_missing_excluded:{n}")
        work = work[work["quality"] != "missing"]
    bad_ts = work["timestamp"].isna()
    if bad_ts.any():
        flags.append(f"invalid_timestamp_excluded:{int(bad_ts.sum())}")
        work = work[~bad_ts]
    bad_close = ~np.isfinite(work["close"].to_numpy(float)) | (work["close"].to_numpy(float) <= 0)
    if bad_close.any():
        flags.append(f"invalid_close_excluded:{int(bad_close.sum())}")
        work = work[~bad_close]
    dup = work["timestamp"].duplicated(keep="last")
    if dup.any():
        flags.append(f"duplicate_timestamp_dropped:{int(dup.sum())}")
        work = work[~dup]
    work = work.sort_values("timestamp")
    if len(work) == 0:
        raise ValueError(f"유효한 행이 없습니다. flags={flags}")

    for q in ("delayed", "manual"):
        n = int((work["quality"] == q).sum())
        if n:
            flags.append(f"quality_{q}_included:{n}")
    sources = sorted(work["source"].unique())
    if len(sources) > 1:
        flags.append(f"multiple_sources:{','.join(sources)}")

    series = PriceSeries(symbol=symbol,
                         timestamps=tuple(t.to_pydatetime() for t in work["timestamp"]),
                         close=work["close"].to_numpy(dtype=float),
                         freq=freq, source=",".join(sources))
    return series, tuple(flags)


def _parse_date(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%d")


class UmePriceSeriesSource:
    """volatility_model.contracts.PriceSeriesSource 구현. UME Market(또는 같은 메서드를 가진 객체)을 감싼다.

    market 객체에는 다음이 필요하다: market(symbol, timeframe, count) -> DataFrame,
    reliability_report(symbol) -> ReliabilityReport (선택).
    호출 후 결과는 속성으로 남는다:
      last_flags        : 변환 중 발견한 품질 플래그
      last_reliability  : UME 신뢰도 값 그대로 (모델 입력이 아니라 별도 경로)
    """

    def __init__(self, market: Any, count: int = 250):
        if count < 1:
            raise ValueError("count는 1 이상이어야 합니다.")
        self._market = market
        self._count = count
        self.last_flags: Tuple[str, ...] = ()
        self.last_reliability: Optional[Dict[str, Any]] = None

    def get_price_series(self, symbol: str, start: Optional[str] = None, end: Optional[str] = None,
                         freq: str = "1d") -> PriceSeries:
        df = self._market.market(symbol, freq, self._count)
        flags = []
        self.last_reliability = self._collect_reliability(symbol, flags)

        ts = pd.to_datetime(df["timestamp"], errors="coerce") if len(df) and "timestamp" in df.columns else None
        if start is not None or end is not None:
            if ts is None:
                raise ValueError("timestamp 컬럼이 없어 기간을 자를 수 없습니다.")
            mask = pd.Series(True, index=df.index)
            if start is not None:
                start_dt = _parse_date(start)
                mask &= ts >= start_dt
                earliest = ts.min()
                if pd.notna(earliest) and earliest > start_dt:
                    flags.append(f"data_starts_after_requested_start:{earliest.date()}")
            if end is not None:
                mask &= ts < _parse_date(end) + timedelta(days=1)   # end 날짜 포함
            df = df[mask]

        series, conv_flags = frame_to_price_series(df, symbol, freq)
        self.last_flags = tuple(flags) + conv_flags
        return series

    def _collect_reliability(self, symbol: str, flags: list) -> Optional[Dict[str, Any]]:
        getter = getattr(self._market, "reliability_report", None)
        if getter is None:
            flags.append("reliability_unavailable")
            return None
        try:
            rep = getter(symbol)
            return {"components": dict(rep.to_dict()),
                    "overall_score": rep.checks.get("overall_score"),
                    "collection": dict(getattr(self._market, "last_report", {}) or {})}
        except Exception as e:  # 신뢰도 계산 실패가 가격 변환을 막지 않는다
            flags.append(f"reliability_unavailable:{type(e).__name__}")
            return None
