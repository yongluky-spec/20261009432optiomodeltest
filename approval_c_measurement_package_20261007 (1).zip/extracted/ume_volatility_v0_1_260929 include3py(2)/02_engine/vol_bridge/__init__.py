"""vol_bridge — 데이터 수집 모듈(UME)과 변동성 모델(volatility_model)의 연결부.

- UME 는 일봉 OHLCV 만 수집한다. 옵션체인은 없다 → 옵션 쪽(OptionChain)은 이 패키지에 없다.
  (LS 옵션체인 어댑터는 로그인 방식·옵션 데이터 제공 여부 확인 후 별도로 만든다.)
- 이 패키지는 volatility_model 만 import 한다. UME 는 import 하지 않고(duck typing) 받은 객체의
  market()/reliability_report() 를 호출할 뿐이다. UME 도 volatility_model 도 이 패키지를 모른다.
- UME 기존 파일은 수정하지 않는다.
- 데이터 신뢰도는 모델 입력에 섞지 않고 별도 경로로 값 그대로 전달한다 (임계값·플래그 생성 없음).

실행(테스트):  cd 02_engine && python -m vol_bridge.tests.test_bridge
"""
__version__ = "0.1.0"
