# 승인 C 실측 준비 패키지 — 2026-10-07

## 목적
이 패키지는 승인 C 최종 판정 및 보안 게이트의 실제 실측을 준비하기 위한 자료 묶음이다.

## 중요 원칙
- 승인 C 최종 판정은 실제 `bl_density.py` 구현체와 실제 실험환경에서 나온 결과만 근거로 한다.
- 임의 수치 생성, 추정, 모의 결과를 실제 실측 결과로 사용하지 않는다.
- 현재 패키지에 없는 원본(예: 사용자 Codespaces의 실제 `bl_density.py`, 1,200 조건 실험 원본, 실제 v0.4 캔버스 파일)은 없는 상태로 표시한다.
- 이 패키지 자체가 600/600 홀드아웃 결과를 생성했다는 의미가 아니다.
- 파일 수정/통합은 별도 승인 범위를 따른다.

## 승인 C 실측 절차
1. 실제 `bl_density.py` 구현체 확보
2. 승인 C `bl_diagnostics.py v0.4`를 실험 환경에 배치
3. 기존 1,200 조건 실험 실행
4. seed 1~10 = adjustment, seed 11~20 = holdout
5. 600/600 confusion matrix 산출
6. adjustment/holdout 비교
7. worst_state 분포 확인
8. 다음 기준으로 검토
   - 양호 통과율 >= 70%
   - 불량 차단율 >= 95%
   - 누출률 <= 5%
9. D1 강등에 따른 worst_state 변화 확인
10. 기준 충족 시 최종 Approval C 판정 검토

## 현재 패키지의 한계
이 폴더에 없는 사용자 측 원본은 임의로 생성하지 않는다.
특히 실제 Codespaces에만 존재하는 구현체/실험환경은 이 패키지에 자동으로 포함될 수 없다.

## 결과 제출 형식
실측 후 다음 정보를 그대로 붙여넣는다.

- adjustment 600:
  - good -> usable
  - good -> rejected
  - bad -> usable
  - bad -> rejected
  - worst_state distribution
- holdout 600:
  - good -> usable
  - good -> rejected
  - bad -> usable
  - bad -> rejected
  - worst_state distribution
- adjustment vs holdout 비교
- 양호 통과율
- 불량 차단율
- 누출률
- 과적합 비교 결과
