# -*- coding: utf-8 -*-
"""
BL 품질진단 계층 — 승인 C 초안 v0.2 (스키마 대조 반영)

대조 기준 (실제 bl_density.py, 2026-10-05 대조):
  - bl_density(strikes, call_prices, forward, T, r=0.0, smoothing_s=None,
               warn_T=None, stop_T=None) -> BLResult (112행 return BLResult(k, q, ...))
  - BLResult 필드: strikes, density, integral, integral_clipped,
                   neg_density_ratio, monotonic_violations, convexity_violations,
                   downside_mass, upside_mass, clipped_negative, status, warnings
  - forward는 상·하방 질량 분할 기준점일 뿐 밀도 계산에 쓰이지 않음 (100~110행)
  - smoothing_s=None → CubicSpline(보간), 값 있으면 UnivariateSpline(평활) (80~84행)
  - F가 격자 밖이면 "forward outside grid" 경고 + 마스크 적분

위치 규칙 (v0.1과 동일):
  - bl_density.py를 수정하지 않는다. BLResult를 "읽기 전용 입력"으로 받는다.
  - 진단은 metric + state만 반환. 판단·차단은 Gate 소유.
  - 측정 불가는 None. 0/1.0 대체 금지.
  - 모든 임계값 PROVISIONAL (Calibration 전 확정 금지).
  - "확률" 명명 금지 — mass/score.
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Any
import numpy as np


class QualityState(Enum):
    OK = "OK"
    WARN = "WARN"
    DEGRADED = "DEGRADED"
    UNUSABLE = "UNUSABLE"


# 임계값 — 전부 PROVISIONAL
THRESHOLDS: dict = {
    "neg_density_ratio_warn": 0.02,
    "neg_density_ratio_degraded": 0.05,
    "neg_density_ratio_unusable": 0.10,
    "neg_density_integral_warn": 0.01,
    "mass_sum_high": 1.05,
    "mass_sum_high_degraded": 1.10,
    "mass_sum_low": 0.95,
    "mass_sum_low_degraded": 0.90,
    "tail_coverage_min": 0.98,
    "k_grid_min": 8,
    "k_spacing_ratio_warn": 2.5,
    "repair_gap_warn": 0.02,
    "mass_score_sum_warn": 0.02,   # down+up 질량 합이 integral_clipped와 어긋나는 경계
}


@dataclass
class DiagnosticItem:
    code: str
    name: str
    value: Optional[float]
    state: Optional[QualityState]
    note: str = ""


@dataclass
class DensityDiagnostics:
    as_of: str = ""
    items: list = field(default_factory=list)
    source: str = ""                      # "price" | "iv"
    smoothing_s: Optional[float] = None    # BLResult에 없으므로 호출자가 전달
    forward: Optional[float] = None       # BLResult에 없으므로 호출자가 전달

    _ORDER = {QualityState.OK: 0, QualityState.WARN: 1,
              QualityState.DEGRADED: 2, QualityState.UNUSABLE: 3}

    @property
    def worst_state(self) -> QualityState:
        measured = [it for it in self.items if it.state is not None]
        if not measured:
            return QualityState.UNUSABLE
        return max(measured, key=lambda it: self._ORDER[it.state]).state

    @property
    def is_usable(self) -> bool:
        return self.worst_state in (QualityState.OK, QualityState.WARN)

    def item(self, code: str) -> Optional[DiagnosticItem]:
        for it in self.items:
            if it.code == code:
                return it
        return None

    def to_dict(self) -> dict:
        return {
            "as_of": self.as_of,
            "source": self.source,
            "smoothing_s": self.smoothing_s,
            "forward": self.forward,
            "worst_state": self.worst_state.value,
            "usable": self.is_usable,
            "provisional_thresholds": True,
            "items": [
                {"code": it.code, "name": it.name, "value": it.value,
                 "state": it.state.value if it.state is not None else None,
                 "note": it.note}
                for it in self.items
            ],
        }


def _state_from(value: Optional[float], warn: float, degraded: float,
                unusable: float, higher_is_worse: bool = True) -> Optional[QualityState]:
    if value is None:
        return None
    if higher_is_worse:
        if value >= unusable:
            return QualityState.UNUSABLE
        if value >= degraded:
            return QualityState.DEGRADED
        if value >= warn:
            return QualityState.WARN
        return QualityState.OK
    if value <= unusable:
        return QualityState.UNUSABLE
    if value <= degraded:
        return QualityState.DEGRADED
    if value <= warn:
        return QualityState.WARN
    return QualityState.OK


def _f(obj: Any, name: str) -> Optional[float]:
    """BLResult 필드를 읽기 전용으로 꺼낸다. 없으면 None (추측 대체 금지)."""
    try:
        v = getattr(obj, name, None)
    except Exception:
        return None
    if v is None:
        return None
    try:
        return float(v)
    except Exception:
        return None


# ----------------------------------------------------------------------
# 주 진입점: BLResult 객체 진단 (읽기 전용)
# ----------------------------------------------------------------------
def diagnose_bl_result(result: Any,
                       forward: float,
                       source: str = "price",
                       smoothing_s: Optional[float] = None,
                       as_of: str = "") -> DensityDiagnostics:
    """실제 bl_density 출력(BLResult)을 그대로 받아 D0~D11 진단.

    BLResult에 forward·smoothing_s가 없으므로 호출자가 전달한다.
    이 함수는 result를 수정하지 않는다(읽기 전용).
    """
    diag = DensityDiagnostics(as_of=as_of, source=source,
                              smoothing_s=smoothing_s, forward=forward)

    K = np.asarray(getattr(result, "strikes", None) or [], dtype=float)
    q = np.asarray(getattr(result, "density", None) or [], dtype=float)
    n = len(K)
    result_status = str(getattr(result, "status", "") or "")
    result_warnings = list(getattr(result, "warnings", None) or [])

    # --- D0. BLResult 스키마 검사 ---
    required = ["strikes", "density", "integral", "neg_density_ratio"]
    missing = [f for f in required if getattr(result, f, None) is None]
    if missing or n < 2 or len(q) != n or not np.all(np.diff(K) > 0) or \
       not np.isfinite(forward):
        diag.items.append(DiagnosticItem(
            "D0", "BLResult 스키마", None, QualityState.UNUSABLE,
            f"필드 누락 {missing or '없음'} / 격자 부적합 — 진단 불가"))
        return diag

    # 기존 결과의 상태·경고는 판단 없이 기록으로 보존
    note0 = f"result.status={result_status}"
    if result_warnings:
        note0 += f" / result.warnings={result_warnings}"
    if "forward outside grid" in " ".join(map(str, result_warnings)):
        d0_state = QualityState.DEGRADED
        note0 += " — F가 격자 밖(마스크 적분 fallback)"
    else:
        d0_state = QualityState.OK
    diag.items.append(DiagnosticItem("D0", "BLResult 스키마", None, d0_state, note0))

    integral = _f(result, "integral")
    integral_clipped = _f(result, "integral_clipped")
    ndr = _f(result, "neg_density_ratio")
    down_m = _f(result, "downside_mass")
    up_m = _f(result, "upside_mass")

    # --- D1. 음수 밀도 비율 — BLResult가 이미 계산한 값 사용 ---
    diag.items.append(DiagnosticItem(
        "D1", "음수 밀도 비율", ndr,
        _state_from(ndr,
                    THRESHOLDS["neg_density_ratio_warn"],
                    THRESHOLDS["neg_density_ratio_degraded"],
                    THRESHOLDS["neg_density_ratio_unusable"]),
        "BLResult.neg_density_ratio — 무잡음 37/37이 놓친 결함 지점"))

    # --- D2. 음수 밀도 적분 비율 — 배열에서 재계산 ---
    neg_mask = q < 0
    neg_integral_ratio = abs(float(np.trapz(np.where(neg_mask, q, 0.0), K))) \
        / max(abs(integral or 1.0), 1e-12)
    diag.items.append(DiagnosticItem(
        "D2", "음수 밀도 적분 비율", neg_integral_ratio,
        _state_from(neg_integral_ratio,
                    THRESHOLDS["neg_density_integral_warn"], 0.03, 0.05),
        "총질량 대비 음수 성분 크기 (진단 계층 재계산)"))

    # --- D3. 질량 합 — BLResult.integral ---
    if integral is not None:
        if integral > THRESHOLDS["mass_sum_high_degraded"] or \
           integral < THRESHOLDS["mass_sum_low_degraded"]:
            ms_state = QualityState.UNUSABLE
        elif integral > THRESHOLDS["mass_sum_high"] or \
             integral < THRESHOLDS["mass_sum_low"]:
            ms_state = QualityState.WARN
        else:
            ms_state = QualityState.OK
        diag.items.append(DiagnosticItem(
            "D3", "질량 합", integral, ms_state,
            "BLResult.integral — 1 초과/과소는 왜곡·경계위반 의심"))

    # --- D4. 꼬리 절단 ---
    if integral is not None and 0 < integral <= 1.0:
        tail_cut = 1.0 - integral
        diag.items.append(DiagnosticItem(
            "D4", "꼬리 절단(잔여 질량)", tail_cut,
            QualityState.WARN if tail_cut > (1 - THRESHOLDS["tail_coverage_min"])
            else QualityState.OK,
            "격자 밖 꼬리 질량 근사 — 측정 불가 아님, 표시 항목"))
    else:
        diag.items.append(DiagnosticItem("D4", "꼬리 절단(잔여 질량)", None, None,
                                         "총질량 비양수 또는 과잉 — 측정 불가(None)"))

    # --- D5. 격자 커버리지 (forward는 분할 기준점) ---
    k_min, k_max = float(K[0]), float(K[-1])
    in_range = k_min < forward < k_max
    if not in_range:
        d5_state, d5_val = QualityState.UNUSABLE, None
    elif n < THRESHOLDS["k_grid_min"]:
        d5_state = QualityState.DEGRADED
        d5_val = float((k_max - k_min) / max(forward, 1e-12))
    else:
        d5_state = QualityState.OK
        d5_val = float((k_max - k_min) / max(forward, 1e-12))
    diag.items.append(DiagnosticItem(
        "D5", "격자 커버리지", d5_val, d5_state,
        "F가 격자 밖이면 상·하방 질량 score 자체가 무의미"))

    # --- D6. 격자 간격 균등성 ---
    if n >= 3:
        dx = np.diff(K)
        spacing_ratio = float(np.percentile(dx, 90) / max(np.percentile(dx, 10), 1e-12))
        diag.items.append(DiagnosticItem(
            "D6", "격자 간격 비", spacing_ratio,
            _state_from(spacing_ratio, THRESHOLDS["k_spacing_ratio_warn"], 4.0, 8.0),
            "불균등 격자는 국소 2차 도함수 왜곡 증폭"))
    else:
        diag.items.append(DiagnosticItem("D6", "격자 간격 비", None, None,
                                         "격자 수 부족 — 측정 불가"))

    # --- D7. 비음수 재투영 질량 편차 — integral vs integral_clipped ---
    if integral is not None and integral_clipped is not None and integral != 0:
        repair_gap = abs(integral_clipped - integral) / max(abs(integral), 1e-12)
        diag.items.append(DiagnosticItem(
            "D7", "비음수 재투영 질량 편차", repair_gap,
            _state_from(repair_gap, THRESHOLDS["repair_gap_warn"], 0.05, 0.10),
            "BLResult.integral vs integral_clipped — 클수록 잡음 왜곡이 큼"))
    else:
        diag.items.append(DiagnosticItem("D7", "비음수 재투영 질량 편차", None, None,
                                         "integral/integral_clipped 부재 — 측정 불가"))

    # --- D8/D9. 상·하방 질량 score — BLResult가 계산한 값 사용 ---
    # (BLResult는 음수 자른 밀도를 CubicSpline으로 이어 F 기준 적분 — 100~110행 방식)
    for code, name, val in (("D8", "하방 질량 score", down_m),
                            ("D9", "상방 질량 score", up_m)):
        if val is None:
            diag.items.append(DiagnosticItem(code, name, None, None,
                                             "BLResult에 값 없음 — 측정 불가"))
            continue
        state = QualityState.OK if 0.0 <= val <= 1.0 else QualityState.DEGRADED
        diag.items.append(DiagnosticItem(
            code, name, val, state,
            "위험중립 질량 score — 실제 발생확률 아님 (calibration 전)"))

    # D8+D9 합 vs integral_clipped 상호 검증 (측정 가능할 때만)
    if down_m is not None and up_m is not None and integral_clipped is not None \
       and integral_clipped > 0:
        score_sum_gap = abs((down_m + up_m) - integral_clipped) / integral_clipped
        if score_sum_gap > THRESHOLDS["mass_score_sum_warn"]:
            for it in diag.items:
                if it.code in ("D8", "D9") and it.state is QualityState.OK:
                    it.state = QualityState.WARN
                    it.note += f" / 하+상 합이 integral_clipped와 {score_sum_gap:.3f} 어긋남"

    # --- D10. smoothing_s — BLResult에 없음, 호출자 전달값 기록 ---
    if smoothing_s is None:
        diag.items.append(DiagnosticItem(
            "D10", "smoothing_s", None, QualityState.WARN,
            "CubicSpline(보간) 경로로 추정 — BLResult에 미기록, PROVISIONAL"))
    else:
        diag.items.append(DiagnosticItem(
            "D10", "smoothing_s", float(smoothing_s), QualityState.WARN,
            "UnivariateSpline(평활) 경로 — 값 미검증, Calibration 대상"))

    # --- D11. 산출 경로 ---
    diag.items.append(DiagnosticItem(
        "D11", "산출 경로", None, QualityState.OK,
        f"source={source} — price 경로는 smoothing_s 지정 가능, "
        f"IV 경로는 smoothed_call_curve_from_iv라 smoothing_s=None 권장"))

    return diag


# ----------------------------------------------------------------------
# price/IV 이중 경로 비교 (compare_paths) — v0.1과 동일 원칙
# ----------------------------------------------------------------------
def compare_paths(diag_price: DensityDiagnostics,
                  diag_iv: DensityDiagnostics,
                  mass_diff_warn: float = 0.05) -> dict:
    mp = diag_price.item("D3").value if diag_price.item("D3") else None
    mi = diag_iv.item("D3").value if diag_iv.item("D3") else None
    if mp is None or mi is None:
        return {"comparable": False, "mass_diff": None,
                "note": "한쪽 경로 질량 측정 불가 — None (추측 대체 금지)"}
    diff = abs(mp - mi) / max(abs(mp), 1e-12)
    return {
        "comparable": True,
        "mass_diff": diff,
        "state_price": diag_price.worst_state.value,
        "state_iv": diag_iv.worst_state.value,
        "warn": diff > mass_diff_warn,   # PROVISIONAL
    }


def diagnose_noisy(result: Any, forward: float,
                   source: str = "price") -> DensityDiagnostics:
    """노이즈 회귀 테스트 진입점 (v0.2: BLResult 기반).

    승인 C 회귀 기준: 기존 구조가 OK를 내던 음수 밀도 28~43% 상황에서
    이 진단이 WARN/DEGRADED/UNUSABLE을 내면 통과.
    """
    return diagnose_bl_result(result, forward, source=source)