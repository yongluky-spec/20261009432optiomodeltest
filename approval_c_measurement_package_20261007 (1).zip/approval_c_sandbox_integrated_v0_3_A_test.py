# -*- coding: utf-8 -*-
"""
Approval C — BL 품질진단 샌드박스 통합 테스트 v0.3-A

목적:
  - 기존 bl_density.py 로직을 이 파일 안에 독립 보존
  - 승인 C v0.3(1단계) 진단 로직을 이 파일 안에 통합
  - 외부 프로젝트 파일 없이 단일 파일로 A 단계 샌드박스 재검증

주의:
  - 이것은 정식 bl_density.py / bl_diagnostics.py 교체본이 아니다.
  - 실제 프로젝트 파일은 수정하지 않는다.
  - 모든 진단 임계값은 PROVISIONAL이다.
  - 위험중립 mass는 실제 발생확률이 아니다.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Any
import math
import traceback
import numpy as np

try:
    from scipy.interpolate import CubicSpline, UnivariateSpline
    from scipy.stats import norm
except Exception as e:
    raise SystemExit("SciPy가 필요합니다. 설치: pip install numpy scipy") from e


# ============================================================
# 1. 기존 BL density 로직 — 원본 로직을 단일 파일에 보존
# ============================================================
_trapz = getattr(np, "trapezoid", None) or np.trapz
NEG_TOL_REL = 1e-6


@dataclass
class BLResult:
    strikes: np.ndarray
    density: np.ndarray
    integral: float
    integral_clipped: float
    neg_density_ratio: float
    monotonic_violations: int
    convexity_violations: int
    downside_mass: float
    upside_mass: float
    clipped_negative: bool
    status: str
    warnings: list = field(default_factory=list)


def _validate_inputs(strikes, call_prices, T, forward):
    k = np.asarray(strikes, dtype=float)
    c = np.asarray(call_prices, dtype=float)
    if k.ndim != 1 or c.ndim != 1 or k.shape != c.shape:
        raise ValueError("strikes/call_prices는 같은 길이의 1차원 배열이어야 합니다.")
    if len(k) < 5:
        raise ValueError("행사가 격자는 5점 이상이어야 합니다.")
    if not (np.all(np.isfinite(k)) and np.all(np.isfinite(c))):
        raise ValueError("NaN 또는 비유한 값이 있습니다.")
    if not np.isfinite(forward) or forward <= 0:
        raise ValueError("forward는 양의 유한 값이어야 합니다.")
    if T <= 0:
        raise ValueError("T는 양수여야 합니다.")


def _rel_tol_mask(values, tol_rel=NEG_TOL_REL):
    peak = np.max(np.abs(values)) if len(values) else 0.0
    thr = tol_rel * peak if peak > 0 else 0.0
    return values < -thr


def bl_density(strikes, call_prices, forward, T, r=0.0,
               smoothing_s=None, warn_T=None, stop_T=None) -> BLResult:
    _validate_inputs(strikes, call_prices, T, forward)
    order = np.argsort(strikes)
    k = np.asarray(strikes, dtype=float)[order]
    c = np.asarray(call_prices, dtype=float)[order]
    if np.any(np.diff(k) <= 0):
        raise ValueError("행사가 중복이 존재합니다.")
    if np.any(c < -1e-12):
        raise ValueError("콜 가격에 음수가 있습니다.")

    warnings, status = [], "OK"
    if stop_T is not None and T < stop_T:
        status = "STOP"; warnings.append("stop")
    elif warn_T is not None and T < warn_T:
        status = "WARN"; warnings.append("warn")

    if smoothing_s is None:
        spline = CubicSpline(k, c)
        d1 = spline(k, 1); d2 = spline(k, 2)
    else:
        spline = UnivariateSpline(k, c, s=smoothing_s, k=3)
        d1 = spline.derivative(1)(k); d2 = spline.derivative(2)(k)
    q = np.exp(r * T) * d2

    monotonic_violations = int(np.sum(_rel_tol_mask(-d1)))
    neg_mask = _rel_tol_mask(q)
    neg_ratio = float(np.mean(neg_mask))
    convexity_violations = int(np.sum(_rel_tol_mask(d2)))

    integral = float(_trapz(q, k))
    q_pos = np.clip(q, 0.0, None)
    clipped_negative = bool(np.any(q < 0))
    integral_clipped = float(_trapz(q_pos, k))
    if neg_ratio > 0:
        warnings.append(f"음수 밀도 비율 {neg_ratio:.4f}")

    if k[0] <= forward <= k[-1]:
        q_spline = CubicSpline(k, q_pos)
        grid_lo = np.concatenate([k[k < forward], [forward]])
        grid_hi = np.concatenate([[forward], k[k > forward]])
        downside_mass = float(_trapz(q_spline(grid_lo), grid_lo))
        upside_mass = float(_trapz(q_spline(grid_hi), grid_hi))
    else:
        warnings.append("forward outside grid")
        below = k <= forward
        downside_mass = float(_trapz(q_pos[below], k[below])) if below.any() else 0.0
        upside_mass = float(_trapz(q_pos[~below], k[~below])) if (~below).any() else 0.0

    return BLResult(k, q, integral, integral_clipped, neg_ratio,
                    monotonic_violations, convexity_violations,
                    downside_mass, upside_mass, clipped_negative, status, warnings)


# ============================================================
# 2. 합성 데이터 — 외부 synthetic.py 없이 독립 재현
# ============================================================
def bs_call(S, K, r, T, sigma):
    K = np.asarray(K, dtype=float)
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    return S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d1 - sigma * np.sqrt(T))


def lognormal_pdf(S, K, r, T, sigma):
    K = np.asarray(K, dtype=float)
    sT = sigma * np.sqrt(T)
    x = (np.log(K / S) - (r - 0.5 * sigma**2) * T) / sT
    return np.exp(-0.5 * x**2) / (K * sT * np.sqrt(2 * np.pi))


def make_noisy_calls(S, r, T, sigma, strikes, noise_abs=0.0,
                     noise_rel=0.0, tick=None, half_spread=0.0, seed=0):
    K = np.asarray(strikes, dtype=float)
    theo = bs_call(S, K, r, T, sigma)
    rng = np.random.default_rng(seed)
    u = rng.uniform(-1.0, 1.0, size=K.shape)
    mid = np.clip(theo + noise_abs * u + theo * noise_rel * u, 0.0, None)
    bid = np.clip(mid - half_spread, 0.0, None)
    ask = mid + half_spread
    if tick:
        bid = np.round(bid / tick) * tick
        ask = np.round(ask / tick) * tick
    return 0.5 * (bid + ask)


# ============================================================
# 3. Approval C v0.3 진단 — 1단계 수정판 통합
# ============================================================
class QualityState(Enum):
    OK = "OK"
    WARN = "WARN"
    DEGRADED = "DEGRADED"
    UNUSABLE = "UNUSABLE"


THRESHOLDS = {
    "neg_density_ratio_warn": 0.02,
    "neg_density_ratio_degraded": 0.05,
    "neg_density_ratio_unusable": 0.10,
    "neg_density_integral_warn": 0.01,
    "mass_sum_high": 1.05,
    "mass_sum_high_degraded": 1.10,
    "mass_sum_low": 0.95,
    "mass_sum_low_degraded": 0.90,
    "tail_coverage_min": 0.98,
    "k_grid_min": 8,
    "k_spacing_ratio_warn": 2.5,
    "repair_gap_warn": 0.02,
    "mass_score_sum_warn": 0.02,
}


@dataclass
class DiagnosticItem:
    code: str
    name: str
    value: Optional[float]
    state: Optional[QualityState]
    note: str = ""


@dataclass
class DensityDiagnostics:
    as_of: str = ""
    items: list = field(default_factory=list)
    source: str = ""
    smoothing_s: Optional[float] = None
    forward: Optional[float] = None

    _ORDER = {QualityState.OK: 0, QualityState.WARN: 1,
              QualityState.DEGRADED: 2, QualityState.UNUSABLE: 3}

    @property
    def worst_state(self):
        measured = [it for it in self.items if it.state is not None]
        if not measured:
            return QualityState.UNUSABLE
        return max(measured, key=lambda it: self._ORDER[it.state]).state

    @property
    def is_usable(self):
        return self.worst_state in (QualityState.OK, QualityState.WARN)

    def item(self, code):
        return next((it for it in self.items if it.code == code), None)

    def to_dict(self):
        return {
            "source": self.source,
            "smoothing_s": self.smoothing_s,
            "forward": self.forward,
            "worst_state": self.worst_state.value,
            "usable": self.is_usable,
            "provisional_thresholds": True,
            "items": [
                {"code": i.code, "name": i.name, "value": i.value,
                 "state": i.state.value if i.state else None, "note": i.note}
                for i in self.items
            ],
        }


def _state_from(value, warn, degraded, unusable, higher_is_worse=True):
    if value is None:
        return None
    if higher_is_worse:
        if value >= unusable: return QualityState.UNUSABLE
        if value >= degraded: return QualityState.DEGRADED
        if value >= warn: return QualityState.WARN
        return QualityState.OK
    if value <= unusable: return QualityState.UNUSABLE
    if value <= degraded: return QualityState.DEGRADED
    if value <= warn: return QualityState.WARN
    return QualityState.OK


def _f(obj, name):
    try:
        v = getattr(obj, name, None)
    except Exception:
        return None
    if v is None:
        return None
    try:
        return float(v)
    except Exception:
        return None


def _safe_array(obj, name):
    """v0.3 수정: numpy array에 대한 `or []` truth-value 평가를 하지 않는다."""
    v = getattr(obj, name, None)
    if v is None:
        return np.array([], dtype=float)
    return np.asarray(v, dtype=float)


def diagnose_bl_result(result, forward, source="price", smoothing_s=None, as_of=""):
    diag = DensityDiagnostics(as_of=as_of, source=source,
                              smoothing_s=smoothing_s, forward=forward)
    K = _safe_array(result, "strikes")
    q = _safe_array(result, "density")
    n = len(K)
    result_status = str(getattr(result, "status", "") or "")
    result_warnings = list(getattr(result, "warnings", None) or ())

    required = ["strikes", "density", "integral", "neg_density_ratio"]
    missing = [f for f in required if getattr(result, f, None) is None]
    if (missing or n < 2 or len(q) != n or not np.all(np.diff(K) > 0)
            or not np.isfinite(forward)):
        diag.items.append(DiagnosticItem(
            "D0", "BLResult 스키마", None, QualityState.UNUSABLE,
            f"필드 누락 {missing or '없음'} / 격자 부적합 — 진단 불가"))
        return diag

    note0 = f"result.status={result_status}"
    if result_warnings:
        note0 += f" / result.warnings={result_warnings}"
    d0_state = QualityState.DEGRADED if "forward outside grid" in " ".join(map(str, result_warnings)) else QualityState.OK
    diag.items.append(DiagnosticItem("D0", "BLResult 스키마", None, d0_state, note0))

    integral = _f(result, "integral")
    integral_clipped = _f(result, "integral_clipped")
    ndr = _f(result, "neg_density_ratio")
    down_m = _f(result, "downside_mass")
    up_m = _f(result, "upside_mass")

    diag.items.append(DiagnosticItem(
        "D1", "음수 밀도 비율", ndr,
        _state_from(ndr, THRESHOLDS["neg_density_ratio_warn"],
                    THRESHOLDS["neg_density_ratio_degraded"],
                    THRESHOLDS["neg_density_ratio_unusable"]),
        "BLResult.neg_density_ratio"))

    if integral is None or integral == 0:
        neg_integral_ratio = None
    else:
        neg_mask = q < 0
        neg_integral = abs(float(_trapz(np.where(neg_mask, q, 0.0), K)))
        neg_integral_ratio = neg_integral / max(abs(integral), 1e-12) if neg_integral > 0 else 0.0
    diag.items.append(DiagnosticItem(
        "D2", "음수 밀도 적분 비율", neg_integral_ratio,
        _state_from(neg_integral_ratio, THRESHOLDS["neg_density_integral_warn"], 0.03, 0.05),
        "총질량 부재/0이면 None"))

    if integral is not None:
        if integral > THRESHOLDS["mass_sum_high_degraded"] or integral < THRESHOLDS["mass_sum_low_degraded"]:
            ms_state = QualityState.UNUSABLE
        elif integral > THRESHOLDS["mass_sum_high"] or integral < THRESHOLDS["mass_sum_low"]:
            ms_state = QualityState.WARN
        else:
            ms_state = QualityState.OK
        diag.items.append(DiagnosticItem("D3", "질량 합", integral, ms_state,
                                         "BLResult.integral"))

    if integral is not None and 0 < integral <= 1.0:
        tail_cut = 1.0 - integral
        diag.items.append(DiagnosticItem(
            "D4", "꼬리 절단(잔여 질량)", tail_cut,
            QualityState.WARN if tail_cut > (1 - THRESHOLDS["tail_coverage_min"]) else QualityState.OK,
            "격자 밖 꼬리 질량 근사"))
    else:
        diag.items.append(DiagnosticItem("D4", "꼬리 절단(잔여 질량)", None, None,
                                         "총질량 비양수 또는 과잉 — 측정 불가(None)"))

    k_min, k_max = float(K[0]), float(K[-1])
    in_range = k_min < forward < k_max
    if not in_range:
        d5_state, d5_val = QualityState.UNUSABLE, None
    elif n < THRESHOLDS["k_grid_min"]:
        d5_state = QualityState.DEGRADED
        d5_val = float((k_max - k_min) / max(forward, 1e-12))
    else:
        d5_state = QualityState.OK
        d5_val = float((k_max - k_min) / max(forward, 1e-12))
    diag.items.append(DiagnosticItem("D5", "격자 커버리지", d5_val, d5_state,
                                     "F가 격자 밖이면 상·하방 질량 score 자체가 무의미"))

    if n >= 3:
        dx = np.diff(K)
        spacing_ratio = float(np.percentile(dx, 90) / max(np.percentile(dx, 10), 1e-12))
        diag.items.append(DiagnosticItem(
            "D6", "격자 간격 비", spacing_ratio,
            _state_from(spacing_ratio, THRESHOLDS["k_spacing_ratio_warn"], 4.0, 8.0),
            "불균등 격자는 국소 2차 도함수 왜곡 증폭"))
    else:
        diag.items.append(DiagnosticItem("D6", "격자 간격 비", None, None, "격자 수 부족 — 측정 불가"))

    if integral is not None and integral_clipped is not None and integral != 0:
        repair_gap = abs(integral_clipped - integral) / max(abs(integral), 1e-12)
        diag.items.append(DiagnosticItem(
            "D7", "비음수 재투영 질량 편차", repair_gap,
            _state_from(repair_gap, THRESHOLDS["repair_gap_warn"], 0.05, 0.10),
            "integral vs integral_clipped"))
    else:
        diag.items.append(DiagnosticItem("D7", "비음수 재투영 질량 편차", None, None,
                                         "측정 불가"))

    for code, name, val in (("D8", "하방 질량 score", down_m), ("D9", "상방 질량 score", up_m)):
        if val is None:
            diag.items.append(DiagnosticItem(code, name, None, None, "측정 불가"))
        else:
            state = QualityState.OK if 0.0 <= val <= 1.0 else QualityState.DEGRADED
            diag.items.append(DiagnosticItem(code, name, val, state,
                                             "위험중립 질량 score — 실제 발생확률 아님"))

    if down_m is not None and up_m is not None and integral_clipped is not None and integral_clipped > 0:
        score_sum_gap = abs((down_m + up_m) - integral_clipped) / integral_clipped
        if score_sum_gap > THRESHOLDS["mass_score_sum_warn"]:
            for it in diag.items:
                if it.code in ("D8", "D9") and it.state is QualityState.OK:
                    it.state = QualityState.WARN
                    it.note += f" / 하+상 합과 {score_sum_gap:.3f} 차이"

    if smoothing_s is None:
        diag.items.append(DiagnosticItem("D10", "smoothing_s", None, QualityState.WARN,
                                         "CubicSpline 경로 — BLResult에 미기록, PROVISIONAL"))
    else:
        diag.items.append(DiagnosticItem("D10", "smoothing_s", float(smoothing_s), QualityState.WARN,
                                         "UnivariateSpline 경로 — 값 미검증, Calibration 대상"))

    diag.items.append(DiagnosticItem("D11", "산출 경로", None, QualityState.OK,
                                     f"source={source}"))
    return diag


def diagnose_noisy(result, forward, source="price"):
    return diagnose_bl_result(result, forward, source=source)


# ============================================================
# 4. A 단계 재검증
# ============================================================
results = []


def check(name, condition, detail=""):
    ok = bool(condition)
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'} - {name}" + (f" | {detail}" if detail else ""))
    return ok


def run():
    print("=" * 72)
    print("Approval C v0.3 — A 단계 샌드박스 통합 재검증")
    print("실제 프로젝트 파일 수정 없음 / 임계값은 PROVISIONAL")
    print("=" * 72)

    S, R, T, SIG = 250.0, 0.03, 0.25, 0.25
    F = S * math.exp(R * T)
    K = np.linspace(0.5 * S, 2.0 * S, 161)

    # A-1. v0.3의 핵심 crash 수정: ndarray truth-value
    base = bl_density(K, bs_call(S, K, R, T, SIG), F, T, R)
    try:
        d = diagnose_bl_result(base, F, source="price")
        check("A1: NumPy ndarray truth-value crash 없음", d.item("D0") is not None)
    except Exception as e:
        check("A1: NumPy ndarray truth-value crash 없음", False, repr(e))

    # A-2. NumPy 2.x 호환 경로
    try:
        d = diagnose_bl_result(base, F)
        check("A2: NumPy 적분 호환 경로 정상", d.item("D2") is not None)
    except Exception as e:
        check("A2: NumPy 적분 호환 경로 정상", False, repr(e))

    # A-3. None principle
    class MissingMeasure:
        strikes = base.strikes
        density = base.density
        integral = 0.0
        neg_density_ratio = base.neg_density_ratio
        integral_clipped = None
        downside_mass = None
        upside_mass = None
        status = "OK"
        warnings = []
    d_none = diagnose_bl_result(MissingMeasure(), F)
    check("A3: 측정 불가값은 None 유지",
          d_none.item("D2").value is None and d_none.item("D7").value is None and
          d_none.item("D8").value is None and d_none.item("D9").value is None)

    # A-4. noiseless baseline
    d_clean = diagnose_bl_result(base, F)
    check("A4: 무잡음 정상 입력 진단 실행", d_clean.worst_state in (QualityState.OK, QualityState.WARN),
          f"worst={d_clean.worst_state.value}")

    # A-5. 강제 음수 밀도 결함 — 진단이 OK로 남지 않는지
    q_bad = base.density.copy()
    q_bad[20:80] -= max(abs(q_bad)) * 0.20
    bad = BLResult(base.strikes, q_bad,
                   float(_trapz(q_bad, base.strikes)),
                   float(_trapz(np.clip(q_bad, 0, None), base.strikes)),
                   float(np.mean(q_bad < -NEG_TOL_REL * max(abs(q_bad)))),
                   base.monotonic_violations, base.convexity_violations,
                   base.downside_mass, base.upside_mass, True, "OK", [])
    d_bad = diagnose_noisy(bad, F)
    check("A5: 음수 밀도 결함을 OK로 방치하지 않음",
          d_bad.worst_state in (QualityState.WARN, QualityState.DEGRADED, QualityState.UNUSABLE),
          f"D1={d_bad.item('D1').value:.4f}, worst={d_bad.worst_state.value}")

    # A-6. 질량 합 > 1 진단
    mass_bad = BLResult(base.strikes, base.density,
                        1.12, base.integral_clipped, base.neg_density_ratio,
                        base.monotonic_violations, base.convexity_violations,
                        base.downside_mass, base.upside_mass, base.clipped_negative,
                        base.status, base.warnings)
    d_mass = diagnose_bl_result(mass_bad, F)
    check("A6: 질량 합 > 1.10을 UNUSABLE로 표시", d_mass.item("D3").state is QualityState.UNUSABLE,
          f"D3={d_mass.item('D3').value}")

    # A-7. forward outside grid
    narrow_K = np.linspace(300.0, 400.0, 21)
    narrow = bl_density(narrow_K, bs_call(S, narrow_K, R, T, SIG), F, T, R)
    d_narrow = diagnose_bl_result(narrow, F)
    check("A7: forward 격자 밖을 DEGRADED/UNUSABLE로 표시",
          d_narrow.item("D0").state in (QualityState.DEGRADED, QualityState.UNUSABLE)
          or d_narrow.item("D5").state is QualityState.UNUSABLE,
          f"D0={d_narrow.item('D0').state.value}, D5={d_narrow.item('D5').state.value}")

    # A-8. 실제 과거 문제와 유사한 noise/tick case — 예외 없이 진단
    noisy_cases = [
        (0.01, 0.001, 0.01, 0.01, 11),
        (0.05, 0.005, 0.01, 0.01, 12),
        (0.10, 0.010, 0.01, 0.01, 13),
    ]
    observed = []
    for noise_abs, noise_rel, tick, spread, seed in noisy_cases:
        c = make_noisy_calls(S, R, T, SIG, K, noise_abs, noise_rel, tick, spread, seed)
        r = bl_density(K, c, F, T, R, smoothing_s=len(K) * noise_abs**2)
        dd = diagnose_noisy(r, F)
        observed.append((r.neg_density_ratio, r.integral, dd.worst_state.value))
    check("A8: noise/tick/smoothing 케이스 3종 진단 실행", len(observed) == 3,
          str(observed))

    # A-9. price/IV 경로 비교 함수 기본 계약(질량 비교만)
    d_price = diagnose_bl_result(base, F, source="price")
    d_iv = diagnose_bl_result(base, F, source="iv")
    mp, mi = d_price.item("D3").value, d_iv.item("D3").value
    diff = abs(mp - mi) / max(abs(mp), 1e-12)
    check("A9: price/IV 질량 비교값 산출", np.isfinite(diff), f"mass_diff={diff:.6g}")

    print("\n" + "=" * 72)
    passed = sum(results)
    total = len(results)
    print(f"A 단계 통합 재검증: {passed}/{total} PASS")
    print("※ PASS는 v0.3 1단계 수정의 샌드박스 동작 확인이지 Approval C 최종 통과를 의미하지 않습니다.")
    print("※ B 단계 설계/수정은 이 파일의 결과 검토 후 별도 결정합니다.")
    print("=" * 72)
    return 0 if all(results) else 1


if __name__ == "__main__":
    try:
        raise SystemExit(run())
    except Exception:
        traceback.print_exc()
        raise SystemExit(2)
